#!/usr/bin/env python3
"""
Offline Verification Suite for NutriTrack (`tools/verify_project.py`).
Because the container environment lacks `javac`, `kotlinc`, Gradle, and the Android SDK,
this script provides deterministic verification of:
1. Kotlin source file structural integrity (package declarations, balanced delimiters, non-empty classes).
2. Seed food dataset (`seed_foods.json` and `seed_foods.csv`) completeness, raw/cooked separation,
   and `source = "ESTIMATE"` honesty tagging.
3. Exact SQLite schema, foreign-key constraints (`ON DELETE SET NULL` when deleting custom foods),
   SQL `SUM` daily total queries, logged-day-only history queries, file-backed persistence across
   close/reopen, and `MIGRATION_1_2` (`ALTER TABLE foods ADD COLUMN barcode/notes`).
"""

import json
import sqlite3
import tempfile
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent.parent

KOTLIN_FILES = [
    "app/src/main/java/com/nutritrack/app/domain/model/Enums.kt",
    "app/src/main/java/com/nutritrack/app/data/local/Converters.kt",
    "app/src/main/java/com/nutritrack/app/data/local/entity/Entities.kt",
    "app/src/main/java/com/nutritrack/app/data/local/dao/Daos.kt",
    "app/src/main/java/com/nutritrack/app/data/local/NutriTrackDatabase.kt",
    "app/src/main/java/com/nutritrack/app/data/local/SeedDatabaseLoader.kt",
    "app/src/main/java/com/nutritrack/app/data/preferences/UserPreferencesRepository.kt",
    "app/src/main/java/com/nutritrack/app/data/repository/NutritionRepository.kt",
    "app/src/main/java/com/nutritrack/app/data/remote/OpenFoodFactsClient.kt",
    "app/src/main/java/com/nutritrack/app/domain/calculation/NutritionCalculator.kt",
    "app/src/main/java/com/nutritrack/app/domain/calculation/HistoryAnalyzer.kt",
    "app/src/main/java/com/nutritrack/app/domain/parser/FoodSearchMatcher.kt",
    "app/src/main/java/com/nutritrack/app/domain/parser/QuickAddParser.kt",
    "app/src/main/java/com/nutritrack/app/domain/export/CsvExporter.kt",
    "app/src/main/java/com/nutritrack/app/di/AppContainer.kt",
    "app/src/main/java/com/nutritrack/app/ui/theme/Theme.kt",
    "app/src/main/java/com/nutritrack/app/ui/components/NutrientSummaryCard.kt",
    "app/src/main/java/com/nutritrack/app/ui/screens/home/HomeScreen.kt",
    "app/src/main/java/com/nutritrack/app/ui/screens/foods/FoodsScreen.kt",
    "app/src/main/java/com/nutritrack/app/ui/screens/quickadd/QuickAddBottomSheet.kt",
    "app/src/main/java/com/nutritrack/app/ui/screens/diary/DiaryScreen.kt",
    "app/src/main/java/com/nutritrack/app/ui/screens/settings/SettingsScreen.kt",
    "app/src/main/java/com/nutritrack/app/ui/navigation/NutriTrackNavHost.kt",
    "app/src/main/java/com/nutritrack/app/ui/NutriTrackViewModel.kt",
    "app/src/main/java/com/nutritrack/app/NutriTrackApplication.kt",
    "app/src/main/java/com/nutritrack/app/MainActivity.kt",
    "app/src/test/java/com/nutritrack/app/domain/calculation/NutritionCalculatorTest.kt",
    "app/src/test/java/com/nutritrack/app/domain/parser/QuickAddParserTest.kt",
    "app/src/test/java/com/nutritrack/app/domain/export/HistoryAndCsvExportTest.kt",
    "app/src/test/java/com/nutritrack/app/data/local/NutriTrackRoomRobolectricTest.kt",
]


def verify_kotlin_sources() -> int:
    for rel in KOTLIN_FILES:
        kt = PROJECT_ROOT / rel
        assert kt.exists(), f"Missing Kotlin source file: {rel}"
        text = kt.read_text(encoding="utf-8")
        assert "package com.nutritrack.app" in text, f"Missing package declaration in {rel}"
        open_braces = text.count("{")
        close_braces = text.count("}")
        assert open_braces == close_braces, (
            f"Unbalanced braces in {rel}: {open_braces} open vs {close_braces} close"
        )
        assert "= True" not in text and "= False" not in text, f"Python boolean typo in {rel}"
    return len(KOTLIN_FILES)


def verify_seed_data() -> int:
    json_path = PROJECT_ROOT / "app/src/main/assets/seed_foods.json"
    csv_path = PROJECT_ROOT / "app/src/main/assets/seed_foods.csv"
    assert json_path.exists(), "Missing seed_foods.json"
    assert csv_path.exists(), "Missing seed_foods.csv"

    foods = json.loads(json_path.read_text(encoding="utf-8"))
    assert 55 <= len(foods) <= 65, f"Expected ~60 seed foods, found {len(foods)}"

    names = {f["name"] for f in foods}
    for required_pair in [
        ("White Rice (Cooked)", "White Rice (Raw)"),
        ("Toor / Arhar Dal (Cooked)", "Toor / Arhar Dal (Raw)"),
        ("Moong Dal (Cooked)", "Moong Dal (Raw)"),
        ("Rajma / Kidney Beans (Cooked)", "Rajma / Kidney Beans (Raw)"),
        ("Chole / Kabuli Chana (Cooked)", "Chole / Kabuli Chana (Raw)"),
        ("Kala Chana / Black Chickpeas (Cooked)", "Kala Chana / Black Chickpeas (Raw)"),
        ("Rolled Oats (Raw)", "Oats Porridge (Cooked in Water)"),
        ("Soy Chunks (Dry / Uncooked)", "Soy Chunks (Boiled / Cooked)"),
    ]:
        assert required_pair[0] in names and required_pair[1] in names, (
            f"Missing raw/cooked pair: {required_pair}"
        )

    for f in foods:
        assert f["source"] == "ESTIMATE", f"Expected ESTIMATE source for {f['name']}"
        assert len(f.get("servings", [])) >= 1, f"Missing servings for {f['name']}"

    return len(foods)


def verify_sqlite_schema_and_migrations() -> None:
    with tempfile.TemporaryDirectory() as tmpdir:
        db_path = Path(tmpdir) / "nutritrack_verify.db"

        conn = sqlite3.connect(db_path)
        conn.execute("PRAGMA foreign_keys = ON")
        conn.executescript(
            """
            CREATE TABLE IF NOT EXISTS `foods` (
                `id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                `name` TEXT NOT NULL,
                `aliases` TEXT NOT NULL,
                `category` TEXT NOT NULL,
                `basis` TEXT NOT NULL,
                `kcalPer100` REAL NOT NULL,
                `proteinPer100` REAL NOT NULL,
                `carbsPer100` REAL NOT NULL,
                `fatPer100` REAL NOT NULL,
                `preparation` TEXT NOT NULL,
                `densityGPerMl` REAL,
                `source` TEXT NOT NULL,
                `isCustom` INTEGER NOT NULL
            );
            CREATE TABLE IF NOT EXISTS `food_servings` (
                `id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                `foodId` INTEGER NOT NULL,
                `label` TEXT NOT NULL,
                `amountGramsOrMl` REAL NOT NULL,
                `isDefault` INTEGER NOT NULL,
                FOREIGN KEY(`foodId`) REFERENCES `foods`(`id`) ON UPDATE NO ACTION ON DELETE CASCADE
            );
            CREATE TABLE IF NOT EXISTS `food_entries` (
                `id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                `entryDate` TEXT NOT NULL,
                `loggedAt` INTEGER NOT NULL,
                `mealCategory` TEXT NOT NULL,
                `foodId` INTEGER,
                `foodNameSnapshot` TEXT NOT NULL,
                `quantity` REAL NOT NULL,
                `unit` TEXT NOT NULL,
                `amountGramsOrMl` REAL NOT NULL,
                `kcal` REAL NOT NULL,
                `protein` REAL NOT NULL,
                `carbs` REAL NOT NULL,
                `fat` REAL NOT NULL,
                `sourceSnapshot` TEXT NOT NULL,
                FOREIGN KEY(`foodId`) REFERENCES `foods`(`id`) ON UPDATE NO ACTION ON DELETE SET NULL
            );
            CREATE TABLE IF NOT EXISTS `nutrition_targets` (
                `id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                `effectiveFrom` TEXT NOT NULL UNIQUE,
                `kcal` REAL,
                `protein` REAL,
                `carbs` REAL,
                `fat` REAL
            );
            """
        )

        # Apply MIGRATION_1_2
        conn.execute("ALTER TABLE `foods` ADD COLUMN `barcode` TEXT DEFAULT NULL")
        conn.execute("ALTER TABLE `foods` ADD COLUMN `notes` TEXT DEFAULT NULL")
        conn.execute("CREATE INDEX IF NOT EXISTS `index_foods_barcode` ON `foods` (`barcode`)")

        cur = conn.cursor()
        cur.execute(
            """
            INSERT INTO foods (name, aliases, category, basis, kcalPer100, proteinPer100, carbsPer100, fatPer100, preparation, densityGPerMl, source, isCustom)
            VALUES ('Custom Laddoo', 'laddoo', 'Custom', 'PER_100G', 420.0, 8.0, 55.0, 18.0, 'COOKED', NULL, 'USER', 1)
            """
        )
        custom_food_id = cur.lastrowid

        cur.execute(
            """
            INSERT INTO food_entries (entryDate, loggedAt, mealCategory, foodId, foodNameSnapshot, quantity, unit, amountGramsOrMl, kcal, protein, carbs, fat, sourceSnapshot)
            VALUES
            ('2026-10-19', 1000, 'BREAKFAST', ?, 'Food A', 100.0, 'g', 100.0, 200.0, 10.0, 25.0, 6.0, 'USER'),
            ('2026-10-19', 2000, 'LUNCH', NULL, 'Food B', 100.0, 'g', 100.0, 300.0, 20.0, 30.0, 10.0, 'ESTIMATE')
            """,
            (custom_food_id,)
        )
        conn.commit()

        row = conn.execute(
            """
            SELECT
                COALESCE(SUM(kcal), 0.0) AS totalKcal,
                COALESCE(SUM(protein), 0.0) AS totalProtein,
                COALESCE(SUM(carbs), 0.0) AS totalCarbs,
                COALESCE(SUM(fat), 0.0) AS totalFat,
                COUNT(*) AS entryCount
            FROM food_entries
            WHERE entryDate = '2026-10-19'
            """
        ).fetchone()
        assert row == (500.0, 30.0, 55.0, 16.0, 2), f"Unexpected SQL SUM result: {row}"

        conn.execute("DELETE FROM foods WHERE id = ?", (custom_food_id,))
        conn.commit()
        conn.close()

        conn2 = sqlite3.connect(db_path)
        conn2.execute("PRAGMA foreign_keys = ON")
        surviving = conn2.execute(
            "SELECT foodId, foodNameSnapshot, kcal, protein, carbs, fat FROM food_entries WHERE foodNameSnapshot = 'Food A'"
        ).fetchone()
        assert surviving == (None, "Food A", 200.0, 10.0, 25.0, 6.0), (
            f"ON DELETE SET NULL or persistence failed: {surviving}"
        )
        conn2.close()


if __name__ == "__main__":
    kt_count = verify_kotlin_sources()
    seed_count = verify_seed_data()
    verify_sqlite_schema_and_migrations()
    print(
        f"[PASS] Verified {kt_count} Kotlin source files, {seed_count} seed foods, "
        "SQLite schema, ON DELETE SET NULL, SQL SUM fixture (500 kcal / 30P / 55C / 16F), "
        "file-backed persistence, and MIGRATION_1_2."
    )
