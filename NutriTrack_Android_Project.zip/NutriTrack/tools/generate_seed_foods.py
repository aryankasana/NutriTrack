#!/usr/bin/env python3
"""
Regenerates NutriTrack's offline seed food catalog (60 Indian & gym essentials)
into app/src/main/assets/seed_foods.json and app/src/main/assets/seed_foods.csv.

All rows generated without live IFCT 2017 / USDA FDC / Open Food Facts dataset downloads
are marked `source = "ESTIMATE"` per project ground rules, so the UI displays an
"Estimated" badge and the final report lists every row needing verification.
"""

import csv
import json
from pathlib import Path
from typing import Any, Dict, List

PROJECT_ROOT = Path(__file__).resolve().parent.parent
ASSETS_DIR = PROJECT_ROOT / "app" / "src" / "main" / "assets"


def build_seed_foods() -> List[Dict[str, Any]]:
    return [
        {
                "name": "Whole Wheat Roti",
                "aliases": "roti,chapati,chappati,phulka,fulka,wheat roti",
                "category": "Breads & Rotis",
                "basis": "PER_100G",
                "kcalPer100": 297.0,
                "proteinPer100": 9.8,
                "carbsPer100": 60.5,
                "fatPer100": 1.7,
                "preparation": "COOKED",
                "densityGPerMl": None,
                "source": "ESTIMATE",
                "notes": "Verify against IFCT 2017 (Whole wheat flour A019 adjusted for cooked chapati moisture)",
                "servings": [
                        {
                                "label": "roti",
                                "amountGramsOrMl": 35.0,
                                "isDefault": True
                        },
                        {
                                "label": "piece",
                                "amountGramsOrMl": 35.0,
                                "isDefault": False
                        }
                ]
        },
        {
                "name": "Plain Wheat Paratha",
                "aliases": "paratha,parantha,plain paratha,tawa paratha",
                "category": "Breads & Rotis",
                "basis": "PER_100G",
                "kcalPer100": 326.0,
                "proteinPer100": 8.2,
                "carbsPer100": 51.0,
                "fatPer100": 9.8,
                "preparation": "COOKED",
                "densityGPerMl": None,
                "source": "ESTIMATE",
                "notes": "Verify against IFCT 2017 / NIN Nutritive Value of Indian Foods",
                "servings": [
                        {
                                "label": "paratha",
                                "amountGramsOrMl": 60.0,
                                "isDefault": True
                        },
                        {
                                "label": "piece",
                                "amountGramsOrMl": 60.0,
                                "isDefault": False
                        }
                ]
        },
        {
                "name": "Aloo Paratha",
                "aliases": "aloo parantha,potato paratha,stuffed aloo paratha",
                "category": "Breads & Rotis",
                "basis": "PER_100G",
                "kcalPer100": 265.0,
                "proteinPer100": 5.8,
                "carbsPer100": 41.5,
                "fatPer100": 8.4,
                "preparation": "COOKED",
                "densityGPerMl": None,
                "source": "ESTIMATE",
                "notes": "Verify against NIN standard recipe tables (stuffed potato flatbread)",
                "servings": [
                        {
                                "label": "paratha",
                                "amountGramsOrMl": 110.0,
                                "isDefault": True
                        },
                        {
                                "label": "piece",
                                "amountGramsOrMl": 110.0,
                                "isDefault": False
                        }
                ]
        },
        {
                "name": "Paneer Paratha",
                "aliases": "paneer parantha,stuffed paneer paratha",
                "category": "Breads & Rotis",
                "basis": "PER_100G",
                "kcalPer100": 295.0,
                "proteinPer100": 11.2,
                "carbsPer100": 36.0,
                "fatPer100": 11.5,
                "preparation": "COOKED",
                "densityGPerMl": None,
                "source": "ESTIMATE",
                "notes": "Verify against NIN standard recipe tables",
                "servings": [
                        {
                                "label": "paratha",
                                "amountGramsOrMl": 120.0,
                                "isDefault": True
                        },
                        {
                                "label": "piece",
                                "amountGramsOrMl": 120.0,
                                "isDefault": False
                        }
                ]
        },
        {
                "name": "Bread (Whole Wheat / Brown)",
                "aliases": "bread,brown bread,wheat bread,whole wheat bread,bread slice,bread slices",
                "category": "Breads & Rotis",
                "basis": "PER_100G",
                "kcalPer100": 252.0,
                "proteinPer100": 9.5,
                "carbsPer100": 46.5,
                "fatPer100": 3.0,
                "preparation": "NA",
                "densityGPerMl": None,
                "source": "ESTIMATE",
                "notes": "Verify against USDA FDC (Bread, whole-wheat, commercially prepared) / OFF",
                "servings": [
                        {
                                "label": "slice",
                                "amountGramsOrMl": 28.0,
                                "isDefault": True
                        },
                        {
                                "label": "piece",
                                "amountGramsOrMl": 28.0,
                                "isDefault": False
                        }
                ]
        },
        {
                "name": "White Bread",
                "aliases": "white bread,sandwich bread,maida bread",
                "category": "Breads & Rotis",
                "basis": "PER_100G",
                "kcalPer100": 266.0,
                "proteinPer100": 7.9,
                "carbsPer100": 50.6,
                "fatPer100": 3.3,
                "preparation": "NA",
                "densityGPerMl": None,
                "source": "ESTIMATE",
                "notes": "Verify against USDA FDC (Bread, white, commercially prepared)",
                "servings": [
                        {
                                "label": "slice",
                                "amountGramsOrMl": 25.0,
                                "isDefault": True
                        },
                        {
                                "label": "piece",
                                "amountGramsOrMl": 25.0,
                                "isDefault": False
                        }
                ]
        },
        {
                "name": "White Rice (Cooked)",
                "aliases": "rice,cooked rice,steamed rice,boiled rice,chawal,bhaat,white rice",
                "category": "Rice & Grains",
                "basis": "PER_100G",
                "kcalPer100": 130.0,
                "proteinPer100": 2.7,
                "carbsPer100": 28.2,
                "fatPer100": 0.3,
                "preparation": "COOKED",
                "densityGPerMl": None,
                "source": "ESTIMATE",
                "notes": "Verify against USDA FDC / IFCT 2017 (Rice, white, cooked)",
                "servings": [
                        {
                                "label": "katori",
                                "amountGramsOrMl": 130.0,
                                "isDefault": True
                        },
                        {
                                "label": "bowl",
                                "amountGramsOrMl": 180.0,
                                "isDefault": False
                        },
                        {
                                "label": "cup",
                                "amountGramsOrMl": 158.0,
                                "isDefault": False
                        }
                ]
        },
        {
                "name": "White Rice (Raw)",
                "aliases": "raw rice,uncooked rice,raw white rice,kacha chawal",
                "category": "Rice & Grains",
                "basis": "PER_100G",
                "kcalPer100": 356.0,
                "proteinPer100": 7.8,
                "carbsPer100": 78.2,
                "fatPer100": 0.5,
                "preparation": "RAW",
                "densityGPerMl": None,
                "source": "ESTIMATE",
                "notes": "Verify against IFCT 2017 (Rice, raw, milled A015)",
                "servings": [
                        {
                                "label": "katori",
                                "amountGramsOrMl": 100.0,
                                "isDefault": True
                        },
                        {
                                "label": "cup",
                                "amountGramsOrMl": 185.0,
                                "isDefault": False
                        }
                ]
        },
        {
                "name": "Brown Rice (Cooked)",
                "aliases": "brown rice,cooked brown rice",
                "category": "Rice & Grains",
                "basis": "PER_100G",
                "kcalPer100": 123.0,
                "proteinPer100": 2.7,
                "carbsPer100": 25.6,
                "fatPer100": 1.0,
                "preparation": "COOKED",
                "densityGPerMl": None,
                "source": "ESTIMATE",
                "notes": "Verify against USDA FDC (Rice, brown, medium-grain, cooked)",
                "servings": [
                        {
                                "label": "katori",
                                "amountGramsOrMl": 135.0,
                                "isDefault": True
                        },
                        {
                                "label": "cup",
                                "amountGramsOrMl": 195.0,
                                "isDefault": False
                        }
                ]
        },
        {
                "name": "Rolled Oats (Raw)",
                "aliases": "oats,raw oats,rolled oats,quaker oats,dry oats",
                "category": "Rice & Grains",
                "basis": "PER_100G",
                "kcalPer100": 379.0,
                "proteinPer100": 13.2,
                "carbsPer100": 67.7,
                "fatPer100": 6.5,
                "preparation": "RAW",
                "densityGPerMl": None,
                "source": "ESTIMATE",
                "notes": "Verify against USDA FDC (Oats, regular and quick, not fortified, dry)",
                "servings": [
                        {
                                "label": "cup",
                                "amountGramsOrMl": 80.0,
                                "isDefault": True
                        },
                        {
                                "label": "katori",
                                "amountGramsOrMl": 50.0,
                                "isDefault": False
                        },
                        {
                                "label": "tbsp",
                                "amountGramsOrMl": 10.0,
                                "isDefault": False
                        }
                ]
        },
        {
                "name": "Oats Porridge (Cooked in Water)",
                "aliases": "cooked oats,oatmeal,boiled oats,oats porridge",
                "category": "Rice & Grains",
                "basis": "PER_100G",
                "kcalPer100": 71.0,
                "proteinPer100": 2.5,
                "carbsPer100": 12.0,
                "fatPer100": 1.5,
                "preparation": "COOKED",
                "densityGPerMl": None,
                "source": "ESTIMATE",
                "notes": "Verify against USDA FDC (Oatmeal, cooked with water)",
                "servings": [
                        {
                                "label": "katori",
                                "amountGramsOrMl": 160.0,
                                "isDefault": True
                        },
                        {
                                "label": "bowl",
                                "amountGramsOrMl": 240.0,
                                "isDefault": False
                        },
                        {
                                "label": "cup",
                                "amountGramsOrMl": 234.0,
                                "isDefault": False
                        }
                ]
        },
        {
                "name": "Toor / Arhar Dal (Cooked)",
                "aliases": "dal,toor dal,arhar dal,yellow dal,dal tadka,cooked dal,tuvar dal",
                "category": "Dals & Legumes",
                "basis": "PER_100G",
                "kcalPer100": 118.0,
                "proteinPer100": 6.2,
                "carbsPer100": 17.5,
                "fatPer100": 2.6,
                "preparation": "COOKED",
                "densityGPerMl": None,
                "source": "ESTIMATE",
                "notes": "Verify against IFCT 2017 (Red gram dal B013 adjusted for cooked consistency)",
                "servings": [
                        {
                                "label": "katori",
                                "amountGramsOrMl": 150.0,
                                "isDefault": True
                        },
                        {
                                "label": "bowl",
                                "amountGramsOrMl": 200.0,
                                "isDefault": False
                        },
                        {
                                "label": "cup",
                                "amountGramsOrMl": 200.0,
                                "isDefault": False
                        }
                ]
        },
        {
                "name": "Toor / Arhar Dal (Raw)",
                "aliases": "raw dal,raw toor dal,raw arhar dal,uncooked toor dal",
                "category": "Dals & Legumes",
                "basis": "PER_100G",
                "kcalPer100": 331.0,
                "proteinPer100": 21.7,
                "carbsPer100": 57.6,
                "fatPer100": 1.6,
                "preparation": "RAW",
                "densityGPerMl": None,
                "source": "ESTIMATE",
                "notes": "Verify against IFCT 2017 (Red gram, dal B013)",
                "servings": [
                        {
                                "label": "katori",
                                "amountGramsOrMl": 100.0,
                                "isDefault": True
                        },
                        {
                                "label": "tbsp",
                                "amountGramsOrMl": 15.0,
                                "isDefault": False
                        }
                ]
        },
        {
                "name": "Moong Dal (Cooked)",
                "aliases": "moong dal,mung dal,yellow moong dal,cooked moong dal",
                "category": "Dals & Legumes",
                "basis": "PER_100G",
                "kcalPer100": 106.0,
                "proteinPer100": 6.8,
                "carbsPer100": 16.5,
                "fatPer100": 1.4,
                "preparation": "COOKED",
                "densityGPerMl": None,
                "source": "ESTIMATE",
                "notes": "Verify against IFCT 2017 (Green gram dal B009 cooked portion)",
                "servings": [
                        {
                                "label": "katori",
                                "amountGramsOrMl": 150.0,
                                "isDefault": True
                        },
                        {
                                "label": "bowl",
                                "amountGramsOrMl": 200.0,
                                "isDefault": False
                        }
                ]
        },
        {
                "name": "Moong Dal (Raw)",
                "aliases": "raw moong dal,uncooked moong dal",
                "category": "Dals & Legumes",
                "basis": "PER_100G",
                "kcalPer100": 326.0,
                "proteinPer100": 23.9,
                "carbsPer100": 56.0,
                "fatPer100": 1.1,
                "preparation": "RAW",
                "densityGPerMl": None,
                "source": "ESTIMATE",
                "notes": "Verify against IFCT 2017 (Green gram, dal B009)",
                "servings": [
                        {
                                "label": "katori",
                                "amountGramsOrMl": 100.0,
                                "isDefault": True
                        }
                ]
        },
        {
                "name": "Masoor Dal (Cooked)",
                "aliases": "masoor dal,red lentil dal,cooked masoor dal",
                "category": "Dals & Legumes",
                "basis": "PER_100G",
                "kcalPer100": 116.0,
                "proteinPer100": 7.6,
                "carbsPer100": 18.2,
                "fatPer100": 1.5,
                "preparation": "COOKED",
                "densityGPerMl": None,
                "source": "ESTIMATE",
                "notes": "Verify against IFCT 2017 (Lentil dal B011 cooked portion)",
                "servings": [
                        {
                                "label": "katori",
                                "amountGramsOrMl": 150.0,
                                "isDefault": True
                        },
                        {
                                "label": "bowl",
                                "amountGramsOrMl": 200.0,
                                "isDefault": False
                        }
                ]
        },
        {
                "name": "Chana Dal (Cooked)",
                "aliases": "chana dal,cooked chana dal,bengal gram dal",
                "category": "Dals & Legumes",
                "basis": "PER_100G",
                "kcalPer100": 136.0,
                "proteinPer100": 7.4,
                "carbsPer100": 19.8,
                "fatPer100": 3.1,
                "preparation": "COOKED",
                "densityGPerMl": None,
                "source": "ESTIMATE",
                "notes": "Verify against IFCT 2017 (Bengal gram, dal B002 cooked)",
                "servings": [
                        {
                                "label": "katori",
                                "amountGramsOrMl": 150.0,
                                "isDefault": True
                        },
                        {
                                "label": "bowl",
                                "amountGramsOrMl": 200.0,
                                "isDefault": False
                        }
                ]
        },
        {
                "name": "Rajma / Kidney Beans (Cooked)",
                "aliases": "rajma,cooked rajma,rajma curry,rajma masala,kidney beans",
                "category": "Dals & Legumes",
                "basis": "PER_100G",
                "kcalPer100": 140.0,
                "proteinPer100": 7.8,
                "carbsPer100": 20.4,
                "fatPer100": 3.0,
                "preparation": "COOKED",
                "densityGPerMl": None,
                "source": "ESTIMATE",
                "notes": "Verify against IFCT 2017 (Rajmah B012 cooked curry)",
                "servings": [
                        {
                                "label": "katori",
                                "amountGramsOrMl": 150.0,
                                "isDefault": True
                        },
                        {
                                "label": "bowl",
                                "amountGramsOrMl": 200.0,
                                "isDefault": False
                        },
                        {
                                "label": "cup",
                                "amountGramsOrMl": 177.0,
                                "isDefault": False
                        }
                ]
        },
        {
                "name": "Rajma / Kidney Beans (Raw)",
                "aliases": "raw rajma,uncooked rajma,dry kidney beans",
                "category": "Dals & Legumes",
                "basis": "PER_100G",
                "kcalPer100": 299.0,
                "proteinPer100": 19.9,
                "carbsPer100": 48.6,
                "fatPer100": 1.8,
                "preparation": "RAW",
                "densityGPerMl": None,
                "source": "ESTIMATE",
                "notes": "Verify against IFCT 2017 (Rajmah, brown/red B012)",
                "servings": [
                        {
                                "label": "katori",
                                "amountGramsOrMl": 100.0,
                                "isDefault": True
                        }
                ]
        },
        {
                "name": "Chole / Kabuli Chana (Cooked)",
                "aliases": "chole,chhole,chana masala,kabuli chana,cooked chole,chickpeas,boiled chickpeas",
                "category": "Dals & Legumes",
                "basis": "PER_100G",
                "kcalPer100": 155.0,
                "proteinPer100": 7.9,
                "carbsPer100": 22.5,
                "fatPer100": 3.8,
                "preparation": "COOKED",
                "densityGPerMl": None,
                "source": "ESTIMATE",
                "notes": "Verify against IFCT 2017 / USDA FDC (Chickpeas, mature seeds, cooked)",
                "servings": [
                        {
                                "label": "katori",
                                "amountGramsOrMl": 150.0,
                                "isDefault": True
                        },
                        {
                                "label": "bowl",
                                "amountGramsOrMl": 200.0,
                                "isDefault": False
                        },
                        {
                                "label": "cup",
                                "amountGramsOrMl": 164.0,
                                "isDefault": False
                        }
                ]
        },
        {
                "name": "Chole / Kabuli Chana (Raw)",
                "aliases": "raw chole,raw kabuli chana,dry chickpeas",
                "category": "Dals & Legumes",
                "basis": "PER_100G",
                "kcalPer100": 334.0,
                "proteinPer100": 18.8,
                "carbsPer100": 52.4,
                "fatPer100": 5.1,
                "preparation": "RAW",
                "densityGPerMl": None,
                "source": "ESTIMATE",
                "notes": "Verify against IFCT 2017 (Bengal gram, whole, white)",
                "servings": [
                        {
                                "label": "katori",
                                "amountGramsOrMl": 100.0,
                                "isDefault": True
                        }
                ]
        },
        {
                "name": "Kala Chana / Black Chickpeas (Cooked)",
                "aliases": "chana,kala chana,boiled chana,black chana,cooked chana",
                "category": "Dals & Legumes",
                "basis": "PER_100G",
                "kcalPer100": 148.0,
                "proteinPer100": 8.2,
                "carbsPer100": 23.0,
                "fatPer100": 2.6,
                "preparation": "COOKED",
                "densityGPerMl": None,
                "source": "ESTIMATE",
                "notes": "Verify against IFCT 2017 (Bengal gram, whole B001 boiled)",
                "servings": [
                        {
                                "label": "katori",
                                "amountGramsOrMl": 140.0,
                                "isDefault": True
                        },
                        {
                                "label": "bowl",
                                "amountGramsOrMl": 180.0,
                                "isDefault": False
                        }
                ]
        },
        {
                "name": "Kala Chana / Black Chickpeas (Raw)",
                "aliases": "raw chana,raw kala chana,dry black chana",
                "category": "Dals & Legumes",
                "basis": "PER_100G",
                "kcalPer100": 287.0,
                "proteinPer100": 18.8,
                "carbsPer100": 43.2,
                "fatPer100": 5.1,
                "preparation": "RAW",
                "densityGPerMl": None,
                "source": "ESTIMATE",
                "notes": "Verify against IFCT 2017 (Bengal gram, whole B001)",
                "servings": [
                        {
                                "label": "katori",
                                "amountGramsOrMl": 100.0,
                                "isDefault": True
                        }
                ]
        },
        {
                "name": "Dal Khichdi (Cooked)",
                "aliases": "khichdi,moong dal khichdi,dal khichdi",
                "category": "Indian Staples",
                "basis": "PER_100G",
                "kcalPer100": 122.0,
                "proteinPer100": 4.3,
                "carbsPer100": 20.8,
                "fatPer100": 2.4,
                "preparation": "COOKED",
                "densityGPerMl": None,
                "source": "ESTIMATE",
                "notes": "Verify against NIN standard Indian dish composition tables",
                "servings": [
                        {
                                "label": "katori",
                                "amountGramsOrMl": 160.0,
                                "isDefault": True
                        },
                        {
                                "label": "bowl",
                                "amountGramsOrMl": 250.0,
                                "isDefault": False
                        }
                ]
        },
        {
                "name": "Kanda Poha (Cooked)",
                "aliases": "poha,kanda poha,batata poha,aval,flattened rice cooked",
                "category": "Indian Staples",
                "basis": "PER_100G",
                "kcalPer100": 158.0,
                "proteinPer100": 3.2,
                "carbsPer100": 27.5,
                "fatPer100": 4.1,
                "preparation": "COOKED",
                "densityGPerMl": None,
                "source": "ESTIMATE",
                "notes": "Verify against NIN standard breakfast dishes",
                "servings": [
                        {
                                "label": "katori",
                                "amountGramsOrMl": 120.0,
                                "isDefault": True
                        },
                        {
                                "label": "bowl",
                                "amountGramsOrMl": 180.0,
                                "isDefault": False
                        }
                ]
        },
        {
                "name": "Rava Upma (Cooked)",
                "aliases": "upma,rava upma,suji upma,sooji upma",
                "category": "Indian Staples",
                "basis": "PER_100G",
                "kcalPer100": 165.0,
                "proteinPer100": 3.8,
                "carbsPer100": 26.2,
                "fatPer100": 4.9,
                "preparation": "COOKED",
                "densityGPerMl": None,
                "source": "ESTIMATE",
                "notes": "Verify against NIN standard breakfast dishes",
                "servings": [
                        {
                                "label": "katori",
                                "amountGramsOrMl": 140.0,
                                "isDefault": True
                        },
                        {
                                "label": "bowl",
                                "amountGramsOrMl": 200.0,
                                "isDefault": False
                        }
                ]
        },
        {
                "name": "Plain Idli (Steamed)",
                "aliases": "idli,idly,rice idli,steamed idli",
                "category": "Indian Staples",
                "basis": "PER_100G",
                "kcalPer100": 146.0,
                "proteinPer100": 4.6,
                "carbsPer100": 30.2,
                "fatPer100": 0.6,
                "preparation": "COOKED",
                "densityGPerMl": None,
                "source": "ESTIMATE",
                "notes": "Verify against NIN standard South Indian breakfast tables",
                "servings": [
                        {
                                "label": "idli",
                                "amountGramsOrMl": 45.0,
                                "isDefault": True
                        },
                        {
                                "label": "piece",
                                "amountGramsOrMl": 45.0,
                                "isDefault": False
                        }
                ]
        },
        {
                "name": "Plain Dosa",
                "aliases": "dosa,plain dosa,sada dosa,dosai",
                "category": "Indian Staples",
                "basis": "PER_100G",
                "kcalPer100": 184.0,
                "proteinPer100": 4.5,
                "carbsPer100": 31.8,
                "fatPer100": 4.2,
                "preparation": "COOKED",
                "densityGPerMl": None,
                "source": "ESTIMATE",
                "notes": "Verify against NIN standard South Indian breakfast tables",
                "servings": [
                        {
                                "label": "dosa",
                                "amountGramsOrMl": 80.0,
                                "isDefault": True
                        },
                        {
                                "label": "piece",
                                "amountGramsOrMl": 80.0,
                                "isDefault": False
                        }
                ]
        },
        {
                "name": "Masala Dosa",
                "aliases": "masala dosa,mysore masala dosa",
                "category": "Indian Staples",
                "basis": "PER_100G",
                "kcalPer100": 206.0,
                "proteinPer100": 4.4,
                "carbsPer100": 32.5,
                "fatPer100": 6.4,
                "preparation": "COOKED",
                "densityGPerMl": None,
                "source": "ESTIMATE",
                "notes": "Verify against NIN standard South Indian breakfast tables",
                "servings": [
                        {
                                "label": "dosa",
                                "amountGramsOrMl": 150.0,
                                "isDefault": True
                        },
                        {
                                "label": "piece",
                                "amountGramsOrMl": 150.0,
                                "isDefault": False
                        }
                ]
        },
        {
                "name": "Besan Chilla",
                "aliases": "besan chilla,besan cheela,chilla,cheela,gram flour pancake",
                "category": "Indian Staples",
                "basis": "PER_100G",
                "kcalPer100": 218.0,
                "proteinPer100": 10.4,
                "carbsPer100": 27.5,
                "fatPer100": 7.2,
                "preparation": "COOKED",
                "densityGPerMl": None,
                "source": "ESTIMATE",
                "notes": "Verify against IFCT 2017 besan values adjusted for cooked chilla",
                "servings": [
                        {
                                "label": "piece",
                                "amountGramsOrMl": 65.0,
                                "isDefault": True
                        }
                ]
        },
        {
                "name": "Chana Sattu (Roasted Gram Flour)",
                "aliases": "sattu,chana sattu,sattu powder,roasted chana flour",
                "category": "Indian Staples",
                "basis": "PER_100G",
                "kcalPer100": 359.0,
                "proteinPer100": 20.6,
                "carbsPer100": 58.0,
                "fatPer100": 5.2,
                "preparation": "RAW",
                "densityGPerMl": None,
                "source": "ESTIMATE",
                "notes": "Verify against IFCT 2017 (Roasted Bengal gram flour)",
                "servings": [
                        {
                                "label": "tbsp",
                                "amountGramsOrMl": 15.0,
                                "isDefault": True
                        },
                        {
                                "label": "scoop",
                                "amountGramsOrMl": 30.0,
                                "isDefault": False
                        },
                        {
                                "label": "katori",
                                "amountGramsOrMl": 80.0,
                                "isDefault": False
                        }
                ]
        },
        {
                "name": "Paneer (Raw)",
                "aliases": "paneer,raw paneer,malai paneer,cottage cheese,indian paneer",
                "category": "Protein & Dairy",
                "basis": "PER_100G",
                "kcalPer100": 296.0,
                "proteinPer100": 18.8,
                "carbsPer100": 4.5,
                "fatPer100": 22.5,
                "preparation": "RAW",
                "densityGPerMl": None,
                "source": "ESTIMATE",
                "notes": "Verify against IFCT 2017 (Paneer / Chhana) and Amul Paneer nutrition facts",
                "servings": [
                        {
                                "label": "katori",
                                "amountGramsOrMl": 100.0,
                                "isDefault": True
                        },
                        {
                                "label": "piece",
                                "amountGramsOrMl": 20.0,
                                "isDefault": False
                        }
                ]
        },
        {
                "name": "Firm Tofu (Raw)",
                "aliases": "tofu,soya paneer,soy paneer,firm tofu",
                "category": "Protein & Dairy",
                "basis": "PER_100G",
                "kcalPer100": 144.0,
                "proteinPer100": 15.8,
                "carbsPer100": 2.8,
                "fatPer100": 8.7,
                "preparation": "RAW",
                "densityGPerMl": None,
                "source": "ESTIMATE",
                "notes": "Verify against USDA FDC (Tofu, firm, prepared with calcium sulfate)",
                "servings": [
                        {
                                "label": "katori",
                                "amountGramsOrMl": 100.0,
                                "isDefault": True
                        },
                        {
                                "label": "piece",
                                "amountGramsOrMl": 25.0,
                                "isDefault": False
                        }
                ]
        },
        {
                "name": "Milk (Toned / Cow Milk)",
                "aliases": "milk,toned milk,cow milk,doodh,amul taaza",
                "category": "Protein & Dairy",
                "basis": "PER_100ML",
                "kcalPer100": 62.0,
                "proteinPer100": 3.2,
                "carbsPer100": 4.8,
                "fatPer100": 3.2,
                "preparation": "NA",
                "densityGPerMl": 1.03,
                "source": "ESTIMATE",
                "notes": "Verify against IFCT 2017 (Milk, cow, whole) / Indian toned milk standard (3% fat)",
                "servings": [
                        {
                                "label": "cup",
                                "amountGramsOrMl": 200.0,
                                "isDefault": True
                        },
                        {
                                "label": "katori",
                                "amountGramsOrMl": 150.0,
                                "isDefault": False
                        }
                ]
        },
        {
                "name": "Full Cream Milk (Buffalo / Gold)",
                "aliases": "full cream milk,buffalo milk,amul gold",
                "category": "Protein & Dairy",
                "basis": "PER_100ML",
                "kcalPer100": 88.0,
                "proteinPer100": 3.5,
                "carbsPer100": 5.0,
                "fatPer100": 6.0,
                "preparation": "NA",
                "densityGPerMl": 1.03,
                "source": "ESTIMATE",
                "notes": "Verify against IFCT 2017 / Indian full cream milk standard (6% fat)",
                "servings": [
                        {
                                "label": "cup",
                                "amountGramsOrMl": 200.0,
                                "isDefault": True
                        }
                ]
        },
        {
                "name": "Curd / Dahi",
                "aliases": "curd,dahi,yogurt,plain curd,homemade curd",
                "category": "Protein & Dairy",
                "basis": "PER_100G",
                "kcalPer100": 61.0,
                "proteinPer100": 3.5,
                "carbsPer100": 4.7,
                "fatPer100": 3.3,
                "preparation": "NA",
                "densityGPerMl": 1.03,
                "source": "ESTIMATE",
                "notes": "Verify against IFCT 2017 / USDA FDC (Yogurt, plain, whole milk)",
                "servings": [
                        {
                                "label": "katori",
                                "amountGramsOrMl": 150.0,
                                "isDefault": True
                        },
                        {
                                "label": "cup",
                                "amountGramsOrMl": 200.0,
                                "isDefault": False
                        },
                        {
                                "label": "bowl",
                                "amountGramsOrMl": 200.0,
                                "isDefault": False
                        },
                        {
                                "label": "tbsp",
                                "amountGramsOrMl": 15.0,
                                "isDefault": False
                        }
                ]
        },
        {
                "name": "Buttermilk / Chaas",
                "aliases": "buttermilk,chaas,chach,mattha,spiced buttermilk,amul masti buttermilk",
                "category": "Protein & Dairy",
                "basis": "PER_100ML",
                "kcalPer100": 29.0,
                "proteinPer100": 1.6,
                "carbsPer100": 2.4,
                "fatPer100": 1.5,
                "preparation": "NA",
                "densityGPerMl": 1.01,
                "source": "ESTIMATE",
                "notes": "Verify against OFF (Indian spiced chaas) / IFCT 2017",
                "servings": [
                        {
                                "label": "cup",
                                "amountGramsOrMl": 200.0,
                                "isDefault": True
                        },
                        {
                                "label": "packet",
                                "amountGramsOrMl": 200.0,
                                "isDefault": False
                        }
                ]
        },
        {
                "name": "Soy Chunks (Dry / Uncooked)",
                "aliases": "soy chunks,soya chunks,nutrela,meal maker,soya wadi,raw soy chunks",
                "category": "Protein & Dairy",
                "basis": "PER_100G",
                "kcalPer100": 345.0,
                "proteinPer100": 52.0,
                "carbsPer100": 33.0,
                "fatPer100": 0.5,
                "preparation": "RAW",
                "densityGPerMl": None,
                "source": "ESTIMATE",
                "notes": "Verify against OFF (Nutrela Soya Chunks per 100g dry weight)",
                "servings": [
                        {
                                "label": "katori",
                                "amountGramsOrMl": 50.0,
                                "isDefault": True
                        },
                        {
                                "label": "cup",
                                "amountGramsOrMl": 60.0,
                                "isDefault": False
                        }
                ]
        },
        {
                "name": "Soy Chunks (Boiled / Cooked)",
                "aliases": "boiled soy chunks,cooked soy chunks,boiled soya chunks,cooked soya chunks",
                "category": "Protein & Dairy",
                "basis": "PER_100G",
                "kcalPer100": 115.0,
                "proteinPer100": 17.3,
                "carbsPer100": 11.0,
                "fatPer100": 0.2,
                "preparation": "COOKED",
                "densityGPerMl": None,
                "source": "ESTIMATE",
                "notes": "Verify hydrated ~3x weight expansion of defatted soy chunks",
                "servings": [
                        {
                                "label": "katori",
                                "amountGramsOrMl": 120.0,
                                "isDefault": True
                        },
                        {
                                "label": "bowl",
                                "amountGramsOrMl": 150.0,
                                "isDefault": False
                        }
                ]
        },
        {
                "name": "Whole Egg (Boiled / Cooked)",
                "aliases": "egg,eggs,boiled egg,boiled eggs,anda,whole egg",
                "category": "Protein & Dairy",
                "basis": "PER_100G",
                "kcalPer100": 155.0,
                "proteinPer100": 12.6,
                "carbsPer100": 1.1,
                "fatPer100": 10.6,
                "preparation": "COOKED",
                "densityGPerMl": None,
                "source": "ESTIMATE",
                "notes": "Verify against USDA FDC (Egg, whole, cooked, hard-boiled) / IFCT 2017",
                "servings": [
                        {
                                "label": "piece",
                                "amountGramsOrMl": 50.0,
                                "isDefault": True
                        }
                ]
        },
        {
                "name": "Whole Egg (Raw)",
                "aliases": "raw egg,raw eggs",
                "category": "Protein & Dairy",
                "basis": "PER_100G",
                "kcalPer100": 143.0,
                "proteinPer100": 12.6,
                "carbsPer100": 0.7,
                "fatPer100": 9.5,
                "preparation": "RAW",
                "densityGPerMl": None,
                "source": "ESTIMATE",
                "notes": "Verify against IFCT 2017 (Egg, poultry, whole, raw M001) / USDA FDC",
                "servings": [
                        {
                                "label": "piece",
                                "amountGramsOrMl": 50.0,
                                "isDefault": True
                        }
                ]
        },
        {
                "name": "Whey Protein Powder",
                "aliases": "whey,whey protein,protein scoop,whey isolate,whey concentrate",
                "category": "Protein & Dairy",
                "basis": "PER_100G",
                "kcalPer100": 390.0,
                "proteinPer100": 78.0,
                "carbsPer100": 8.0,
                "fatPer100": 5.0,
                "preparation": "NA",
                "densityGPerMl": None,
                "source": "ESTIMATE",
                "notes": "Verify against typical whey protein supplement label",
                "servings": [
                        {
                                "label": "scoop",
                                "amountGramsOrMl": 30.0,
                                "isDefault": True
                        },
                        {
                                "label": "piece",
                                "amountGramsOrMl": 30.0,
                                "isDefault": False
                        }
                ]
        },
        {
                "name": "Chicken Breast (Cooked / Grilled)",
                "aliases": "chicken breast,cooked chicken breast,grilled chicken,boiled chicken",
                "category": "Protein & Dairy",
                "basis": "PER_100G",
                "kcalPer100": 165.0,
                "proteinPer100": 31.0,
                "carbsPer100": 0.0,
                "fatPer100": 3.6,
                "preparation": "COOKED",
                "densityGPerMl": None,
                "source": "ESTIMATE",
                "notes": "Verify against USDA FDC (Chicken, broilers or fryers, breast, meat only, cooked, roasted)",
                "servings": [
                        {
                                "label": "piece",
                                "amountGramsOrMl": 150.0,
                                "isDefault": True
                        }
                ]
        },
        {
                "name": "Chicken Breast (Raw)",
                "aliases": "raw chicken breast,uncooked chicken breast",
                "category": "Protein & Dairy",
                "basis": "PER_100G",
                "kcalPer100": 120.0,
                "proteinPer100": 22.5,
                "carbsPer100": 0.0,
                "fatPer100": 2.6,
                "preparation": "RAW",
                "densityGPerMl": None,
                "source": "ESTIMATE",
                "notes": "Verify against USDA FDC / IFCT 2017 (Chicken, breast, skinless, raw)",
                "servings": [
                        {
                                "label": "piece",
                                "amountGramsOrMl": 150.0,
                                "isDefault": True
                        }
                ]
        },
        {
                "name": "Peanut Butter (Unsweetened)",
                "aliases": "peanut butter,pb,natural peanut butter",
                "category": "Nuts & Healthy Fats",
                "basis": "PER_100G",
                "kcalPer100": 588.0,
                "proteinPer100": 25.8,
                "carbsPer100": 20.0,
                "fatPer100": 50.0,
                "preparation": "NA",
                "densityGPerMl": None,
                "source": "ESTIMATE",
                "notes": "Verify against USDA FDC (Peanut butter, smooth style)",
                "servings": [
                        {
                                "label": "tbsp",
                                "amountGramsOrMl": 16.0,
                                "isDefault": True
                        },
                        {
                                "label": "tsp",
                                "amountGramsOrMl": 5.3,
                                "isDefault": False
                        }
                ]
        },
        {
                "name": "Almonds (Raw / Badam)",
                "aliases": "almond,almonds,badam,soaked almonds",
                "category": "Nuts & Healthy Fats",
                "basis": "PER_100G",
                "kcalPer100": 579.0,
                "proteinPer100": 21.2,
                "carbsPer100": 21.6,
                "fatPer100": 49.9,
                "preparation": "RAW",
                "densityGPerMl": None,
                "source": "ESTIMATE",
                "notes": "Verify against IFCT 2017 (Almond G001) / USDA FDC",
                "servings": [
                        {
                                "label": "piece",
                                "amountGramsOrMl": 1.2,
                                "isDefault": True
                        },
                        {
                                "label": "tbsp",
                                "amountGramsOrMl": 10.0,
                                "isDefault": False
                        }
                ]
        },
        {
                "name": "Walnuts (Akhrot)",
                "aliases": "walnut,walnuts,akhrot",
                "category": "Nuts & Healthy Fats",
                "basis": "PER_100G",
                "kcalPer100": 654.0,
                "proteinPer100": 15.2,
                "carbsPer100": 13.7,
                "fatPer100": 65.2,
                "preparation": "RAW",
                "densityGPerMl": None,
                "source": "ESTIMATE",
                "notes": "Verify against IFCT 2017 (Walnut G020) / USDA FDC",
                "servings": [
                        {
                                "label": "piece",
                                "amountGramsOrMl": 4.0,
                                "isDefault": True
                        }
                ]
        },
        {
                "name": "Peanuts (Roasted / Moongphali)",
                "aliases": "peanut,peanuts,moongphali,groundnut,roasted peanuts",
                "category": "Nuts & Healthy Fats",
                "basis": "PER_100G",
                "kcalPer100": 567.0,
                "proteinPer100": 25.8,
                "carbsPer100": 16.1,
                "fatPer100": 49.2,
                "preparation": "COOKED",
                "densityGPerMl": None,
                "source": "ESTIMATE",
                "notes": "Verify against IFCT 2017 (Groundnut G009) / USDA FDC",
                "servings": [
                        {
                                "label": "tbsp",
                                "amountGramsOrMl": 10.0,
                                "isDefault": True
                        },
                        {
                                "label": "katori",
                                "amountGramsOrMl": 40.0,
                                "isDefault": False
                        }
                ]
        },
        {
                "name": "Desi Ghee",
                "aliases": "ghee,desi ghee,cow ghee,clarified butter",
                "category": "Nuts & Healthy Fats",
                "basis": "PER_100G",
                "kcalPer100": 900.0,
                "proteinPer100": 0.0,
                "carbsPer100": 0.0,
                "fatPer100": 99.8,
                "preparation": "NA",
                "densityGPerMl": 0.91,
                "source": "ESTIMATE",
                "notes": "Verify against IFCT 2017 (Ghee)",
                "servings": [
                        {
                                "label": "tsp",
                                "amountGramsOrMl": 5.0,
                                "isDefault": True
                        },
                        {
                                "label": "tbsp",
                                "amountGramsOrMl": 14.0,
                                "isDefault": False
                        }
                ]
        },
        {
                "name": "Banana (Ripe)",
                "aliases": "banana,bananas,kela,ripe banana",
                "category": "Fruits & Vegetables",
                "basis": "PER_100G",
                "kcalPer100": 89.0,
                "proteinPer100": 1.1,
                "carbsPer100": 22.8,
                "fatPer100": 0.3,
                "preparation": "RAW",
                "densityGPerMl": None,
                "source": "ESTIMATE",
                "notes": "Verify against USDA FDC (Bananas, raw) / IFCT 2017 (Banana, ripe E009)",
                "servings": [
                        {
                                "label": "piece",
                                "amountGramsOrMl": 118.0,
                                "isDefault": True
                        }
                ]
        },
        {
                "name": "Apple",
                "aliases": "apple,apples,seb",
                "category": "Fruits & Vegetables",
                "basis": "PER_100G",
                "kcalPer100": 52.0,
                "proteinPer100": 0.3,
                "carbsPer100": 13.8,
                "fatPer100": 0.2,
                "preparation": "RAW",
                "densityGPerMl": None,
                "source": "ESTIMATE",
                "notes": "Verify against USDA FDC (Apples, raw, with skin) / IFCT 2017",
                "servings": [
                        {
                                "label": "piece",
                                "amountGramsOrMl": 150.0,
                                "isDefault": True
                        }
                ]
        },
        {
                "name": "Potato (Boiled)",
                "aliases": "potato,boiled potato,aloo,boiled aloo",
                "category": "Fruits & Vegetables",
                "basis": "PER_100G",
                "kcalPer100": 87.0,
                "proteinPer100": 1.9,
                "carbsPer100": 20.1,
                "fatPer100": 0.1,
                "preparation": "COOKED",
                "densityGPerMl": None,
                "source": "ESTIMATE",
                "notes": "Verify against USDA FDC (Potatoes, boiled, cooked without skin) / IFCT 2017",
                "servings": [
                        {
                                "label": "piece",
                                "amountGramsOrMl": 135.0,
                                "isDefault": True
                        }
                ]
        },
        {
                "name": "Cucumber (Raw / Kheera)",
                "aliases": "cucumber,kheera,kakdi",
                "category": "Fruits & Vegetables",
                "basis": "PER_100G",
                "kcalPer100": 15.0,
                "proteinPer100": 0.7,
                "carbsPer100": 3.6,
                "fatPer100": 0.1,
                "preparation": "RAW",
                "densityGPerMl": None,
                "source": "ESTIMATE",
                "notes": "Verify against IFCT 2017 / USDA FDC",
                "servings": [
                        {
                                "label": "piece",
                                "amountGramsOrMl": 150.0,
                                "isDefault": True
                        }
                ]
        },
        {
                "name": "Palak / Spinach Sabzi (Cooked)",
                "aliases": "palak,spinach,cooked spinach,palak sabzi",
                "category": "Fruits & Vegetables",
                "basis": "PER_100G",
                "kcalPer100": 68.0,
                "proteinPer100": 3.1,
                "carbsPer100": 6.4,
                "fatPer100": 3.4,
                "preparation": "COOKED",
                "densityGPerMl": None,
                "source": "ESTIMATE",
                "notes": "Verify against IFCT 2017 (Spinach C033 cooked preparation)",
                "servings": [
                        {
                                "label": "katori",
                                "amountGramsOrMl": 140.0,
                                "isDefault": True
                        }
                ]
        },
        {
                "name": "Marie Biscuit",
                "aliases": "biscuit,biscuits,marie biscuit,marie gold,britannia marie",
                "category": "Snacks & Sweets",
                "basis": "PER_100G",
                "kcalPer100": 442.0,
                "proteinPer100": 7.8,
                "carbsPer100": 77.0,
                "fatPer100": 11.2,
                "preparation": "NA",
                "densityGPerMl": None,
                "source": "ESTIMATE",
                "notes": "Verify against Open Food Facts (Britannia Marie Gold)",
                "servings": [
                        {
                                "label": "piece",
                                "amountGramsOrMl": 6.0,
                                "isDefault": True
                        }
                ]
        },
        {
                "name": "Potato Chips (Salted)",
                "aliases": "chips,potato chips,lays,salted chips",
                "category": "Snacks & Sweets",
                "basis": "PER_100G",
                "kcalPer100": 536.0,
                "proteinPer100": 6.6,
                "carbsPer100": 52.8,
                "fatPer100": 34.0,
                "preparation": "NA",
                "densityGPerMl": None,
                "source": "ESTIMATE",
                "notes": "Verify against Open Food Facts (Lay's Classic Salted)",
                "servings": [
                        {
                                "label": "packet",
                                "amountGramsOrMl": 28.0,
                                "isDefault": True
                        },
                        {
                                "label": "katori",
                                "amountGramsOrMl": 25.0,
                                "isDefault": False
                        }
                ]
        },
        {
                "name": "Kurkure Masala Munch",
                "aliases": "kurkure,masala munch",
                "category": "Snacks & Sweets",
                "basis": "PER_100G",
                "kcalPer100": 554.0,
                "proteinPer100": 6.0,
                "carbsPer100": 55.6,
                "fatPer100": 34.2,
                "preparation": "NA",
                "densityGPerMl": None,
                "source": "ESTIMATE",
                "notes": "Verify against Open Food Facts (Kurkure Masala Munch)",
                "servings": [
                        {
                                "label": "packet",
                                "amountGramsOrMl": 30.0,
                                "isDefault": True
                        },
                        {
                                "label": "katori",
                                "amountGramsOrMl": 30.0,
                                "isDefault": False
                        }
                ]
        },
        {
                "name": "Aloo Bhujia / Namkeen",
                "aliases": "namkeen,bhujia,aloo bhujia,haldiram bhujia,sev,mixture",
                "category": "Snacks & Sweets",
                "basis": "PER_100G",
                "kcalPer100": 565.0,
                "proteinPer100": 9.5,
                "carbsPer100": 44.0,
                "fatPer100": 39.0,
                "preparation": "NA",
                "densityGPerMl": None,
                "source": "ESTIMATE",
                "notes": "Verify against Open Food Facts (Haldiram's Aloo Bhujia)",
                "servings": [
                        {
                                "label": "katori",
                                "amountGramsOrMl": 30.0,
                                "isDefault": True
                        },
                        {
                                "label": "tbsp",
                                "amountGramsOrMl": 10.0,
                                "isDefault": False
                        }
                ]
        },
        {
                "name": "Vanilla Ice Cream",
                "aliases": "ice cream,vanilla ice cream,amul ice cream",
                "category": "Snacks & Sweets",
                "basis": "PER_100G",
                "kcalPer100": 207.0,
                "proteinPer100": 3.5,
                "carbsPer100": 23.6,
                "fatPer100": 11.0,
                "preparation": "NA",
                "densityGPerMl": None,
                "source": "ESTIMATE",
                "notes": "Verify against USDA FDC / Open Food Facts (Amul Vanilla Ice Cream)",
                "servings": [
                        {
                                "label": "scoop",
                                "amountGramsOrMl": 65.0,
                                "isDefault": True
                        },
                        {
                                "label": "cup",
                                "amountGramsOrMl": 90.0,
                                "isDefault": False
                        }
                ]
        },
        {
                "name": "Gulab Jamun",
                "aliases": "gulab jamun,jamun,sweet",
                "category": "Snacks & Sweets",
                "basis": "PER_100G",
                "kcalPer100": 325.0,
                "proteinPer100": 4.8,
                "carbsPer100": 52.0,
                "fatPer100": 11.0,
                "preparation": "COOKED",
                "densityGPerMl": None,
                "source": "ESTIMATE",
                "notes": "Verify against Open Food Facts / NIN Indian sweets reference",
                "servings": [
                        {
                                "label": "piece",
                                "amountGramsOrMl": 45.0,
                                "isDefault": True
                        }
                ]
        }
]


def main() -> None:
    ASSETS_DIR.mkdir(parents=True, exist_ok=True)
    foods = build_seed_foods()

    json_path = ASSETS_DIR / "seed_foods.json"
    if json_path.exists():
        json_path.unlink()
    with json_path.open("w", encoding="utf-8") as f:
        json.dump(foods, f, indent=2, ensure_ascii=False)

    csv_path = ASSETS_DIR / "seed_foods.csv"
    if csv_path.exists():
        csv_path.unlink()
    with csv_path.open("w", encoding="utf-8", newline="") as f:
        writer = csv.writer(f)
        writer.writerow([
            "name",
            "aliases",
            "category",
            "basis",
            "kcalPer100",
            "proteinPer100",
            "carbsPer100",
            "fatPer100",
            "preparation",
            "densityGPerMl",
            "source",
            "defaultServing",
            "notes"
        ])
        for item in foods:
            servings = item.get("servings", [])
            default_srv = next((s for s in servings if s.get("isDefault")), servings[0] if servings else None)
            default_srv_str = f"{default_srv['label']}:{default_srv['amountGramsOrMl']}" if default_srv else ""
            writer.writerow([
                item["name"],
                item["aliases"],
                item["category"],
                item["basis"],
                item["kcalPer100"],
                item["proteinPer100"],
                item["carbsPer100"],
                item["fatPer100"],
                item["preparation"],
                item["densityGPerMl"] if item["densityGPerMl"] is not None else "",
                item["source"],
                default_srv_str,
                item.get("notes", "")
            ])

    print(f"Generated {len(foods)} essential foods in {json_path} and {csv_path}")


if __name__ == "__main__":
    main()
