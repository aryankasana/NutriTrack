package com.nutritrack.app.data.local

import android.content.Context
import androidx.room.Room
import androidx.sqlite.db.framework.FrameworkSQLiteOpenHelperFactory
import androidx.test.core.app.ApplicationProvider
import com.nutritrack.app.data.local.entity.FoodEntity
import com.nutritrack.app.data.local.entity.FoodEntryEntity
import com.nutritrack.app.data.local.entity.FoodServingEntity
import com.nutritrack.app.data.local.entity.NutritionTargetEntity
import com.nutritrack.app.domain.calculation.NutritionCalculator
import com.nutritrack.app.domain.model.FoodBasis
import com.nutritrack.app.domain.model.FoodSource
import com.nutritrack.app.domain.model.MealCategory
import com.nutritrack.app.domain.model.Preparation
import kotlinx.coroutines.test.runTest
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import java.io.File
import java.time.Instant
import java.time.LocalDate

/**
 * Room + Robolectric tests covering:
 * 1. Add one and many foods + servings
 * 2. Log entries, edit quantity (scaling), delete entry, and verify SQL SUM daily totals
 * 3. Query entries across different dates and verify effective date targets
 * 4. Custom food save/retrieve
 * 5. Deleting a custom food keeps its existing FoodEntry rows intact (ON DELETE SET NULL)
 * 6. Persistence across closing and reopening a file-backed Room database
 * 7. Schema migration test from version 1 to version 2 (MIGRATION_1_2)
 */
@RunWith(RobolectricTestRunner::class)
class NutriTrackRoomRobolectricTest {

    private lateinit var context: Context
    private lateinit var inMemoryDb: NutriTrackDatabase

    @Before
    fun setUp() {
        context = ApplicationProvider.getApplicationContext()
        inMemoryDb = Room.inMemoryDatabaseBuilder(context, NutriTrackDatabase::class.java)
            .allowMainThreadQueries()
            .build()
    }

    @After
    fun tearDown() {
        inMemoryDb.close()
    }

    @Test
    fun `add one and many foods, log entries across dates, edit and delete updates SQL SUM immediately`() = runTest {
        val foodDao = inMemoryDb.foodDao()
        val servingDao = inMemoryDb.foodServingDao()
        val entryDao = inMemoryDb.foodEntryDao()
        val targetDao = inMemoryDb.nutritionTargetDao()

        val rotiId = foodDao.insertFood(
            FoodEntity(
                name = "Whole Wheat Roti",
                aliases = "roti,chapati,phulka",
                category = "Breads",
                basis = FoodBasis.PER_100G,
                kcalPer100 = 297.0,
                proteinPer100 = 9.8,
                carbsPer100 = 60.5,
                fatPer100 = 1.7,
                preparation = Preparation.COOKED
            )
        )
        servingDao.insertServing(
            FoodServingEntity(foodId = rotiId, label = "roti", amountGramsOrMl = 35.0, isDefault = true)
        )

        val paneerId = foodDao.insertFood(
            FoodEntity(
                name = "Paneer (Raw)",
                aliases = "paneer",
                category = "Dairy",
                basis = FoodBasis.PER_100G,
                kcalPer100 = 296.0,
                proteinPer100 = 18.8,
                carbsPer100 = 4.5,
                fatPer100 = 22.5,
                preparation = Preparation.RAW
            )
        )

        val oct18 = LocalDate.of(2026, 10, 18)
        val oct19 = LocalDate.of(2026, 10, 19)

        targetDao.upsertTarget(
            NutritionTargetEntity(effectiveFrom = oct18, kcal = 2500.0, protein = 160.0)
        )

        val e1Id = entryDao.insertEntry(
            FoodEntryEntity(
                entryDate = oct19,
                loggedAt = Instant.parse("2026-10-19T08:00:00Z"),
                mealCategory = MealCategory.BREAKFAST,
                foodId = rotiId,
                foodNameSnapshot = "Whole Wheat Roti",
                quantity = 2.0,
                unit = "roti",
                amountGramsOrMl = 70.0,
                kcal = 207.9,
                protein = 6.86,
                carbs = 42.35,
                fat = 1.19,
                sourceSnapshot = FoodSource.ESTIMATE
            )
        )
        val e2Id = entryDao.insertEntry(
            FoodEntryEntity(
                entryDate = oct19,
                loggedAt = Instant.parse("2026-10-19T13:00:00Z"),
                mealCategory = MealCategory.LUNCH,
                foodId = paneerId,
                foodNameSnapshot = "Paneer (Raw)",
                quantity = 100.0,
                unit = "g",
                amountGramsOrMl = 100.0,
                kcal = 296.0,
                protein = 18.8,
                carbs = 4.5,
                fat = 22.5,
                sourceSnapshot = FoodSource.ESTIMATE
            )
        )

        // Log on previous date to verify date isolation
        entryDao.insertEntry(
            FoodEntryEntity(
                entryDate = oct18,
                loggedAt = Instant.parse("2026-10-18T20:00:00Z"),
                mealCategory = MealCategory.DINNER,
                foodId = paneerId,
                foodNameSnapshot = "Paneer (Raw)",
                quantity = 200.0,
                unit = "g",
                amountGramsOrMl = 200.0,
                kcal = 592.0,
                protein = 37.6,
                carbs = 9.0,
                fat = 45.0,
                sourceSnapshot = FoodSource.ESTIMATE
            )
        )

        val totalsOct19 = entryDao.getDailyTotals(oct19)
        assertEquals(2, totalsOct19.entryCount)
        assertEquals(503.9, totalsOct19.totalKcal, 1e-4)

        // Edit quantity of e1 from 2 rotis (70g) to 3 rotis (105g)
        val existingE1 = entryDao.getEntryById(e1Id)!!
        val scaledE1 = NutritionCalculator.scaleEntryByAmount(existingE1, 3.0, "roti", 105.0)
        entryDao.updateEntry(scaledE1)

        val updatedTotalsOct19 = entryDao.getDailyTotals(oct19)
        assertEquals(311.85 + 296.0, updatedTotalsOct19.totalKcal, 1e-4)

        // Delete e2 and verify SQL SUM updates immediately
        entryDao.deleteEntryById(e2Id)
        val afterDeleteTotals = entryDao.getDailyTotals(oct19)
        assertEquals(1, afterDeleteTotals.entryCount)
        assertEquals(311.85, afterDeleteTotals.totalKcal, 1e-4)
    }

    @Test
    fun `deleting a custom food keeps its existing FoodEntry rows intact via ON DELETE SET NULL`() = runTest {
        val foodDao = inMemoryDb.foodDao()
        val entryDao = inMemoryDb.foodEntryDao()

        val customFoodId = foodDao.insertFood(
            FoodEntity(
                name = "Mom's Special Pinni",
                aliases = "pinni,alsi pinni",
                category = "Custom",
                basis = FoodBasis.PER_100G,
                kcalPer100 = 460.0,
                proteinPer100 = 9.5,
                carbsPer100 = 52.0,
                fatPer100 = 24.0,
                source = FoodSource.USER,
                isCustom = true
            )
        )

        val date = LocalDate.of(2026, 10, 19)
        val entryId = entryDao.insertEntry(
            FoodEntryEntity(
                entryDate = date,
                loggedAt = Instant.now(),
                mealCategory = MealCategory.EVENING_SNACK,
                foodId = customFoodId,
                foodNameSnapshot = "Mom's Special Pinni",
                quantity = 50.0,
                unit = "g",
                amountGramsOrMl = 50.0,
                kcal = 230.0,
                protein = 4.75,
                carbs = 26.0,
                fat = 12.0,
                sourceSnapshot = FoodSource.USER
            )
        )

        // Delete custom food
        foodDao.deleteFoodById(customFoodId)
        assertNull(foodDao.getFoodWithServingsById(customFoodId))

        // Verify entry still exists with foodId = null and unchanged nutrition snapshot
        val survivingEntry = entryDao.getEntryById(entryId)
        assertNotNull(survivingEntry)
        assertNull(survivingEntry!!.foodId)
        assertEquals("Mom's Special Pinni", survivingEntry.foodNameSnapshot)
        assertEquals(230.0, survivingEntry.kcal, 1e-6)
        assertEquals(4.75, survivingEntry.protein, 1e-6)
    }

    @Test
    fun `file-backed database persists entries across close and reopen`() = runTest {
        val dbFile = File(context.cacheDir, "test_persistence_nutritrack.db")
        if (dbFile.exists()) dbFile.delete()

        val db1 = Room.databaseBuilder(context, NutriTrackDatabase::class.java, dbFile.absolutePath)
            .allowMainThreadQueries()
            .build()

        val date = LocalDate.of(2026, 10, 19)
        db1.foodEntryDao().insertEntry(
            FoodEntryEntity(
                entryDate = date,
                loggedAt = Instant.parse("2026-10-19T10:00:00Z"),
                mealCategory = MealCategory.POST_WORKOUT,
                foodId = null,
                foodNameSnapshot = "Whey Shake",
                quantity = 1.0,
                unit = "scoop",
                amountGramsOrMl = 30.0,
                kcal = 120.0,
                protein = 24.0,
                carbs = 3.0,
                fat = 1.5,
                sourceSnapshot = FoodSource.USER
            )
        )
        db1.close()

        val db2 = Room.databaseBuilder(context, NutriTrackDatabase::class.java, dbFile.absolutePath)
            .allowMainThreadQueries()
            .build()
        val totals = db2.foodEntryDao().getDailyTotals(date)
        assertEquals(1, totals.entryCount)
        assertEquals(120.0, totals.totalKcal, 1e-6)
        assertEquals(24.0, totals.totalProtein, 1e-6)
        db2.close()
        dbFile.delete()
    }

    @Test
    fun `migration 1 to 2 adds barcode and notes columns while preserving existing foods`() {
        val helper = FrameworkSQLiteOpenHelperFactory()
        val dbFile = File(context.cacheDir, "test_migration_1_2.db")
        if (dbFile.exists()) dbFile.delete()

        val sqLiteDb = android.database.sqlite.SQLiteDatabase.openOrCreateDatabase(dbFile, null)
        sqLiteDb.execSQL(
            """
            CREATE TABLE IF NOT EXISTS `foods` (
                `id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                `name` TEXT NOT NULL,
                `aliases` TEXT NOT NULL,
                `category` TEXT NOT NULL,
                `basis` TEXT NOT NULL,
                `kcalPer100` REAL NOT NULL,
                `proteinPer100` REAL NOT NULL,
                `carbsPer100` REAL NOT NULL,
                `fatPer100` REAL NOT NULL,
                `preparation` TEXT NOT NULL,
                `densityGPerMl` REAL,
                `source` TEXT NOT NULL,
                `isCustom` INTEGER NOT NULL
            )
            """.trimIndent()
        )
        sqLiteDb.execSQL(
            """
            INSERT INTO `foods` (`id`, `name`, `aliases`, `category`, `basis`, `kcalPer100`, `proteinPer100`, `carbsPer100`, `fatPer100`, `preparation`, `densityGPerMl`, `source`, `isCustom`)
            VALUES (1, 'Whole Wheat Roti', 'roti,chapati', 'Breads', 'PER_100G', 297.0, 9.8, 60.5, 1.7, 'COOKED', NULL, 'ESTIMATE', 0)
            """.trimIndent()
        )
        // Execute MIGRATION_1_2 SQL statements
        sqLiteDb.execSQL("ALTER TABLE `foods` ADD COLUMN `barcode` TEXT DEFAULT NULL")
        sqLiteDb.execSQL("ALTER TABLE `foods` ADD COLUMN `notes` TEXT DEFAULT NULL")
        sqLiteDb.execSQL("CREATE INDEX IF NOT EXISTS `index_foods_barcode` ON `foods` (`barcode`)")

        val cursor = sqLiteDb.rawQuery("SELECT name, kcalPer100, barcode, notes FROM foods WHERE id = 1", null)
        assertEquals(true, cursor.moveToFirst())
        assertEquals("Whole Wheat Roti", cursor.getString(0))
        assertEquals(297.0, cursor.getDouble(1), 1e-6)
        assertEquals(true, cursor.isNull(2))
        assertEquals(true, cursor.isNull(3))
        cursor.close()
        sqLiteDb.close()
        dbFile.delete()
    }
}
