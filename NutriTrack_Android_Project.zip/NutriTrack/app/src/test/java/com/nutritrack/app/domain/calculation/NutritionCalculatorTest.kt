package com.nutritrack.app.domain.calculation

import com.nutritrack.app.data.local.entity.FoodEntity
import com.nutritrack.app.data.local.entity.FoodEntryEntity
import com.nutritrack.app.data.local.entity.FoodServingEntity
import com.nutritrack.app.domain.model.FoodBasis
import com.nutritrack.app.domain.model.FoodSource
import com.nutritrack.app.domain.model.MealCategory
import com.nutritrack.app.domain.model.Preparation
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.Instant
import java.time.LocalDate

class NutritionCalculatorTest {

    private val paneerFood = FoodEntity(
        id = 1L,
        name = "Paneer (Raw)",
        aliases = "cottage cheese,indian paneer",
        category = "Dairy & Paneer",
        basis = FoodBasis.PER_100G,
        kcalPer100 = 296.0,
        proteinPer100 = 18.8,
        carbsPer100 = 4.5,
        fatPer100 = 22.5,
        preparation = Preparation.RAW,
        source = FoodSource.ESTIMATE
    )

    private val rotiFood = FoodEntity(
        id = 2L,
        name = "Whole Wheat Roti",
        aliases = "chapati,phulka,roti",
        category = "Breads & Grains",
        basis = FoodBasis.PER_100G,
        kcalPer100 = 297.0,
        proteinPer100 = 9.8,
        carbsPer100 = 60.5,
        fatPer100 = 1.7,
        preparation = Preparation.COOKED,
        source = FoodSource.ESTIMATE
    )

    private val rotiServings = listOf(
        FoodServingEntity(
            id = 10L,
            foodId = 2L,
            label = "roti",
            amountGramsOrMl = 35.0,
            isDefault = true
        )
    )

    @Test
    fun `required fixture - target 2500 kcal with Food A and Food B produces 500 kcal 30P 55C 16F and 2000 remaining`() {
        val foodA = FoodEntity(
            id = 101L,
            name = "Food A",
            category = "Test",
            basis = FoodBasis.PER_100G,
            kcalPer100 = 200.0,
            proteinPer100 = 10.0,
            carbsPer100 = 25.0,
            fatPer100 = 6.0
        )
        val foodB = FoodEntity(
            id = 102L,
            name = "Food B",
            category = "Test",
            basis = FoodBasis.PER_100G,
            kcalPer100 = 300.0,
            proteinPer100 = 20.0,
            carbsPer100 = 30.0,
            fatPer100 = 10.0
        )

        val calcA = NutritionCalculator.computeFromAmount(foodA, 100.0)
        val calcB = NutritionCalculator.computeFromAmount(foodB, 100.0)

        val totalKcal = calcA.kcal + calcB.kcal
        val totalProtein = calcA.protein + calcB.protein
        val totalCarbs = calcA.carbs + calcB.carbs
        val totalFat = calcA.fat + calcB.fat

        val summary = NutritionCalculator.buildDailySummary(
            totalKcal = totalKcal,
            totalProtein = totalProtein,
            totalCarbs = totalCarbs,
            totalFat = totalFat,
            entryCount = 2,
            targetKcal = 2500.0,
            targetProtein = 160.0,
            targetCarbs = 280.0,
            targetFat = 70.0
        )

        assertEquals(500.0, summary.kcal.consumed, 1e-6)
        assertEquals(30.0, summary.protein.consumed, 1e-6)
        assertEquals(55.0, summary.carbs.consumed, 1e-6)
        assertEquals(16.0, summary.fat.consumed, 1e-6)
        assertEquals(2000.0, summary.kcal.remaining!!, 1e-6)
        assertFalse(summary.kcal.isOverTarget)
        assertEquals("2000 kcal remaining", NutritionCalculator.formatRemainingLabel(summary.kcal, isKcal = true))
    }

    @Test
    fun `decimal quantities 0_5 1_25 and 2_75 calculate accurately in Double and round only for display`() {
        val convHalf = NutritionCalculator.resolveAmountGramsOrMl(rotiFood, rotiServings, 0.5, "roti")
        assertTrue(convHalf is UnitConversionResult.Success)
        val amtHalf = (convHalf as UnitConversionResult.Success).amountGramsOrMl
        assertEquals(17.5, amtHalf, 1e-6)
        val nutHalf = NutritionCalculator.computeFromAmount(rotiFood, amtHalf)
        assertEquals(297.0 * 0.175, nutHalf.kcal, 1e-6)
        assertEquals("52", NutritionCalculator.formatKcal(nutHalf.kcal))

        val conv125 = NutritionCalculator.resolveAmountGramsOrMl(rotiFood, rotiServings, 1.25, "roti")
        val amt125 = (conv125 as UnitConversionResult.Success).amountGramsOrMl
        assertEquals(43.75, amt125, 1e-6)
        val nut125 = NutritionCalculator.computeFromAmount(rotiFood, amt125)
        assertEquals(297.0 * 0.4375, nut125.kcal, 1e-6)
        assertEquals("4.3", NutritionCalculator.formatMacro(nut125.protein))

        val conv275 = NutritionCalculator.resolveAmountGramsOrMl(rotiFood, rotiServings, 2.75, "roti")
        val amt275 = (conv275 as UnitConversionResult.Success).amountGramsOrMl
        assertEquals(96.25, amt275, 1e-6)
        val nut275 = NutritionCalculator.computeFromAmount(rotiFood, amt275)
        assertEquals(297.0 * 0.9625, nut275.kcal, 1e-6)
    }

    @Test
    fun `overage shows negative remaining and Over by X label clearly`() {
        val progress = NutritionCalculator.computeNutrientProgress(consumed = 2740.0, target = 2500.0)
        assertTrue(progress.isOverTarget)
        assertEquals(-240.0, progress.remaining!!, 1e-6)
        assertEquals(240.0, progress.overageAmount, 1e-6)
        assertEquals(1.0f, progress.progressFraction!!, 1e-5f)
        assertEquals("Over by 240 kcal", NutritionCalculator.formatRemainingLabel(progress, isKcal = true))
    }

    @Test
    fun `unset target returns null remaining and null progressFraction`() {
        val progress = NutritionCalculator.computeNutrientProgress(consumed = 180.0, target = null)
        assertNull(progress.target)
        assertNull(progress.remaining)
        assertNull(progress.progressFraction)
        assertFalse(progress.isOverTarget)
        assertEquals("No target set", NutritionCalculator.formatRemainingLabel(progress, isKcal = false))
    }

    @Test
    fun `missing household serving returns MissingServingWeight and never guesses`() {
        val result = NutritionCalculator.resolveAmountGramsOrMl(
            food = paneerFood,
            servings = emptyList(),
            quantity = 1.0,
            rawUnit = "katori"
        )
        assertTrue(result is UnitConversionResult.MissingServingWeight)
        val missing = result as UnitConversionResult.MissingServingWeight
        assertEquals("katori", missing.requestedUnit)
        assertEquals(paneerFood.id, missing.foodId)
    }

    @Test
    fun `editing quantity scales stored entry nutrition by newAmount over oldAmount`() {
        val initial = FoodEntryEntity(
            id = 5L,
            entryDate = LocalDate.of(2026, 10, 19),
            loggedAt = Instant.now(),
            mealCategory = MealCategory.LUNCH,
            foodId = paneerFood.id,
            foodNameSnapshot = paneerFood.name,
            quantity = 100.0,
            unit = "g",
            amountGramsOrMl = 100.0,
            kcal = 296.0,
            protein = 18.8,
            carbs = 4.5,
            fat = 22.5,
            sourceSnapshot = FoodSource.ESTIMATE
        )

        val scaled = NutritionCalculator.scaleEntryByAmount(
            entry = initial,
            newQuantity = 150.0,
            newUnit = "g",
            newAmountGramsOrMl = 150.0
        )

        assertEquals(444.0, scaled.kcal, 1e-6)
        assertEquals(28.2, scaled.protein, 1e-6)
        assertEquals(6.75, scaled.carbs, 1e-6)
        assertEquals(33.75, scaled.fat, 1e-6)
    }
}
