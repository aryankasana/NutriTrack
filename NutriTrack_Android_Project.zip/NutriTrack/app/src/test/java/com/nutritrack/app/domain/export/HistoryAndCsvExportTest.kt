package com.nutritrack.app.domain.export

import com.nutritrack.app.data.local.dao.DatedNutritionTotalsTuple
import com.nutritrack.app.data.local.entity.FoodEntryEntity
import com.nutritrack.app.domain.calculation.HistoryAnalyzer
import com.nutritrack.app.domain.model.FoodSource
import com.nutritrack.app.domain.model.MealCategory
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneOffset

class HistoryAndCsvExportTest {

    @Test
    fun `unlogged days show hasData false and are excluded from period averages`() {
        val start = LocalDate.of(2026, 10, 13)
        val end = LocalDate.of(2026, 10, 19)

        val logged = listOf(
            DatedNutritionTotalsTuple(
                entryDate = LocalDate.of(2026, 10, 14),
                totalKcal = 2200.0,
                totalProtein = 150.0,
                totalCarbs = 240.0,
                totalFat = 70.0,
                entryCount = 4
            ),
            DatedNutritionTotalsTuple(
                entryDate = LocalDate.of(2026, 10, 18),
                totalKcal = 2600.0,
                totalProtein = 170.0,
                totalCarbs = 280.0,
                totalFat = 80.0,
                entryCount = 5
            )
        )

        val series = HistoryAnalyzer.buildDailySeries(start, end, logged)
        assertEquals(7, series.size)

        val unloggedOct13 = series.first { it.date == LocalDate.of(2026, 10, 13) }
        assertFalse(unloggedOct13.hasData)
        assertNull(unloggedOct13.totalKcal)

        val loggedOct14 = series.first { it.date == LocalDate.of(2026, 10, 14) }
        assertTrue(loggedOct14.hasData)
        assertEquals(2200.0, loggedOct14.totalKcal!!, 1e-6)

        val averages = HistoryAnalyzer.computeLoggedDayAverages(start, end, logged)
        assertEquals(2, averages.loggedDaysCount)
        assertEquals(7, averages.totalWindowDays)
        assertEquals(2400.0, averages.averageKcal!!, 1e-6)
        assertEquals(160.0, averages.averageProtein!!, 1e-6)
    }

    @Test
    fun `csv exporter produces required header and escapes commas properly`() {
        val entry = FoodEntryEntity(
            id = 1L,
            entryDate = LocalDate.of(2026, 10, 19),
            loggedAt = Instant.parse("2026-10-19T08:30:00Z"),
            mealCategory = MealCategory.BREAKFAST,
            foodId = 10L,
            foodNameSnapshot = "Toor / Arhar Dal, Cooked",
            quantity = 1.5,
            unit = "katori",
            amountGramsOrMl = 225.0,
            kcal = 265.5,
            protein = 13.95,
            carbs = 39.375,
            fat = 5.85,
            sourceSnapshot = FoodSource.ESTIMATE
        )

        val csv = CsvExporter.formatEntriesToCsv(listOf(entry), ZoneOffset.UTC)
        val lines = csv.trim().lines()
        assertEquals(2, lines.size)
        assertEquals("date,time,meal,food,quantity,unit,kcal,P,C,F,source", lines[0])
        assertEquals(
            "2026-10-19,08:30:00,Breakfast,\"Toor / Arhar Dal, Cooked\",1.5,katori,265.5,14.0,39.4,5.9,ESTIMATE",
            lines[1]
        )
    }
}
