package com.nutritrack.app.domain.parser

import com.nutritrack.app.data.local.entity.FoodEntity
import com.nutritrack.app.data.local.entity.FoodServingEntity
import com.nutritrack.app.data.local.entity.FoodWithServings
import com.nutritrack.app.domain.model.FoodBasis
import com.nutritrack.app.domain.model.FoodSource
import com.nutritrack.app.domain.model.Preparation
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test

class QuickAddParserTest {

    private lateinit var testCatalog: List<FoodWithServings>

    @Before
    fun setUp() {
        testCatalog = listOf(
            FoodWithServings(
                food = FoodEntity(
                    id = 1L,
                    name = "Whole Wheat Roti",
                    aliases = "roti,chapati,phulka",
                    category = "Breads & Rotis",
                    basis = FoodBasis.PER_100G,
                    kcalPer100 = 297.0,
                    proteinPer100 = 9.8,
                    carbsPer100 = 60.5,
                    fatPer100 = 1.7,
                    preparation = Preparation.COOKED,
                    source = FoodSource.ESTIMATE
                ),
                servings = listOf(
                    FoodServingEntity(id = 1L, foodId = 1L, label = "roti", amountGramsOrMl = 35.0, isDefault = true),
                    FoodServingEntity(id = 2L, foodId = 1L, label = "piece", amountGramsOrMl = 35.0, isDefault = false)
                )
            ),
            FoodWithServings(
                food = FoodEntity(
                    id = 2L,
                    name = "Milk (Toned / Cow Milk)",
                    aliases = "milk,toned milk,cow milk,doodh",
                    category = "Protein & Dairy",
                    basis = FoodBasis.PER_100ML,
                    kcalPer100 = 62.0,
                    proteinPer100 = 3.2,
                    carbsPer100 = 4.8,
                    fatPer100 = 3.2,
                    preparation = Preparation.NA,
                    densityGPerMl = 1.03,
                    source = FoodSource.ESTIMATE
                ),
                servings = listOf(
                    FoodServingEntity(id = 3L, foodId = 2L, label = "cup", amountGramsOrMl = 200.0, isDefault = true)
                )
            ),
            FoodWithServings(
                food = FoodEntity(
                    id = 3L,
                    name = "Banana (Ripe)",
                    aliases = "banana,bananas,kela",
                    category = "Fruits & Vegetables",
                    basis = FoodBasis.PER_100G,
                    kcalPer100 = 89.0,
                    proteinPer100 = 1.1,
                    carbsPer100 = 22.8,
                    fatPer100 = 0.3,
                    preparation = Preparation.RAW,
                    source = FoodSource.ESTIMATE
                ),
                servings = listOf(
                    FoodServingEntity(id = 4L, foodId = 3L, label = "piece", amountGramsOrMl = 118.0, isDefault = true)
                )
            ),
            FoodWithServings(
                food = FoodEntity(
                    id = 4L,
                    name = "Paneer (Raw)",
                    aliases = "paneer,raw paneer,cottage cheese",
                    category = "Protein & Dairy",
                    basis = FoodBasis.PER_100G,
                    kcalPer100 = 296.0,
                    proteinPer100 = 18.8,
                    carbsPer100 = 4.5,
                    fatPer100 = 22.5,
                    preparation = Preparation.RAW,
                    source = FoodSource.ESTIMATE
                ),
                servings = listOf(
                    FoodServingEntity(id = 5L, foodId = 4L, label = "katori", amountGramsOrMl = 100.0, isDefault = true)
                )
            ),
            FoodWithServings(
                food = FoodEntity(
                    id = 5L,
                    name = "Toor / Arhar Dal (Cooked)",
                    aliases = "dal,toor dal,arhar dal,yellow dal,cooked dal",
                    category = "Dals & Legumes",
                    basis = FoodBasis.PER_100G,
                    kcalPer100 = 118.0,
                    proteinPer100 = 6.2,
                    carbsPer100 = 17.5,
                    fatPer100 = 2.6,
                    preparation = Preparation.COOKED,
                    source = FoodSource.ESTIMATE
                ),
                servings = listOf(
                    FoodServingEntity(id = 6L, foodId = 5L, label = "katori", amountGramsOrMl = 150.0, isDefault = true),
                    FoodServingEntity(id = 7L, foodId = 5L, label = "bowl", amountGramsOrMl = 200.0, isDefault = false)
                )
            ),
            FoodWithServings(
                food = FoodEntity(
                    id = 6L,
                    name = "Curd / Dahi",
                    aliases = "curd,dahi,yogurt",
                    category = "Protein & Dairy",
                    basis = FoodBasis.PER_100G,
                    kcalPer100 = 61.0,
                    proteinPer100 = 3.5,
                    carbsPer100 = 4.7,
                    fatPer100 = 3.3,
                    preparation = Preparation.NA,
                    densityGPerMl = 1.03,
                    source = FoodSource.ESTIMATE
                ),
                servings = listOf(
                    FoodServingEntity(id = 8L, foodId = 6L, label = "katori", amountGramsOrMl = 150.0, isDefault = true),
                    FoodServingEntity(id = 9L, foodId = 6L, label = "cup", amountGramsOrMl = 200.0, isDefault = false)
                )
            ),
            FoodWithServings(
                food = FoodEntity(
                    id = 7L,
                    name = "Rolled Oats (Raw)",
                    aliases = "oats,raw oats,rolled oats",
                    category = "Rice & Grains",
                    basis = FoodBasis.PER_100G,
                    kcalPer100 = 379.0,
                    proteinPer100 = 13.2,
                    carbsPer100 = 67.7,
                    fatPer100 = 6.5,
                    preparation = Preparation.RAW,
                    source = FoodSource.ESTIMATE
                ),
                servings = listOf(
                    FoodServingEntity(id = 10L, foodId = 7L, label = "cup", amountGramsOrMl = 80.0, isDefault = true)
                )
            ),
            FoodWithServings(
                food = FoodEntity(
                    id = 8L,
                    name = "Whole Egg (Boiled / Cooked)",
                    aliases = "egg,eggs,boiled egg,boiled eggs,anda",
                    category = "Protein & Dairy",
                    basis = FoodBasis.PER_100G,
                    kcalPer100 = 155.0,
                    proteinPer100 = 12.6,
                    carbsPer100 = 1.1,
                    fatPer100 = 10.6,
                    preparation = Preparation.COOKED,
                    source = FoodSource.ESTIMATE
                ),
                servings = listOf(
                    FoodServingEntity(id = 11L, foodId = 8L, label = "piece", amountGramsOrMl = 50.0, isDefault = true)
                )
            ),
            FoodWithServings(
                food = FoodEntity(
                    id = 9L,
                    name = "Bread (Whole Wheat / Brown)",
                    aliases = "bread,brown bread,wheat bread,bread slice,bread slices",
                    category = "Breads & Rotis",
                    basis = FoodBasis.PER_100G,
                    kcalPer100 = 252.0,
                    proteinPer100 = 9.5,
                    carbsPer100 = 46.5,
                    fatPer100 = 3.0,
                    preparation = Preparation.NA,
                    source = FoodSource.ESTIMATE
                ),
                servings = listOf(
                    FoodServingEntity(id = 12L, foodId = 9L, label = "slice", amountGramsOrMl = 28.0, isDefault = true)
                )
            ),
            FoodWithServings(
                food = FoodEntity(
                    id = 10L,
                    name = "White Rice (Cooked)",
                    aliases = "rice,cooked rice,steamed rice,chawal",
                    category = "Rice & Grains",
                    basis = FoodBasis.PER_100G,
                    kcalPer100 = 130.0,
                    proteinPer100 = 2.7,
                    carbsPer100 = 28.2,
                    fatPer100 = 0.3,
                    preparation = Preparation.COOKED,
                    source = FoodSource.ESTIMATE
                ),
                servings = listOf(
                    FoodServingEntity(id = 13L, foodId = 10L, label = "katori", amountGramsOrMl = 130.0, isDefault = true)
                )
            ),
            FoodWithServings(
                food = FoodEntity(
                    id = 11L,
                    name = "White Rice (Raw)",
                    aliases = "raw rice,uncooked rice",
                    category = "Rice & Grains",
                    basis = FoodBasis.PER_100G,
                    kcalPer100 = 356.0,
                    proteinPer100 = 7.8,
                    carbsPer100 = 78.2,
                    fatPer100 = 0.5,
                    preparation = Preparation.RAW,
                    source = FoodSource.ESTIMATE
                ),
                servings = listOf(
                    FoodServingEntity(id = 14L, foodId = 11L, label = "katori", amountGramsOrMl = 100.0, isDefault = true)
                )
            ),
            FoodWithServings(
                food = FoodEntity(
                    id = 12L,
                    name = "Rajma / Kidney Beans (Cooked)",
                    aliases = "rajma,cooked rajma,kidney beans",
                    category = "Dals & Legumes",
                    basis = FoodBasis.PER_100G,
                    kcalPer100 = 140.0,
                    proteinPer100 = 7.8,
                    carbsPer100 = 20.4,
                    fatPer100 = 3.0,
                    preparation = Preparation.COOKED,
                    source = FoodSource.ESTIMATE
                ),
                servings = listOf(
                    FoodServingEntity(id = 15L, foodId = 12L, label = "katori", amountGramsOrMl = 150.0, isDefault = true)
                )
            )
        )
    }

    @Test
    fun `input 1 - 3 roti, 200 ml milk, 1 banana, 100 g paneer`() {
        val result = QuickAddParser.parseBatch("3 roti, 200 ml milk, 1 banana, 100 g paneer", testCatalog)
        assertEquals(4, result.size)

        assertEquals(ParsedItemStatus.MATCHED, result[0].status)
        assertEquals(3.0, result[0].quantity, 1e-6)
        assertEquals("Whole Wheat Roti", result[0].matchedFood?.food?.name)
        assertEquals(105.0, result[0].computedNutrition!!.amountGramsOrMl, 1e-6)

        assertEquals(ParsedItemStatus.MATCHED, result[1].status)
        assertEquals(200.0, result[1].quantity, 1e-6)
        assertEquals("ml", result[1].parsedUnit)
        assertEquals("Milk (Toned / Cow Milk)", result[1].matchedFood?.food?.name)
        assertEquals(124.0, result[1].computedNutrition!!.kcal, 1e-6)

        assertEquals(ParsedItemStatus.MATCHED, result[2].status)
        assertEquals(1.0, result[2].quantity, 1e-6)
        assertEquals("Banana (Ripe)", result[2].matchedFood?.food?.name)

        assertEquals(ParsedItemStatus.MATCHED, result[3].status)
        assertEquals(100.0, result[3].quantity, 1e-6)
        assertEquals("g", result[3].parsedUnit)
        assertEquals("Paneer (Raw)", result[3].matchedFood?.food?.name)
        assertEquals(296.0, result[3].computedNutrition!!.kcal, 1e-6)
    }

    @Test
    fun `input 2 - 2 roti, 1 bowl dal, 200g curd`() {
        val result = QuickAddParser.parseBatch("2 roti, 1 bowl dal, 200g curd", testCatalog)
        assertEquals(3, result.size)

        assertEquals(2.0, result[0].quantity, 1e-6)
        assertEquals("Whole Wheat Roti", result[0].matchedFood?.food?.name)

        assertEquals(1.0, result[1].quantity, 1e-6)
        assertEquals("bowl", result[1].parsedUnit)
        assertEquals("Toor / Arhar Dal (Cooked)", result[1].matchedFood?.food?.name)
        assertEquals(200.0, result[1].computedNutrition!!.amountGramsOrMl, 1e-6)

        assertEquals(200.0, result[2].quantity, 1e-6)
        assertEquals("g", result[2].parsedUnit)
        assertEquals("Curd / Dahi", result[2].matchedFood?.food?.name)
    }

    @Test
    fun `input 3 - 250ml milk, 40g oats, 1 banana`() {
        val result = QuickAddParser.parseBatch("250ml milk, 40g oats, 1 banana", testCatalog)
        assertEquals(3, result.size)

        assertEquals(250.0, result[0].quantity, 1e-6)
        assertEquals("ml", result[0].parsedUnit)
        assertEquals("Milk (Toned / Cow Milk)", result[0].matchedFood?.food?.name)

        assertEquals(40.0, result[1].quantity, 1e-6)
        assertEquals("g", result[1].parsedUnit)
        assertEquals("Rolled Oats (Raw)", result[1].matchedFood?.food?.name)

        assertEquals(1.0, result[2].quantity, 1e-6)
        assertEquals("Banana (Ripe)", result[2].matchedFood?.food?.name)
    }

    @Test
    fun `input 4 - 3 eggs, 2 bread slices`() {
        val result = QuickAddParser.parseBatch("3 eggs, 2 bread slices", testCatalog)
        assertEquals(2, result.size)

        assertEquals(3.0, result[0].quantity, 1e-6)
        assertEquals("Whole Egg (Boiled / Cooked)", result[0].matchedFood?.food?.name)
        assertEquals(150.0, result[0].computedNutrition!!.amountGramsOrMl, 1e-6)

        assertEquals(2.0, result[1].quantity, 1e-6)
        assertEquals("slice", result[1].resolvedUnit)
        assertEquals("Bread (Whole Wheat / Brown)", result[1].matchedFood?.food?.name)
        assertEquals(56.0, result[1].computedNutrition!!.amountGramsOrMl, 1e-6)
    }

    @Test
    fun `input 5 - 100g cooked rice, 150g paneer`() {
        val result = QuickAddParser.parseBatch("100g cooked rice, 150g paneer", testCatalog)
        assertEquals(2, result.size)

        assertEquals(100.0, result[0].quantity, 1e-6)
        assertEquals(Preparation.COOKED, result[0].preparationHint)
        assertEquals("White Rice (Cooked)", result[0].matchedFood?.food?.name)
        assertEquals(130.0, result[0].computedNutrition!!.kcal, 1e-6)

        assertEquals(150.0, result[1].quantity, 1e-6)
        assertEquals("Paneer (Raw)", result[1].matchedFood?.food?.name)
        assertEquals(444.0, result[1].computedNutrition!!.kcal, 1e-6)
    }

    @Test
    fun `input 6 - 1_5 katori rajma`() {
        val result = QuickAddParser.parseBatch("1.5 katori rajma", testCatalog)
        assertEquals(1, result.size)
        assertEquals(1.5, result[0].quantity, 1e-6)
        assertEquals("katori", result[0].parsedUnit)
        assertEquals("Rajma / Kidney Beans (Cooked)", result[0].matchedFood?.food?.name)
        assertEquals(225.0, result[0].computedNutrition!!.amountGramsOrMl, 1e-6)
    }

    @Test
    fun `input 7 - 1 slash 2 cup curd and unicode half`() {
        val result = QuickAddParser.parseBatch("1/2 cup curd", testCatalog)
        assertEquals(1, result.size)
        assertEquals(0.5, result[0].quantity, 1e-6)
        assertEquals("cup", result[0].parsedUnit)
        assertEquals("Curd / Dahi", result[0].matchedFood?.food?.name)
        assertEquals(100.0, result[0].computedNutrition!!.amountGramsOrMl, 1e-6)

        val unicodeResult = QuickAddParser.parseBatch("½ cup dahi", testCatalog)
        assertEquals(0.5, unicodeResult[0].quantity, 1e-6)
        assertEquals("Curd / Dahi", unicodeResult[0].matchedFood?.food?.name)
    }

    @Test
    fun `input 8 - paneer 100g reversed order`() {
        val result = QuickAddParser.parseBatch("paneer 100g", testCatalog)
        assertEquals(1, result.size)
        assertEquals(ParsedItemStatus.MATCHED, result[0].status)
        assertEquals(100.0, result[0].quantity, 1e-6)
        assertEquals("g", result[0].parsedUnit)
        assertEquals("Paneer (Raw)", result[0].matchedFood?.food?.name)
        assertNotNull(result[0].computedNutrition)
    }

    @Test
    fun `input 9 - xyzfood 50g unknown food returns UNMATCHED`() {
        val result = QuickAddParser.parseBatch("xyzfood 50g", testCatalog)
        assertEquals(1, result.size)
        assertEquals(ParsedItemStatus.UNMATCHED, result[0].status)
        assertEquals(50.0, result[0].quantity, 1e-6)
        assertEquals("g", result[0].parsedUnit)
        assertEquals("xyzfood", result[0].extractedFoodName)
        assertNull(result[0].matchedFood)
    }

    @Test
    fun `input 10 - empty input returns empty list`() {
        val emptyResult = QuickAddParser.parseBatch("", testCatalog)
        assertTrue(emptyResult.isEmpty())

        val whitespaceResult = QuickAddParser.parseBatch("   \n  ", testCatalog)
        assertTrue(whitespaceResult.isEmpty())
    }
}
