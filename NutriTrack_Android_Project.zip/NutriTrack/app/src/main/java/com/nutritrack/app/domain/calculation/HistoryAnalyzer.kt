package com.nutritrack.app.domain.calculation

import com.nutritrack.app.data.local.dao.DatedNutritionTotalsTuple
import java.time.LocalDate

data class DayHistoryPoint(
    val date: LocalDate,
    /** False when the day has 0 entries; UI must display "No data", never 0. */
    val hasData: Boolean,
    val totalKcal: Double?,
    val totalProtein: Double?,
    val totalCarbs: Double?,
    val totalFat: Double?,
    val entryCount: Int
)

data class PeriodNutritionAverages(
    val loggedDaysCount: Int,
    val totalWindowDays: Int,
    /** Null if loggedDaysCount == 0 (no data in window) */
    val averageKcal: Double?,
    val averageProtein: Double?,
    val averageCarbs: Double?,
    val averageFat: Double?
)

object HistoryAnalyzer {

    /**
     * Builds a day-by-day series between [startDate] and [endDate] inclusive.
     * Unlogged days have `hasData = false` and null totals so they display "No data", never zero.
     */
    fun buildDailySeries(
        startDate: LocalDate,
        endDate: LocalDate,
        loggedDays: List<DatedNutritionTotalsTuple>
    ): List<DayHistoryPoint> {
        if (endDate.isBefore(startDate)) return emptyList()
        val byDate = loggedDays.filter { it.entryCount > 0 }.associateBy { it.entryDate }

        val result = mutableListOf<DayHistoryPoint>()
        var cursor = startDate
        while (!cursor.isAfter(endDate)) {
            val row = byDate[cursor]
            if (row != null && row.entryCount > 0) {
                result.add(
                    DayHistoryPoint(
                        date = cursor,
                        hasData = true,
                        totalKcal = row.totalKcal,
                        totalProtein = row.totalProtein,
                        totalCarbs = row.totalCarbs,
                        totalFat = row.totalFat,
                        entryCount = row.entryCount
                    )
                )
            } else {
                result.add(
                    DayHistoryPoint(
                        date = cursor,
                        hasData = false,
                        totalKcal = null,
                        totalProtein = null,
                        totalCarbs = null,
                        totalFat = null,
                        entryCount = 0
                    )
                )
            }
            cursor = cursor.plusDays(1)
        }
        return result
    }

    /**
     * History/averages/charts use ONLY days with at least one entry.
     * Unlogged days are excluded from the denominator.
     */
    fun computeLoggedDayAverages(
        startDate: LocalDate,
        endDate: LocalDate,
        loggedDays: List<DatedNutritionTotalsTuple>
    ): PeriodNutritionAverages {
        val windowDays = if (endDate.isBefore(startDate)) {
            0
        } else {
            (endDate.toEpochDay() - startDate.toEpochDay() + 1).toInt()
        }
        val activeDays = loggedDays.filter {
            !it.entryDate.isBefore(startDate) && !it.entryDate.isAfter(endDate) && it.entryCount > 0
        }
        if (activeDays.isEmpty()) {
            return PeriodNutritionAverages(
                loggedDaysCount = 0,
                totalWindowDays = windowDays,
                averageKcal = null,
                averageProtein = null,
                averageCarbs = null,
                averageFat = null
            )
        }
        val count = activeDays.size.toDouble()
        return PeriodNutritionAverages(
            loggedDaysCount = activeDays.size,
            totalWindowDays = windowDays,
            averageKcal = activeDays.sumOf { it.totalKcal } / count,
            averageProtein = activeDays.sumOf { it.totalProtein } / count,
            averageCarbs = activeDays.sumOf { it.totalCarbs } / count,
            averageFat = activeDays.sumOf { it.totalFat } / count
        )
    }
}
