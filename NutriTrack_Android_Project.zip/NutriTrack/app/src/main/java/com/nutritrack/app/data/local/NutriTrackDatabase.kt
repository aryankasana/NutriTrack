package com.nutritrack.app.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import com.nutritrack.app.data.local.dao.FavoriteFoodDao
import com.nutritrack.app.data.local.dao.FoodDao
import com.nutritrack.app.data.local.dao.FoodEntryDao
import com.nutritrack.app.data.local.dao.FoodServingDao
import com.nutritrack.app.data.local.dao.NutritionTargetDao
import com.nutritrack.app.data.local.dao.QuantityHistoryDao
import com.nutritrack.app.data.local.dao.SavedMealDao
import com.nutritrack.app.data.local.entity.FavoriteFoodEntity
import com.nutritrack.app.data.local.entity.FoodEntity
import com.nutritrack.app.data.local.entity.FoodEntryEntity
import com.nutritrack.app.data.local.entity.FoodServingEntity
import com.nutritrack.app.data.local.entity.NutritionTargetEntity
import com.nutritrack.app.data.local.entity.QuantityHistoryEntity
import com.nutritrack.app.data.local.entity.SavedMealEntity
import com.nutritrack.app.data.local.entity.SavedMealItemEntity

@Database(
    entities = [
        FoodEntity::class,
        FoodServingEntity::class,
        FoodEntryEntity::class,
        SavedMealEntity::class,
        SavedMealItemEntity::class,
        FavoriteFoodEntity::class,
        QuantityHistoryEntity::class,
        NutritionTargetEntity::class
    ],
    version = 2,
    exportSchema = true
)
@TypeConverters(Converters::class)
abstract class NutriTrackDatabase : RoomDatabase() {
    abstract fun foodDao(): FoodDao
    abstract fun foodServingDao(): FoodServingDao
    abstract fun foodEntryDao(): FoodEntryDao
    abstract fun nutritionTargetDao(): NutritionTargetDao
    abstract fun favoriteFoodDao(): FavoriteFoodDao
    abstract fun quantityHistoryDao(): QuantityHistoryDao
    abstract fun savedMealDao(): SavedMealDao

    companion object {
        const val DATABASE_NAME = "nutritrack.db"

        /**
         * Schema migration from version 1 to version 2:
         * Adds optional `barcode` and `notes` columns to `foods` and indexes `barcode`
         * while preserving all existing foods, servings, and logged entries intact.
         */
        val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE `foods` ADD COLUMN `barcode` TEXT DEFAULT NULL")
                db.execSQL("ALTER TABLE `foods` ADD COLUMN `notes` TEXT DEFAULT NULL")
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_foods_barcode` ON `foods` (`barcode`)")
            }
        }

        @Volatile
        private var INSTANCE: NutriTrackDatabase? = null

        fun getInstance(context: Context): NutriTrackDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    NutriTrackDatabase::class.java,
                    DATABASE_NAME
                )
                    .addMigrations(MIGRATION_1_2)
                    .build()
                    .also { INSTANCE = it }
            }
        }
    }
}
