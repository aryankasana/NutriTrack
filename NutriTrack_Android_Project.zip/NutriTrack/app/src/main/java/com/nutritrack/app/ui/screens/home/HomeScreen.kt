package com.nutritrack.app.ui.screens.home

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ChevronLeft
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Today
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.nutritrack.app.data.local.entity.FoodEntryEntity
import com.nutritrack.app.data.local.entity.FoodWithServings
import com.nutritrack.app.domain.calculation.DailyNutritionSummary
import com.nutritrack.app.domain.calculation.NutritionCalculator
import com.nutritrack.app.domain.model.MealCategory
import com.nutritrack.app.ui.components.FoodSourceBadge
import com.nutritrack.app.ui.components.NutrientSummaryCard
import com.nutritrack.app.ui.theme.CalorieAccent
import com.nutritrack.app.ui.theme.CarbsAccent
import com.nutritrack.app.ui.theme.FatAccent
import com.nutritrack.app.ui.theme.ProteinAccent
import java.time.LocalDate
import java.time.format.DateTimeFormatter

@Composable
fun HomeScreen(
    selectedDate: LocalDate,
    todayDate: LocalDate,
    summary: DailyNutritionSummary,
    entries: List<FoodEntryEntity>,
    allFoods: List<FoodWithServings>,
    defaultMealCategory: MealCategory,
    onPreviousDay: () -> Unit,
    onNextDay: () -> Unit,
    onJumpToToday: () -> Unit,
    onOpenQuickAdd: () -> Unit,
    onManualEntrySave: (
        mealCategory: MealCategory,
        foodName: String,
        quantity: Double,
        unit: String,
        kcal: Double,
        protein: Double,
        carbs: Double,
        fat: Double
    ) -> Unit,
    onEditEntry: (
        entry: FoodEntryEntity,
        newFoodId: Long?,
        newQuantity: Double,
        newUnit: String,
        newMealCategory: MealCategory
    ) -> Unit,
    onDeleteEntry: (FoodEntryEntity) -> Unit,
    onDuplicateEntry: (FoodEntryEntity) -> Unit,
    modifier: Modifier = Modifier
) {
    var editingEntry by remember { mutableStateOf<FoodEntryEntity?>(null) }
    var showManualDialog by remember { mutableStateOf(false) }

    val dateFormatter = remember { DateTimeFormatter.ofPattern("EEE, dd MMM yyyy") }
    val groupedMeals = remember(entries) {
        entries.groupBy { it.mealCategory }
            .toSortedMap(compareBy { it.sortOrder })
    }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = onOpenQuickAdd,
                icon = { Icon(Icons.Default.Add, contentDescription = "Add Food") },
                text = { Text("+ Add Food") },
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = MaterialTheme.colorScheme.onPrimary
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Spacer(modifier = Modifier.height(8.dp))
                DateHeaderBar(
                    selectedDate = selectedDate,
                    todayDate = todayDate,
                    formattedDate = selectedDate.format(dateFormatter),
                    onPreviousDay = onPreviousDay,
                    onNextDay = onNextDay,
                    onJumpToToday = onJumpToToday
                )
            }

            // Four Nutrient Cards (Calories, Protein, Carbs, Fat)
            item {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        NutrientSummaryCard(
                            title = "Calories",
                            unitSuffix = "kcal",
                            progress = summary.kcal,
                            isKcal = true,
                            accentColor = CalorieAccent,
                            modifier = Modifier.weight(1f)
                        )
                        NutrientSummaryCard(
                            title = "Protein",
                            unitSuffix = "g",
                            progress = summary.protein,
                            isKcal = false,
                            accentColor = ProteinAccent,
                            modifier = Modifier.weight(1f)
                        )
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        NutrientSummaryCard(
                            title = "Carbs",
                            unitSuffix = "g",
                            progress = summary.carbs,
                            isKcal = false,
                            accentColor = CarbsAccent,
                            modifier = Modifier.weight(1f)
                        )
                        NutrientSummaryCard(
                            title = "Fat",
                            unitSuffix = "g",
                            progress = summary.fat,
                            isKcal = false,
                            accentColor = FatAccent,
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }

            // Quick action row
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Meals (${entries.size} entries)",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    OutlinedButton(onClick = { showManualDialog = true }) {
                        Text("Manual Portion")
                    }
                }
            }

            if (entries.isEmpty()) {
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f)
                        )
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(24.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(
                                text = "No foods logged for this day yet",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.SemiBold
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "Tap '+ Add Food' to type '3 roti, 200 ml milk, 1 banana, 100 g paneer' and log in two taps.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            } else {
                groupedMeals.forEach { (mealCategory, mealEntries) ->
                    item(key = "meal_header_${mealCategory.name}") {
                        val mealKcal = mealEntries.sumOf { it.kcal }
                        val mealP = mealEntries.sumOf { it.protein }
                        val mealC = mealEntries.sumOf { it.carbs }
                        val mealF = mealEntries.sumOf { it.fat }

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(top = 8.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = mealCategory.displayName,
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )
                            Text(
                                text = "${NutritionCalculator.formatKcal(mealKcal)} kcal • " +
                                    "${NutritionCalculator.formatMacro(mealP)}P " +
                                    "${NutritionCalculator.formatMacro(mealC)}C " +
                                    "${NutritionCalculator.formatMacro(mealF)}F",
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    items(
                        items = mealEntries,
                        key = { it.id }
                    ) { entry ->
                        FoodEntryRowCard(
                            entry = entry,
                            onEdit = { editingEntry = entry },
                            onDuplicate = { onDuplicateEntry(entry) },
                            onDelete = { onDeleteEntry(entry) }
                        )
                    }
                }
            }

            item {
                Spacer(modifier = Modifier.height(88.dp))
            }
        }
    }

    if (showManualDialog) {
        ManualPortionDialog(
            initialMealCategory = defaultMealCategory,
            onDismiss = { showManualDialog = false },
            onConfirm = { meal, name, qty, unit, kcal, p, c, f ->
                onManualEntrySave(meal, name, qty, unit, kcal, p, c, f)
                showManualDialog = false
            }
        )
    }

    editingEntry?.let { targetEntry ->
        EditEntryDialog(
            entry = targetEntry,
            allFoods = allFoods,
            onDismiss = { editingEntry = null },
            onSave = { newFoodId, newQty, newUnit, newMealCategory ->
                onEditEntry(targetEntry, newFoodId, newQty, newUnit, newMealCategory)
                editingEntry = null
            }
        )
    }
}

@Composable
private fun DateHeaderBar(
    selectedDate: LocalDate,
    todayDate: LocalDate,
    formattedDate: String,
    onPreviousDay: () -> Unit,
    onNextDay: () -> Unit,
    onJumpToToday: () -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        IconButton(onClick = onPreviousDay) {
            Icon(Icons.Default.ChevronLeft, contentDescription = "Previous day")
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                text = when (selectedDate) {
                    todayDate -> "Today • $formattedDate"
                    todayDate.minusDays(1) -> "Yesterday • $formattedDate"
                    todayDate.plusDays(1) -> "Tomorrow • $formattedDate"
                    else -> formattedDate
                },
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            if (selectedDate != todayDate) {
                IconButton(onClick = onJumpToToday) {
                    Icon(Icons.Default.Today, contentDescription = "Jump to Today")
                }
            }
            IconButton(onClick = onNextDay) {
                Icon(Icons.Default.ChevronRight, contentDescription = "Next day")
            }
        }
    }
}

@Composable
fun FoodEntryRowCard(
    entry: FoodEntryEntity,
    onEdit: () -> Unit,
    onDuplicate: () -> Unit,
    onDelete: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        text = entry.foodNameSnapshot,
                        style = MaterialTheme.typography.bodyLarge,
                        fontWeight = FontWeight.SemiBold
                    )
                    FoodSourceBadge(source = entry.sourceSnapshot)
                }
                val qtyStr = if (entry.quantity % 1.0 == 0.0) {
                    entry.quantity.toInt().toString()
                } else {
                    entry.quantity.toString()
                }
                Text(
                    text = "$qtyStr ${entry.unit} (${entry.amountGramsOrMl.toInt()}g/ml) • " +
                        "${NutritionCalculator.formatKcal(entry.kcal)} kcal | " +
                        "${NutritionCalculator.formatMacro(entry.protein)}P " +
                        "${NutritionCalculator.formatMacro(entry.carbs)}C " +
                        "${NutritionCalculator.formatMacro(entry.fat)}F",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Row {
                IconButton(onClick = onEdit) {
                    Icon(Icons.Default.Edit, contentDescription = "Edit entry")
                }
                IconButton(onClick = onDuplicate) {
                    Icon(Icons.Default.ContentCopy, contentDescription = "Duplicate entry")
                }
                IconButton(onClick = onDelete) {
                    Icon(Icons.Default.Delete, contentDescription = "Delete entry")
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ManualPortionDialog(
    initialMealCategory: MealCategory,
    initialFoodName: String = "",
    initialQuantity: String = "1",
    initialUnit: String = "serving",
    onDismiss: () -> Unit,
    onConfirm: (
        mealCategory: MealCategory,
        foodName: String,
        quantity: Double,
        unit: String,
        kcal: Double,
        protein: Double,
        carbs: Double,
        fat: Double
    ) -> Unit
) {
    var foodName by remember { mutableStateOf(initialFoodName) }
    var quantityText by remember { mutableStateOf(initialQuantity) }
    var unitText by remember { mutableStateOf(initialUnit) }
    var kcalText by remember { mutableStateOf("") }
    var proteinText by remember { mutableStateOf("") }
    var carbsText by remember { mutableStateOf("") }
    var fatText by remember { mutableStateOf("") }
    var selectedMeal by remember { mutableStateOf(initialMealCategory) }
    var mealExpanded by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Manual Nutrition Entry") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = foodName,
                    onValueChange = { foodName = it },
                    label = { Text("Dish / Food name") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = quantityText,
                        onValueChange = { quantityText = it },
                        label = { Text("Qty") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = unitText,
                        onValueChange = { unitText = it },
                        label = { Text("Unit") },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = kcalText,
                        onValueChange = { kcalText = it },
                        label = { Text("kcal") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = proteinText,
                        onValueChange = { proteinText = it },
                        label = { Text("Protein (g)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = carbsText,
                        onValueChange = { carbsText = it },
                        label = { Text("Carbs (g)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = fatText,
                        onValueChange = { fatText = it },
                        label = { Text("Fat (g)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                }
                ExposedDropdownMenuBox(
                    expanded = mealExpanded,
                    onExpandedChange = { mealExpanded = !mealExpanded }
                ) {
                    OutlinedTextField(
                        value = selectedMeal.displayName,
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("Meal Category") },
                        trailingIcon = {
                            ExposedDropdownMenuDefaults.TrailingIcon(expanded = mealExpanded)
                        },
                        modifier = Modifier
                            .menuAnchor()
                            .fillMaxWidth()
                    )
                    ExposedDropdownMenu(
                        expanded = mealExpanded,
                        onDismissRequest = { mealExpanded = false }
                    ) {
                        MealCategory.entries.forEach { category ->
                            DropdownMenuItem(
                                text = { Text(category.displayName) },
                                onClick = {
                                    selectedMeal = category
                                    mealExpanded = false
                                }
                            )
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val qty = quantityText.toDoubleOrNull() ?: 1.0
                    val kcal = kcalText.toDoubleOrNull() ?: 0.0
                    val p = proteinText.toDoubleOrNull() ?: 0.0
                    val c = carbsText.toDoubleOrNull() ?: 0.0
                    val f = fatText.toDoubleOrNull() ?: 0.0
                    if (foodName.isNotBlank()) {
                        onConfirm(
                            selectedMeal,
                            foodName.trim(),
                            qty,
                            unitText.ifBlank { "serving" },
                            kcal,
                            p,
                            c,
                            f
                        )
                    }
                }
            ) {
                Text("Save Entry")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EditEntryDialog(
    entry: FoodEntryEntity,
    allFoods: List<FoodWithServings>,
    onDismiss: () -> Unit,
    onSave: (
        newFoodId: Long?,
        newQuantity: Double,
        newUnit: String,
        newMealCategory: MealCategory
    ) -> Unit
) {
    var selectedFoodId by remember { mutableStateOf(entry.foodId) }
    var quantityText by remember { mutableStateOf(entry.quantity.toString()) }
    var unitText by remember { mutableStateOf(entry.unit) }
    var selectedMeal by remember { mutableStateOf(entry.mealCategory) }
    var foodMenuExpanded by remember { mutableStateOf(false) }
    var mealMenuExpanded by remember { mutableStateOf(false) }

    val selectedFoodName = remember(selectedFoodId, allFoods) {
        allFoods.firstOrNull { it.food.id == selectedFoodId }?.food?.name ?: entry.foodNameSnapshot
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Edit Logged Entry") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                ExposedDropdownMenuBox(
                    expanded = foodMenuExpanded,
                    onExpandedChange = { foodMenuExpanded = !foodMenuExpanded }
                ) {
                    OutlinedTextField(
                        value = selectedFoodName,
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("Food") },
                        trailingIcon = {
                            ExposedDropdownMenuDefaults.TrailingIcon(expanded = foodMenuExpanded)
                        },
                        modifier = Modifier
                            .menuAnchor()
                            .fillMaxWidth()
                    )
                    ExposedDropdownMenu(
                        expanded = foodMenuExpanded,
                        onDismissRequest = { foodMenuExpanded = false }
                    ) {
                        allFoods.take(40).forEach { item ->
                            DropdownMenuItem(
                                text = { Text(item.food.name) },
                                onClick = {
                                    selectedFoodId = item.food.id
                                    foodMenuExpanded = false
                                }
                            )
                        }
                    }
                }

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = quantityText,
                        onValueChange = { quantityText = it },
                        label = { Text("Quantity") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    OutlinedTextField(
                        value = unitText,
                        onValueChange = { unitText = it },
                        label = { Text("Unit") },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                }

                ExposedDropdownMenuBox(
                    expanded = mealMenuExpanded,
                    onExpandedChange = { mealMenuExpanded = !mealMenuExpanded }
                ) {
                    OutlinedTextField(
                        value = selectedMeal.displayName,
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("Meal") },
                        trailingIcon = {
                            ExposedDropdownMenuDefaults.TrailingIcon(expanded = mealMenuExpanded)
                        },
                        modifier = Modifier
                            .menuAnchor()
                            .fillMaxWidth()
                    )
                    ExposedDropdownMenu(
                        expanded = mealMenuExpanded,
                        onDismissRequest = { mealMenuExpanded = false }
                    ) {
                        MealCategory.entries.forEach { meal ->
                            DropdownMenuItem(
                                text = { Text(meal.displayName) },
                                onClick = {
                                    selectedMeal = meal
                                    mealMenuExpanded = false
                                }
                            )
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val qty = quantityText.toDoubleOrNull()
                    if (qty != null && qty > 0.0) {
                        onSave(selectedFoodId, qty, unitText.trim(), selectedMeal)
                    }
                }
            ) {
                Text("Save Changes")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}
