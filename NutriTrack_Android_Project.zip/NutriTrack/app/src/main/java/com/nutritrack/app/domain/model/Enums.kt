package com.nutritrack.app.domain.model

enum class FoodBasis(val displayName: String, val unitSuffix: String) {
    PER_100G("Per 100g", "g"),
    PER_100ML("Per 100ml", "ml")
}

enum class Preparation(val displayName: String) {
    RAW("Raw"),
    COOKED("Cooked"),
    NA("N/A")
}

enum class FoodSource(val displayName: String, val badgeLabel: String) {
    IFCT("IFCT 2017", "IFCT"),
    USDA("USDA FDC", "USDA"),
    OFF("Open Food Facts", "OFF"),
    USER("Custom Food", "Custom"),
    ESTIMATE("Estimated Value", "Estimated")
}

enum class MealCategory(val displayName: String, val sortOrder: Int) {
    BREAKFAST("Breakfast", 0),
    MORNING_SNACK("Morning snack", 1),
    LUNCH("Lunch", 2),
    EVENING_SNACK("Evening snack", 3),
    PRE_WORKOUT("Pre-workout", 4),
    POST_WORKOUT("Post-workout", 5),
    DINNER("Dinner", 6),
    LATE_NIGHT_SNACK("Late-night snack", 7),
    OTHER("Other", 8)
}

enum class ThemeMode(val displayName: String) {
    SYSTEM("System default"),
    LIGHT("Light"),
    DARK("Dark")
}
