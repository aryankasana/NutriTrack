package com.nutritrack.app.domain.export

import android.content.Context
import android.content.Intent
import androidx.core.content.FileProvider
import com.nutritrack.app.data.local.entity.FoodEntryEntity
import java.io.File
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale

object CsvExporter {

    const val CSV_HEADER = "date,time,meal,food,quantity,unit,kcal,P,C,F,source"

    private val timeFormatter: DateTimeFormatter =
        DateTimeFormatter.ofPattern("HH:mm:ss", Locale.US)

    /**
     * Generates a complete CSV string of all entries with columns:
     * date, time, meal, food, quantity, unit, kcal, P, C, F, source
     */
    fun formatEntriesToCsv(
        entries: List<FoodEntryEntity>,
        zoneId: ZoneId = ZoneId.systemDefault()
    ): String {
        val sb = StringBuilder()
        sb.appendLine(CSV_HEADER)
        for (entry in entries) {
            val dateStr = entry.entryDate.toString()
            val timeStr = entry.loggedAt.atZone(zoneId).toLocalTime().format(timeFormatter)
            val mealStr = escapeCsvField(entry.mealCategory.displayName)
            val foodStr = escapeCsvField(entry.foodNameSnapshot)
            val qtyStr = formatDoubleClean(entry.quantity)
            val unitStr = escapeCsvField(entry.unit)
            val kcalStr = String.format(Locale.US, "%.1f", entry.kcal)
            val pStr = String.format(Locale.US, "%.1f", entry.protein)
            val cStr = String.format(Locale.US, "%.1f", entry.carbs)
            val fStr = String.format(Locale.US, "%.1f", entry.fat)
            val sourceStr = entry.sourceSnapshot.name

            sb.append(dateStr).append(',')
                .append(timeStr).append(',')
                .append(mealStr).append(',')
                .append(foodStr).append(',')
                .append(qtyStr).append(',')
                .append(unitStr).append(',')
                .append(kcalStr).append(',')
                .append(pStr).append(',')
                .append(cStr).append(',')
                .append(fStr).append(',')
                .appendLine(sourceStr)
        }
        return sb.toString()
    }

    fun escapeCsvField(raw: String): String {
        val needsQuotes = raw.contains(',') || raw.contains('"') || raw.contains('\n') || raw.contains('\r')
        if (!needsQuotes) return raw
        val escaped = raw.replace("\"", "\"\"")
        return "\"$escaped\""
    }

    private fun formatDoubleClean(value: Double): String {
        return if (value % 1.0 == 0.0) {
            value.toLong().toString()
        } else {
            String.format(Locale.US, "%.2f", value).trimEnd('0').trimEnd('.')
        }
    }

    /**
     * Writes the CSV into `<cacheDir>/exports/nutritrack_entries.csv` and launches
     * the Android Share Sheet via `FileProvider`.
     */
    fun shareCsvViaIntent(context: Context, csvContent: String) {
        val exportDir = File(context.cacheDir, "exports").apply { mkdirs() }
        val csvFile = File(exportDir, "nutritrack_entries.csv")
        csvFile.writeText(csvContent, Charsets.UTF_8)

        val uri = FileProvider.getUriForFile(
            context,
            "${context.packageName}.fileprovider",
            csvFile
        )

        val sendIntent = Intent(Intent.ACTION_SEND).apply {
            type = "text/csv"
            putExtra(Intent.EXTRA_STREAM, uri)
            putExtra(Intent.EXTRA_SUBJECT, "NutriTrack Nutrition Log Export")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        val chooser = Intent.createChooser(sendIntent, "Export NutriTrack CSV")
        chooser.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(chooser)
    }
}
