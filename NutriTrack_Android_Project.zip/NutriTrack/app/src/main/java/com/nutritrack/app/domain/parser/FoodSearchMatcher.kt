package com.nutritrack.app.domain.parser

import com.nutritrack.app.data.local.entity.FoodWithServings
import com.nutritrack.app.domain.model.Preparation
import java.util.Locale
import kotlin.math.min

sealed class FoodMatchOutcome {
    data class Matched(val foodWithServings: FoodWithServings) : FoodMatchOutcome()
    data class Ambiguous(val candidates: List<FoodWithServings>) : FoodMatchOutcome()
    data class Unmatched(val suggestions: List<FoodWithServings>) : FoodMatchOutcome()
}

object FoodSearchMatcher {

    private val rawModifierTokens = setOf("raw", "uncooked", "dry", "kacha")
    private val cookedModifierTokens = setOf("cooked", "boiled", "steamed", "fried", "grilled", "roasted")

    fun searchFoods(
        query: String,
        catalog: List<FoodWithServings>
    ): List<FoodWithServings> {
        val cleaned = query.trim().lowercase(Locale.ROOT)
        if (cleaned.isEmpty()) return catalog

        return catalog
            .mapNotNull { item ->
                val score = scoreCandidate(cleaned, null, item)
                if (score > 0) item to score else null
            }
            .sortedWith(compareByDescending<Pair<FoodWithServings, Int>> { it.second }.thenBy { it.first.food.name })
            .map { it.first }
    }

    /**
     * Resolves a parsed food name + optional preparation hint against the food catalog.
     * Returns:
     * - Matched: single confident winner
     * - Ambiguous: multiple close candidates (never silently picks when ambiguous)
     * - Unmatched: no match found (provides top fallback suggestions if any)
     */
    fun matchFoodName(
        rawFoodQuery: String,
        explicitPrep: Preparation?,
        catalog: List<FoodWithServings>
    ): FoodMatchOutcome {
        val normalizedQuery = normalizeText(rawFoodQuery)
        if (normalizedQuery.isEmpty()) {
            return FoodMatchOutcome.Unmatched(emptyList())
        }

        val queryTokens = normalizedQuery.split(" ").filter { it.isNotEmpty() }
        val inferredPrep = explicitPrep ?: inferPreparationFromTokens(queryTokens)
        val coreQueryTokens = queryTokens.filterNot {
            it in rawModifierTokens || it in cookedModifierTokens
        }
        val coreQuery = if (coreQueryTokens.isNotEmpty()) {
            coreQueryTokens.joinToString(" ")
        } else {
            normalizedQuery
        }

        val scored = catalog.mapNotNull { candidate ->
            val score = scoreCandidate(coreQuery, inferredPrep, candidate)
            if (score > 0) candidate to score else null
        }.sortedWith(
            compareByDescending<Pair<FoodWithServings, Int>> { it.second }
                .thenBy { it.first.food.name.length }
        )

        if (scored.isEmpty()) {
            return FoodMatchOutcome.Unmatched(catalog.take(5))
        }

        val topScore = scored.first().second
        val closeCandidates = scored.filter { topScore - it.second <= 8 }.map { it.first }

        return when {
            topScore < 55 -> FoodMatchOutcome.Unmatched(scored.take(5).map { it.first })
            closeCandidates.size == 1 -> FoodMatchOutcome.Matched(closeCandidates.first())
            else -> FoodMatchOutcome.Ambiguous(closeCandidates.take(5))
        }
    }

    fun inferPreparationFromTokens(tokens: List<String>): Preparation? {
        val lower = tokens.map { it.lowercase(Locale.ROOT) }
        return when {
            lower.any { it in rawModifierTokens } -> Preparation.RAW
            lower.any { it in cookedModifierTokens } -> Preparation.COOKED
            else -> null
        }
    }

    private fun scoreCandidate(
        coreQuery: String,
        requestedPrep: Preparation?,
        candidate: FoodWithServings
    ): Int {
        val food = candidate.food
        val normalizedName = normalizeText(food.name)
        val aliases = food.aliasList().map { normalizeText(it) }
        val singularQuery = singularizePhrase(coreQuery)

        var baseScore = 0

        // 1. Exact canonical name match
        if (normalizedName == coreQuery || normalizedName == singularQuery) {
            baseScore = 100
        }

        // 2. Exact alias match (e.g., "roti", "chapati", "phulka", "curd", "dahi", "milk", "paneer")
        if (baseScore == 0 && aliases.any { it == coreQuery || it == singularQuery }) {
            baseScore = 95
        }

        // 3. Name without parenthetical qualifier matches exactly (e.g. "White Rice (Cooked)" -> "white rice")
        val strippedName = normalizeText(food.name.substringBefore("("))
        if (baseScore == 0 && (strippedName == coreQuery || strippedName == singularQuery)) {
            baseScore = 92
        }

        // 4. Token / substring containment
        if (baseScore == 0) {
            val allCandidatePhrases = listOf(normalizedName, strippedName) + aliases
            val tokenMatch = allCandidatePhrases.any { phrase ->
                val words = phrase.split(" ")
                words.contains(coreQuery) || words.contains(singularQuery)
            }
            if (tokenMatch) {
                baseScore = 76
            } else if (allCandidatePhrases.any { it.contains(coreQuery) || coreQuery.contains(it) }) {
                baseScore = 66
            }
        }

        // 5. Fuzzy Levenshtein fallback for minor typos
        if (baseScore == 0 && coreQuery.length >= 4) {
            val bestDistance = (listOf(strippedName) + aliases)
                .filter { it.isNotEmpty() }
                .minOfOrNull { levenshtein(singularQuery, it) } ?: Int.MAX_VALUE
            if (bestDistance == 1) {
                baseScore = 65
            } else if (bestDistance == 2 && coreQuery.length >= 6) {
                baseScore = 58
            }
        }

        if (baseScore == 0) return 0

        // Preparation modifier adjustment
        val prepBonus = when (requestedPrep) {
            Preparation.RAW -> when (food.preparation) {
                Preparation.RAW -> 15
                Preparation.COOKED -> -20
                Preparation.NA -> 0
            }
            Preparation.COOKED -> when (food.preparation) {
                Preparation.COOKED -> 15
                Preparation.RAW -> -20
                Preparation.NA -> 0
            }
            Preparation.NA, null -> {
                // When user writes "1 bowl dal" or "1.5 katori rajma" without specifying raw/cooked,
                // cooked / ready-to-eat staples are slightly preferred over uncooked grains/pulses,
                // unless the staple is normally eaten/weighed raw (like oats, paneer, fruits, nuts).
                val rawDefaultCategories = setOf("Fruits & Vegetables", "Nuts & Healthy Fats")
                if (food.category in rawDefaultCategories ||
                    food.name.contains("Oats (Raw)", ignoreCase = true) ||
                    food.name.contains("Paneer", ignoreCase = true)
                ) {
                    if (food.preparation == Preparation.RAW) 10 else 0
                } else {
                    if (food.preparation == Preparation.COOKED) 10 else 0
                }
            }
        }

        return baseScore + prepBonus
    }

    private fun normalizeText(input: String): String {
        return input.lowercase(Locale.ROOT)
            .replace(Regex("[^a-z0-9\\s]"), " ")
            .replace(Regex("\\s+"), " ")
            .trim()
    }

    private fun singularizePhrase(phrase: String): String {
        return phrase.split(" ").joinToString(" ") { word ->
            when {
                word.endsWith("ies") && word.length > 4 -> word.dropLast(3) + "y"
                word.endsWith("es") && (word.endsWith("oes") || word.endsWith("ches") || word.endsWith("shes")) ->
                    word.dropLast(2)
                word.endsWith("s") && word.length > 3 && !word.endsWith("ss") && word != "oats" && word != "chips" ->
                    word.dropLast(1)
                else -> word
            }
        }
    }

    private fun levenshtein(lhs: String, rhs: String): Int {
        if (lhs == rhs) return 0
        if (lhs.isEmpty()) return rhs.length
        if (rhs.isEmpty()) return lhs.length

        var prev = IntArray(rhs.length + 1) { it }
        var curr = IntArray(rhs.length + 1)

        for (i in 1..lhs.length) {
            curr[0] = i
            for (j in 1..rhs.length) {
                val cost = if (lhs[i - 1] == rhs[j - 1]) 0 else 1
                curr[j] = min(
                    min(curr[j - 1] + 1, prev[j] + 1),
                    prev[j - 1] + cost
                )
            }
            val tmp = prev
            prev = curr
            curr = tmp
        }
        return prev[rhs.length]
    }
}
