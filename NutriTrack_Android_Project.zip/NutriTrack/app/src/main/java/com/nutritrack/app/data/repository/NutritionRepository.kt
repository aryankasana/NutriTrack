package com.nutritrack.app.data.repository

import com.nutritrack.app.data.local.dao.DailyNutritionTotalsTuple
import com.nutritrack.app.data.local.dao.DatedNutritionTotalsTuple
import com.nutritrack.app.data.local.dao.FavoriteFoodDao
import com.nutritrack.app.data.local.dao.FoodDao
import com.nutritrack.app.data.local.dao.FoodEntryDao
import com.nutritrack.app.data.local.dao.FoodServingDao
import com.nutritrack.app.data.local.dao.NutritionTargetDao
import com.nutritrack.app.data.local.dao.QuantityHistoryDao
import com.nutritrack.app.data.local.dao.RecentFoodProjection
import com.nutritrack.app.data.local.dao.SavedMealDao
import com.nutritrack.app.data.local.entity.FavoriteFoodEntity
import com.nutritrack.app.data.local.entity.FoodEntity
import com.nutritrack.app.data.local.entity.FoodEntryEntity
import com.nutritrack.app.data.local.entity.FoodServingEntity
import com.nutritrack.app.data.local.entity.FoodWithServings
import com.nutritrack.app.data.local.entity.NutritionTargetEntity
import com.nutritrack.app.data.local.entity.QuantityHistoryEntity
import com.nutritrack.app.data.local.entity.SavedMealEntity
import com.nutritrack.app.data.local.entity.SavedMealItemEntity
import com.nutritrack.app.data.local.entity.SavedMealWithItems
import com.nutritrack.app.domain.calculation.NutritionCalculator
import com.nutritrack.app.domain.calculation.UnitConversionResult
import com.nutritrack.app.domain.model.FoodBasis
import com.nutritrack.app.domain.model.FoodSource
import com.nutritrack.app.domain.model.MealCategory
import com.nutritrack.app.domain.model.Preparation
import kotlinx.coroutines.flow.Flow
import java.time.Instant
import java.time.LocalDate

class NutritionRepository(
    private val foodDao: FoodDao,
    private val foodServingDao: FoodServingDao,
    private val foodEntryDao: FoodEntryDao,
    private val nutritionTargetDao: NutritionTargetDao,
    private val favoriteFoodDao: FavoriteFoodDao,
    private val quantityHistoryDao: QuantityHistoryDao,
    private val savedMealDao: SavedMealDao
) {
    fun observeAllFoodsWithServings(): Flow<List<FoodWithServings>> =
        foodDao.observeAllFoodsWithServings()

    fun observeCustomFoodsWithServings(): Flow<List<FoodWithServings>> =
        foodDao.observeCustomFoodsWithServings()

    fun observeEntriesForDate(date: LocalDate): Flow<List<FoodEntryEntity>> =
        foodEntryDao.observeEntriesForDate(date)

    fun observeDailyTotals(date: LocalDate): Flow<DailyNutritionTotalsTuple> =
        foodEntryDao.observeDailyTotals(date)

    fun observeLoggedDailyTotalsBetween(
        startDate: LocalDate,
        endDate: LocalDate
    ): Flow<List<DatedNutritionTotalsTuple>> =
        foodEntryDao.observeLoggedDailyTotalsBetween(startDate, endDate)

    fun observeEffectiveTargetForDate(date: LocalDate): Flow<NutritionTargetEntity?> =
        nutritionTargetDao.observeEffectiveTargetForDate(date)

    fun observeAllTargets(): Flow<List<NutritionTargetEntity>> =
        nutritionTargetDao.observeAllTargets()

    fun observeFavorites(): Flow<List<FavoriteFoodEntity>> =
        favoriteFoodDao.observeFavorites()

    fun observeRecentFoods(limit: Int = 15): Flow<List<RecentFoodProjection>> =
        foodEntryDao.observeRecentFoods(limit)

    fun observeSavedMealsWithItems(): Flow<List<SavedMealWithItems>> =
        savedMealDao.observeSavedMealsWithItems()

    fun searchPastEntries(query: String): Flow<List<FoodEntryEntity>> =
        foodEntryDao.searchPastEntries(query)

    suspend fun getAllEntriesChronological(): List<FoodEntryEntity> =
        foodEntryDao.getAllEntriesChronological()

    /**
     * Logs a food item for [entryDate] and [mealCategory], computing nutrition once at save time
     * and storing the snapshot. Also updates [QuantityHistoryEntity] for fast one-tap suggestions.
     */
    suspend fun logFoodEntry(
        entryDate: LocalDate,
        mealCategory: MealCategory,
        foodWithServings: FoodWithServings,
        quantity: Double,
        unit: String,
        amountGramsOrMl: Double,
        loggedAt: Instant = Instant.now()
    ): Long {
        val computed = NutritionCalculator.computeFromAmount(
            food = foodWithServings.food,
            amountGramsOrMl = amountGramsOrMl
        )
        val entry = FoodEntryEntity(
            entryDate = entryDate,
            loggedAt = loggedAt,
            mealCategory = mealCategory,
            foodId = foodWithServings.food.id,
            foodNameSnapshot = foodWithServings.food.name,
            quantity = quantity,
            unit = unit,
            amountGramsOrMl = computed.amountGramsOrMl,
            kcal = computed.kcal,
            protein = computed.protein,
            carbs = computed.carbs,
            fat = computed.fat,
            sourceSnapshot = foodWithServings.food.source
        )
        val id = foodEntryDao.insertEntry(entry)
        recordQuantityUsage(foodWithServings.food.id, quantity, unit, loggedAt)
        return id
    }

    /**
     * Logs a manual nutrition portion directly (e.g. homemade dish or unmatched item entered manually).
     */
    suspend fun logManualPortion(
        entryDate: LocalDate,
        mealCategory: MealCategory,
        foodName: String,
        quantity: Double,
        unit: String,
        kcal: Double,
        protein: Double,
        carbs: Double,
        fat: Double,
        loggedAt: Instant = Instant.now()
    ): Long {
        val entry = FoodEntryEntity(
            entryDate = entryDate,
            loggedAt = loggedAt,
            mealCategory = mealCategory,
            foodId = null,
            foodNameSnapshot = foodName.trim(),
            quantity = quantity,
            unit = unit.ifBlank { "serving" },
            amountGramsOrMl = quantity,
            kcal = kcal,
            protein = protein,
            carbs = carbs,
            fat = fat,
            sourceSnapshot = FoodSource.USER
        )
        return foodEntryDao.insertEntry(entry)
    }

    /**
     * Updates an existing entry:
     * - If the food stays the same, scales the stored nutrition by newAmount / oldAmount.
     * - If the food changes, recalculates nutrition from the new food.
     */
    suspend fun editEntry(
        existingEntry: FoodEntryEntity,
        newFoodId: Long?,
        newQuantity: Double,
        newUnit: String,
        newMealCategory: MealCategory
    ) {
        val updated = if (newFoodId == existingEntry.foodId) {
            val newAmount = if (newFoodId != null) {
                val foodWithServings = foodDao.getFoodWithServingsById(newFoodId)
                if (foodWithServings != null) {
                    when (val res = NutritionCalculator.resolveAmountGramsOrMl(
                        foodWithServings.food,
                        foodWithServings.servings,
                        newQuantity,
                        newUnit
                    )) {
                        is UnitConversionResult.Success -> res.amountGramsOrMl
                        is UnitConversionResult.MissingServingWeight ->
                            if (existingEntry.quantity > 0.0) {
                                existingEntry.amountGramsOrMl * (newQuantity / existingEntry.quantity)
                            } else {
                                newQuantity
                            }
                    }
                } else {
                    if (existingEntry.quantity > 0.0) {
                        existingEntry.amountGramsOrMl * (newQuantity / existingEntry.quantity)
                    } else {
                        newQuantity
                    }
                }
            } else {
                if (existingEntry.quantity > 0.0) {
                    existingEntry.amountGramsOrMl * (newQuantity / existingEntry.quantity)
                } else {
                    newQuantity
                }
            }
            NutritionCalculator.scaleEntryByAmount(
                entry = existingEntry.copy(mealCategory = newMealCategory),
                newQuantity = newQuantity,
                newUnit = newUnit,
                newAmountGramsOrMl = newAmount
            )
        } else if (newFoodId != null) {
            val newFoodWithServings = foodDao.getFoodWithServingsById(newFoodId) ?: return
            val resolvedAmount = when (val res = NutritionCalculator.resolveAmountGramsOrMl(
                newFoodWithServings.food,
                newFoodWithServings.servings,
                newQuantity,
                newUnit
            )) {
                is UnitConversionResult.Success -> res.amountGramsOrMl
                is UnitConversionResult.MissingServingWeight -> newQuantity * 100.0
            }
            NutritionCalculator.recalculateEntryWithNewFood(
                entry = existingEntry.copy(mealCategory = newMealCategory),
                newFood = newFoodWithServings.food,
                newQuantity = newQuantity,
                newUnit = newUnit,
                newAmountGramsOrMl = resolvedAmount
            )
        } else {
            existingEntry.copy(
                mealCategory = newMealCategory,
                quantity = newQuantity,
                unit = newUnit
            )
        }
        foodEntryDao.updateEntry(updated)
    }

    suspend fun deleteEntry(entry: FoodEntryEntity) {
        foodEntryDao.deleteEntry(entry)
    }

    suspend fun duplicateEntry(
        entry: FoodEntryEntity,
        targetDate: LocalDate = entry.entryDate,
        targetMealCategory: MealCategory = entry.mealCategory
    ): Long {
        val copy = entry.copy(
            id = 0L,
            entryDate = targetDate,
            mealCategory = targetMealCategory,
            loggedAt = Instant.now()
        )
        return foodEntryDao.insertEntry(copy)
    }

    suspend fun copyMealEntries(
        sourceDate: LocalDate,
        sourceMealCategory: MealCategory,
        targetDate: LocalDate,
        targetMealCategory: MealCategory = sourceMealCategory
    ): Int {
        val entries = foodEntryDao.getEntriesForDate(sourceDate)
            .filter { it.mealCategory == sourceMealCategory }
        if (entries.isEmpty()) return 0
        val now = Instant.now()
        val copied = entries.mapIndexed { idx, e ->
            e.copy(
                id = 0L,
                entryDate = targetDate,
                mealCategory = targetMealCategory,
                loggedAt = now.plusMillis(idx.toLong())
            )
        }
        foodEntryDao.insertEntries(copied)
        return copied.size
    }

    suspend fun repeatYesterdayIntoDate(targetDate: LocalDate): Int {
        val yesterday = targetDate.minusDays(1)
        val yesterdayEntries = foodEntryDao.getEntriesForDate(yesterday)
        if (yesterdayEntries.isEmpty()) return 0
        val now = Instant.now()
        val copied = yesterdayEntries.mapIndexed { idx, e ->
            e.copy(
                id = 0L,
                entryDate = targetDate,
                loggedAt = now.plusMillis(idx.toLong())
            )
        }
        foodEntryDao.insertEntries(copied)
        return copied.size
    }

    suspend fun createCustomFood(
        name: String,
        aliases: String,
        category: String,
        basis: FoodBasis,
        kcalPer100: Double,
        proteinPer100: Double,
        carbsPer100: Double,
        fatPer100: Double,
        preparation: Preparation = Preparation.NA,
        densityGPerMl: Double? = null,
        defaultServingLabel: String? = null,
        defaultServingGramsOrMl: Double? = null,
        source: FoodSource = FoodSource.USER,
        barcode: String? = null
    ): Long {
        val food = FoodEntity(
            name = name.trim(),
            aliases = aliases.trim().lowercase(),
            category = category.ifBlank { "Custom" }.trim(),
            basis = basis,
            kcalPer100 = kcalPer100,
            proteinPer100 = proteinPer100,
            carbsPer100 = carbsPer100,
            fatPer100 = fatPer100,
            preparation = preparation,
            densityGPerMl = densityGPerMl,
            source = source,
            isCustom = source == FoodSource.USER,
            barcode = barcode
        )
        val foodId = foodDao.insertFood(food)
        if (!defaultServingLabel.isNullOrBlank() && defaultServingGramsOrMl != null && defaultServingGramsOrMl > 0.0) {
            foodServingDao.insertServing(
                FoodServingEntity(
                    foodId = foodId,
                    label = defaultServingLabel.trim().lowercase(),
                    amountGramsOrMl = defaultServingGramsOrMl,
                    isDefault = true
                )
            )
        }
        return foodId
    }

    /**
     * Deleting a custom food removes it from `foods` while foreign key ON DELETE SET NULL
     * ensures existing `food_entries` retain their snapshot name and nutrition unchanged.
     */
    suspend fun deleteCustomFood(foodId: Long) {
        foodDao.deleteFoodById(foodId)
    }

    /**
     * Saves or updates a user-configured household serving weight for a specific food
     * (e.g., when prompted once for an unknown household unit or edited in Foods tab).
     */
    suspend fun saveFoodServing(
        foodId: Long,
        label: String,
        amountGramsOrMl: Double,
        isDefault: Boolean = false
    ): Long {
        if (isDefault) {
            foodServingDao.clearDefaultForFood(foodId)
        }
        val normalizedLabel = NutritionCalculator.normalizeUnitLabel(label).ifBlank { label.trim().lowercase() }
        return foodServingDao.insertServing(
            FoodServingEntity(
                foodId = foodId,
                label = normalizedLabel,
                amountGramsOrMl = amountGramsOrMl,
                isDefault = isDefault
            )
        )
    }

    suspend fun deleteFoodServing(servingId: Long) {
        foodServingDao.deleteServingById(servingId)
    }

    suspend fun toggleFavoriteFood(
        foodId: Long,
        preferredQuantity: Double = 1.0,
        preferredUnit: String = "piece"
    ) {
        val existing = favoriteFoodDao.getFavoriteForFood(foodId)
        if (existing != null) {
            favoriteFoodDao.deleteFavoriteForFood(foodId)
        } else {
            favoriteFoodDao.upsertFavorite(
                FavoriteFoodEntity(
                    foodId = foodId,
                    preferredQuantity = preferredQuantity,
                    preferredUnit = preferredUnit
                )
            )
        }
    }

    suspend fun updateFavoritePreference(
        foodId: Long,
        preferredQuantity: Double,
        preferredUnit: String
    ) {
        favoriteFoodDao.upsertFavorite(
            FavoriteFoodEntity(
                foodId = foodId,
                preferredQuantity = preferredQuantity,
                preferredUnit = preferredUnit
            )
        )
    }

    suspend fun createSavedMeal(
        name: String,
        defaultMealCategory: MealCategory?,
        items: List<Triple<Long, Double, String>>
    ): Long {
        val mealId = savedMealDao.insertSavedMeal(
            SavedMealEntity(
                name = name.trim(),
                defaultMealCategory = defaultMealCategory
            )
        )
        val entities = items.map { (foodId, qty, unit) ->
            SavedMealItemEntity(
                savedMealId = mealId,
                foodId = foodId,
                quantity = qty,
                unit = unit
            )
        }
        savedMealDao.insertSavedMealItems(entities)
        return mealId
    }

    suspend fun deleteSavedMeal(mealId: Long) {
        savedMealDao.deleteSavedMealById(mealId)
    }

    suspend fun logSavedMeal(
        savedMealId: Long,
        entryDate: LocalDate,
        mealCategory: MealCategory
    ): Int {
        val mealWithItems = savedMealDao.getSavedMealWithItemsById(savedMealId) ?: return 0
        var count = 0
        for (item in mealWithItems.items) {
            val foodWithServings = foodDao.getFoodWithServingsById(item.foodId) ?: continue
            val conv = NutritionCalculator.resolveAmountGramsOrMl(
                food = foodWithServings.food,
                servings = foodWithServings.servings,
                quantity = item.quantity,
                rawUnit = item.unit
            )
            val amount = when (conv) {
                is UnitConversionResult.Success -> conv.amountGramsOrMl
                is UnitConversionResult.MissingServingWeight -> item.quantity * 100.0
            }
            logFoodEntry(
                entryDate = entryDate,
                mealCategory = mealCategory,
                foodWithServings = foodWithServings,
                quantity = item.quantity,
                unit = item.unit,
                amountGramsOrMl = amount
            )
            count++
        }
        return count
    }

    suspend fun upsertNutritionTarget(
        effectiveFrom: LocalDate,
        kcal: Double?,
        protein: Double?,
        carbs: Double?,
        fat: Double?
    ) {
        nutritionTargetDao.upsertTarget(
            NutritionTargetEntity(
                effectiveFrom = effectiveFrom,
                kcal = kcal,
                protein = protein,
                carbs = carbs,
                fat = fat
            )
        )
    }

    private suspend fun recordQuantityUsage(
        foodId: Long,
        quantity: Double,
        unit: String,
        usedAt: Instant
    ) {
        val existing = quantityHistoryDao.getHistoryForFoodAndUnit(foodId, unit)
        if (existing != null) {
            quantityHistoryDao.upsertHistory(
                existing.copy(
                    quantity = quantity,
                    useCount = existing.useCount + 1,
                    lastUsedAt = usedAt
                )
            )
        } else {
            quantityHistoryDao.upsertHistory(
                QuantityHistoryEntity(
                    foodId = foodId,
                    quantity = quantity,
                    unit = unit,
                    useCount = 1,
                    lastUsedAt = usedAt
                )
            )
        }
    }
}
