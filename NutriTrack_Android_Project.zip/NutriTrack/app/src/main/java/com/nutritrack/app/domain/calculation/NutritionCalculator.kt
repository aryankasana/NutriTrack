package com.nutritrack.app.domain.calculation

import com.nutritrack.app.data.local.entity.FoodEntity
import com.nutritrack.app.data.local.entity.FoodEntryEntity
import com.nutritrack.app.data.local.entity.FoodServingEntity
import com.nutritrack.app.domain.model.FoodBasis
import java.util.Locale
import kotlin.math.abs
import kotlin.math.roundToInt

data class ComputedNutrition(
    val amountGramsOrMl: Double,
    val kcal: Double,
    val protein: Double,
    val carbs: Double,
    val fat: Double
)

sealed class UnitConversionResult {
    data class Success(
        val canonicalUnit: String,
        val amountGramsOrMl: Double
    ) : UnitConversionResult()

    /**
     * Returned when a household unit (e.g. katori, roti, cup, piece, slice) is not configured
     * for the specific food. Caller must prompt user once and store as a FoodServing, never guess.
     */
    data class MissingServingWeight(
        val foodId: Long,
        val foodName: String,
        val requestedUnit: String,
        val basis: FoodBasis
    ) : UnitConversionResult()
}

data class NutrientProgress(
    val consumed: Double,
    val target: Double?,
    /** Null if target is unset; can be negative when consumed > target */
    val remaining: Double?,
    /** True if target is set and consumed > target */
    val isOverTarget: Boolean,
    /** Positive amount over target when isOverTarget is true, else 0.0 */
    val overageAmount: Double,
    /** Progress fraction in [0f, 1f], or null if target is unset */
    val progressFraction: Float?
)

data class DailyNutritionSummary(
    val kcal: NutrientProgress,
    val protein: NutrientProgress,
    val carbs: NutrientProgress,
    val fat: NutrientProgress,
    val entryCount: Int
)

object NutritionCalculator {

    private val gramAliases = setOf("g", "gm", "gms", "gram", "grams")
    private val kilogramAliases = setOf("kg", "kgs", "kilogram", "kilograms")
    private val mlAliases = setOf("ml", "milliliter", "milliliters", "millilitre", "millilitres")
    private val literAliases = setOf("l", "ltr", "litre", "litres", "liter", "liters")

    fun normalizeUnitLabel(rawUnit: String?): String {
        if (rawUnit.isNullOrBlank()) return ""
        return when (val cleaned = rawUnit.trim().lowercase(Locale.ROOT)) {
            in gramAliases -> "g"
            in kilogramAliases -> "kg"
            in mlAliases -> "ml"
            in literAliases -> "l"
            "pc", "pcs", "piece", "pieces", "no", "nos" -> "piece"
            "slice", "slices" -> "slice"
            "cup", "cups" -> "cup"
            "katori", "katoris", "bowl", "bowls" -> if (cleaned.startsWith("bowl")) "bowl" else "katori"
            "roti", "rotis", "chapati", "chapatis", "phulka", "phulkas" -> "roti"
            "paratha", "parathas" -> "paratha"
            "idli", "idlis" -> "idli"
            "dosa", "dosas" -> "dosa"
            "tbsp", "tablespoon", "tablespoons" -> "tbsp"
            "tsp", "teaspoon", "teaspoons" -> "tsp"
            "scoop", "scoops" -> "scoop"
            "packet", "packets", "pack" -> "packet"
            else -> cleaned
        }
    }

    /**
     * Resolves (quantity, unit) into the food's basis amount (grams for PER_100G, ml for PER_100ML).
     * Never guesses a household serving weight if it is not configured in [servings].
     */
    fun resolveAmountGramsOrMl(
        food: FoodEntity,
        servings: List<FoodServingEntity>,
        quantity: Double,
        rawUnit: String?
    ): UnitConversionResult {
        val normalized = normalizeUnitLabel(rawUnit)

        // If no unit was specified, use the food's default serving (or "piece" serving if present)
        if (normalized.isEmpty()) {
            val defaultServing = servings.firstOrNull { it.isDefault }
                ?: servings.firstOrNull { normalizeUnitLabel(it.label) == "piece" }
                ?: servings.firstOrNull()
            return if (defaultServing != null) {
                UnitConversionResult.Success(
                    canonicalUnit = defaultServing.label,
                    amountGramsOrMl = quantity * defaultServing.amountGramsOrMl
                )
            } else {
                UnitConversionResult.MissingServingWeight(
                    foodId = food.id,
                    foodName = food.name,
                    requestedUnit = "piece",
                    basis = food.basis
                )
            }
        }

        // Direct mass units (g, kg)
        if (normalized == "g" || normalized == "kg") {
            val grams = if (normalized == "kg") quantity * 1000.0 else quantity
            return when (food.basis) {
                FoodBasis.PER_100G -> UnitConversionResult.Success(normalized, grams)
                FoodBasis.PER_100ML -> {
                    val density = food.densityGPerMl
                    if (density != null && density > 0.0) {
                        UnitConversionResult.Success(normalized, grams / density)
                    } else {
                        // Look for an explicit serving or require density/serving configuration
                        UnitConversionResult.MissingServingWeight(
                            foodId = food.id,
                            foodName = food.name,
                            requestedUnit = normalized,
                            basis = food.basis
                        )
                    }
                }
            }
        }

        // Direct volume units (ml, l)
        if (normalized == "ml" || normalized == "l") {
            val ml = if (normalized == "l") quantity * 1000.0 else quantity
            return when (food.basis) {
                FoodBasis.PER_100ML -> UnitConversionResult.Success(normalized, ml)
                FoodBasis.PER_100G -> {
                    val density = food.densityGPerMl
                    if (density != null && density > 0.0) {
                        UnitConversionResult.Success(normalized, ml * density)
                    } else {
                        UnitConversionResult.MissingServingWeight(
                            foodId = food.id,
                            foodName = food.name,
                            requestedUnit = normalized,
                            basis = food.basis
                        )
                    }
                }
            }
        }

        // Household / custom serving units: match against food's configured FoodServing rows.
        // Note: katori and bowl are interchangeable household labels if only one is defined on the food,
        // ONLY when explicitly configured for that specific food.
        val matchingServing = servings.firstOrNull {
            normalizeUnitLabel(it.label) == normalized || it.label.equals(rawUnit?.trim(), ignoreCase = true)
        } ?: if (normalized == "bowl" || normalized == "katori") {
            servings.firstOrNull {
                val l = normalizeUnitLabel(it.label)
                l == "katori" || l == "bowl"
            }
        } else if (normalized == "piece") {
            servings.firstOrNull { it.isDefault }
        } else {
            null
        }

        return if (matchingServing != null) {
            UnitConversionResult.Success(
                canonicalUnit = matchingServing.label,
                amountGramsOrMl = quantity * matchingServing.amountGramsOrMl
            )
        } else {
            UnitConversionResult.MissingServingWeight(
                foodId = food.id,
                foodName = food.name,
                requestedUnit = normalized,
                basis = food.basis
            )
        }
    }

    /**
     * Core formula: nutrient = per-100 value * amount / 100.0.
     * Uses Double internally; never adjusts kcal to match macros.
     */
    fun computeFromAmount(
        food: FoodEntity,
        amountGramsOrMl: Double
    ): ComputedNutrition {
        val factor = amountGramsOrMl / 100.0
        return ComputedNutrition(
            amountGramsOrMl = amountGramsOrMl,
            kcal = food.kcalPer100 * factor,
            protein = food.proteinPer100 * factor,
            carbs = food.carbsPer100 * factor,
            fat = food.fatPer100 * factor
        )
    }

    /**
     * Editing quantity on an existing entry scales the stored values by newAmount / oldAmount.
     */
    fun scaleEntryByAmount(
        entry: FoodEntryEntity,
        newQuantity: Double,
        newUnit: String = entry.unit,
        newAmountGramsOrMl: Double
    ): FoodEntryEntity {
        val ratio = if (entry.amountGramsOrMl > 0.0) {
            newAmountGramsOrMl / entry.amountGramsOrMl
        } else if (entry.quantity > 0.0) {
            newQuantity / entry.quantity
        } else {
            1.0
        }
        return entry.copy(
            quantity = newQuantity,
            unit = newUnit,
            amountGramsOrMl = newAmountGramsOrMl,
            kcal = entry.kcal * ratio,
            protein = entry.protein * ratio,
            carbs = entry.carbs * ratio,
            fat = entry.fat * ratio
        )
    }

    /**
     * Changing the food on an existing entry recalculates nutrition from the new food.
     */
    fun recalculateEntryWithNewFood(
        entry: FoodEntryEntity,
        newFood: FoodEntity,
        newQuantity: Double,
        newUnit: String,
        newAmountGramsOrMl: Double
    ): FoodEntryEntity {
        val computed = computeFromAmount(newFood, newAmountGramsOrMl)
        return entry.copy(
            foodId = newFood.id,
            foodNameSnapshot = newFood.name,
            quantity = newQuantity,
            unit = newUnit,
            amountGramsOrMl = computed.amountGramsOrMl,
            kcal = computed.kcal,
            protein = computed.protein,
            carbs = computed.carbs,
            fat = computed.fat,
            sourceSnapshot = newFood.source
        )
    }

    fun computeNutrientProgress(
        consumed: Double,
        target: Double?
    ): NutrientProgress {
        if (target == null || target <= 0.0) {
            return NutrientProgress(
                consumed = consumed,
                target = null,
                remaining = null,
                isOverTarget = false,
                overageAmount = 0.0,
                progressFraction = null
            )
        }
        val remaining = target - consumed
        val isOver = remaining < -1e-6
        val overage = if (isOver) abs(remaining) else 0.0
        val fraction = (consumed / target).coerceIn(0.0, 1.0).toFloat()
        return NutrientProgress(
            consumed = consumed,
            target = target,
            remaining = remaining,
            isOverTarget = isOver,
            overageAmount = overage,
            progressFraction = fraction
        )
    }

    fun buildDailySummary(
        totalKcal: Double,
        totalProtein: Double,
        totalCarbs: Double,
        totalFat: Double,
        entryCount: Int,
        targetKcal: Double?,
        targetProtein: Double?,
        targetCarbs: Double?,
        targetFat: Double?
    ): DailyNutritionSummary {
        return DailyNutritionSummary(
            kcal = computeNutrientProgress(totalKcal, targetKcal),
            protein = computeNutrientProgress(totalProtein, targetProtein),
            carbs = computeNutrientProgress(totalCarbs, targetCarbs),
            fat = computeNutrientProgress(totalFat, targetFat),
            entryCount = entryCount
        )
    }

    /** Display formatting: kcal rounded to whole integer. */
    fun formatKcal(kcal: Double): String = kcal.roundToInt().toString()

    /** Display formatting: macros rounded to 1 decimal place (or whole if .0 is preferred, we format to 1 decimal). */
    fun formatMacro(grams: Double): String = String.format(Locale.US, "%.1f", grams)

    /** Display formatting for remaining / overage: never hide negative remaining; show "over by X" clearly. */
    fun formatRemainingLabel(progress: NutrientProgress, isKcal: Boolean): String {
        val target = progress.target ?: return "No target set"
        if (target <= 0.0) return "No target set"
        return if (progress.isOverTarget) {
            val amountStr = if (isKcal) {
                "${progress.overageAmount.roundToInt()} kcal"
            } else {
                "${formatMacro(progress.overageAmount)} g"
            }
            "Over by $amountStr"
        } else {
            val rem = (progress.remaining ?: 0.0).coerceAtLeast(0.0)
            val amountStr = if (isKcal) {
                "${rem.roundToInt()} kcal"
            } else {
                "${formatMacro(rem)} g"
            }
            "$amountStr remaining"
        }
    }
}
