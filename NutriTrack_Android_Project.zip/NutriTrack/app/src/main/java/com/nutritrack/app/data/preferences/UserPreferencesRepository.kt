package com.nutritrack.app.data.preferences

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.nutritrack.app.domain.model.MealCategory
import com.nutritrack.app.domain.model.ThemeMode
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "nutritrack_preferences")

data class UserPreferences(
    val themeMode: ThemeMode = ThemeMode.SYSTEM,
    val lastUsedMealCategory: MealCategory = MealCategory.BREAKFAST,
    val openFoodFactsEnabled: Boolean = false,
    val keepQuickAddFocused: Boolean = true
)

class UserPreferencesRepository(private val context: Context) {

    private object Keys {
        val THEME_MODE = stringPreferencesKey("theme_mode")
        val LAST_MEAL_CATEGORY = stringPreferencesKey("last_meal_category")
        val OPEN_FOOD_FACTS_ENABLED = booleanPreferencesKey("open_food_facts_enabled")
        val KEEP_QUICK_ADD_FOCUSED = booleanPreferencesKey("keep_quick_add_focused")
    }

    val preferencesFlow: Flow<UserPreferences> = context.dataStore.data.map { prefs ->
        val theme = prefs[Keys.THEME_MODE]?.let {
            runCatching { ThemeMode.valueOf(it) }.getOrNull()
        } ?: ThemeMode.SYSTEM

        val lastMeal = prefs[Keys.LAST_MEAL_CATEGORY]?.let {
            runCatching { MealCategory.valueOf(it) }.getOrNull()
        } ?: MealCategory.BREAKFAST

        val offEnabled = prefs[Keys.OPEN_FOOD_FACTS_ENABLED] ?: false
        val keepFocused = prefs[Keys.KEEP_QUICK_ADD_FOCUSED] ?: true

        UserPreferences(
            themeMode = theme,
            lastUsedMealCategory = lastMeal,
            openFoodFactsEnabled = offEnabled,
            keepQuickAddFocused = keepFocused
        )
    }

    suspend fun setThemeMode(mode: ThemeMode) {
        context.dataStore.edit { prefs ->
            prefs[Keys.THEME_MODE] = mode.name
        }
    }

    suspend fun setLastUsedMealCategory(category: MealCategory) {
        context.dataStore.edit { prefs ->
            prefs[Keys.LAST_MEAL_CATEGORY] = category.name
        }
    }

    suspend fun setOpenFoodFactsEnabled(enabled: Boolean) {
        context.dataStore.edit { prefs ->
            prefs[Keys.OPEN_FOOD_FACTS_ENABLED] = enabled
        }
    }

    suspend fun setKeepQuickAddFocused(keepFocused: Boolean) {
        context.dataStore.edit { prefs ->
            prefs[Keys.KEEP_QUICK_ADD_FOCUSED] = keepFocused
        }
    }
}
