package com.nutritrack.app.ui.screens.foods

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CloudDownload
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Scale
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.nutritrack.app.data.local.dao.RecentFoodProjection
import com.nutritrack.app.data.local.entity.FavoriteFoodEntity
import com.nutritrack.app.data.local.entity.FoodWithServings
import com.nutritrack.app.data.local.entity.SavedMealWithItems
import com.nutritrack.app.domain.calculation.NutritionCalculator
import com.nutritrack.app.domain.model.FoodBasis
import com.nutritrack.app.domain.model.MealCategory
import com.nutritrack.app.domain.model.Preparation
import com.nutritrack.app.domain.parser.FoodSearchMatcher
import com.nutritrack.app.ui.components.FoodSourceBadge

enum class FoodsTab(val title: String) {
    ALL("All"),
    RECENT("Recent"),
    FAVORITES("Favorites"),
    SAVED_MEALS("Saved meals"),
    CUSTOM("Custom")
}

@Composable
fun FoodsScreen(
    allFoods: List<FoodWithServings>,
    recentFoods: List<RecentFoodProjection>,
    favorites: List<FavoriteFoodEntity>,
    savedMeals: List<SavedMealWithItems>,
    defaultMealCategory: MealCategory,
    openFoodFactsEnabled: Boolean,
    openFoodFactsLoading: Boolean,
    openFoodFactsMessage: String?,
    onQuickLogFood: (FoodWithServings, Double, String) -> Unit,
    onToggleFavorite: (FoodWithServings, Double, String) -> Unit,
    onCreateCustomFood: (
        name: String,
        aliases: String,
        category: String,
        basis: FoodBasis,
        kcalPer100: Double,
        proteinPer100: Double,
        carbsPer100: Double,
        fatPer100: Double,
        preparation: Preparation,
        servingLabel: String?,
        servingWeight: Double?
    ) -> Unit,
    onDeleteCustomFood: (Long) -> Unit,
    onSaveServing: (foodId: Long, label: String, amountGramsOrMl: Double, isDefault: Boolean) -> Unit,
    onDeleteServing: (servingId: Long) -> Unit,
    onCreateSavedMeal: (
        name: String,
        defaultMealCategory: MealCategory?,
        items: List<Triple<Long, Double, String>>
    ) -> Unit,
    onLogSavedMeal: (savedMealId: Long, mealCategory: MealCategory) -> Unit,
    onDeleteSavedMeal: (savedMealId: Long) -> Unit,
    onSearchOpenFoodFacts: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedTabIndex by remember { mutableIntStateOf(0) }
    var searchQuery by remember { mutableStateOf("") }
    var showCreateCustomDialog by remember { mutableStateOf(false) }
    var showCreateSavedMealDialog by remember { mutableStateOf(false) }
    var editingServingsForFood by remember { mutableStateOf<FoodWithServings?>(null) }

    val selectedTab = FoodsTab.entries[selectedTabIndex]
    val favoriteMap = remember(favorites) { favorites.associateBy { it.foodId } }
    val foodById = remember(allFoods) { allFoods.associateBy { it.food.id } }

    val filteredFoods = remember(allFoods, searchQuery, selectedTab, recentFoods, favorites) {
        val baseList = when (selectedTab) {
            FoodsTab.ALL -> allFoods
            FoodsTab.RECENT -> recentFoods.mapNotNull { foodById[it.foodId] }
            FoodsTab.FAVORITES -> favorites.mapNotNull { foodById[it.foodId] }
            FoodsTab.SAVED_MEALS -> emptyList()
            FoodsTab.CUSTOM -> allFoods.filter { it.food.isCustom }
        }
        if (searchQuery.isBlank()) {
            baseList
        } else {
            FoodSearchMatcher.searchFoods(searchQuery, baseList)
        }
    }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        floatingActionButton = {
            FloatingActionButton(
                onClick = {
                    if (selectedTab == FoodsTab.SAVED_MEALS) {
                        showCreateSavedMealDialog = true
                    } else {
                        showCreateCustomDialog = true
                    }
                }
            ) {
                Icon(
                    imageVector = Icons.Default.Add,
                    contentDescription = if (selectedTab == FoodsTab.SAVED_MEALS) "New Saved Meal" else "New Custom Food"
                )
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            ScrollableTabRow(
                selectedTabIndex = selectedTabIndex,
                edgePadding = 16.dp
            ) {
                FoodsTab.entries.forEachIndexed { index, tab ->
                    Tab(
                        selected = selectedTabIndex == index,
                        onClick = { selectedTabIndex = index },
                        text = { Text(tab.title) }
                    )
                }
            }

            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = { Text("Search foods, aliases (roti, dahi, chole)...") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                singleLine = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp)
            )

            if (openFoodFactsEnabled && searchQuery.trim().length >= 3 && selectedTab != FoodsTab.SAVED_MEALS) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 4.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = openFoodFactsMessage ?: "Lookup packaged foods in Open Food Facts (cached offline)",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedButton(
                        onClick = { onSearchOpenFoodFacts(searchQuery.trim()) },
                        enabled = !openFoodFactsLoading
                    ) {
                        Icon(Icons.Default.CloudDownload, contentDescription = null)
                        Text(if (openFoodFactsLoading) " Searching..." else " Lookup OFF")
                    }
                }
            }

            if (selectedTab == FoodsTab.SAVED_MEALS) {
                SavedMealsListContent(
                    savedMeals = savedMeals,
                    foodById = foodById,
                    defaultMealCategory = defaultMealCategory,
                    onLogSavedMeal = onLogSavedMeal,
                    onDeleteSavedMeal = onDeleteSavedMeal,
                    onCreateNew = { showCreateSavedMealDialog = true }
                )
            } else {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    if (filteredFoods.isEmpty()) {
                        item {
                            Text(
                                text = "No matching foods found. Tap '+' to create a custom food.",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.padding(vertical = 24.dp)
                            )
                        }
                    } else {
                        items(
                            items = filteredFoods,
                            key = { it.food.id }
                        ) { item ->
                            val fav = favoriteMap[item.food.id]
                            val defaultServing = item.servings.firstOrNull { it.isDefault } ?: item.servings.firstOrNull()
                            val prefQty = fav?.preferredQuantity ?: 1.0
                            val prefUnit = fav?.preferredUnit ?: (defaultServing?.label ?: "g")

                            FoodCatalogCard(
                                foodWithServings = item,
                                isFavorite = fav != null,
                                preferredQuantity = prefQty,
                                preferredUnit = prefUnit,
                                onQuickLog = { onQuickLogFood(item, prefQty, prefUnit) },
                                onToggleFavorite = { onToggleFavorite(item, prefQty, prefUnit) },
                                onEditServings = { editingServingsForFood = item },
                                onDeleteCustom = if (item.food.isCustom) {
                                    { onDeleteCustomFood(item.food.id) }
                                } else {
                                    null
                                }
                            )
                        }
                    }
                    item { Spacer(modifier = Modifier.height(84.dp)) }
                }
            }
        }
    }

    if (showCreateCustomDialog) {
        CreateCustomFoodDialog(
            onDismiss = { showCreateCustomDialog = false },
            onSave = { name, aliases, category, basis, kcal, p, c, f, prep, srvLabel, srvWeight ->
                onCreateCustomFood(name, aliases, category, basis, kcal, p, c, f, prep, srvLabel, srvWeight)
                showCreateCustomDialog = false
            }
        )
    }

    editingServingsForFood?.let { currentFood ->
        // Keep refreshed from allFoods state
        val latest = allFoods.firstOrNull { it.food.id == currentFood.food.id } ?: currentFood
        EditServingsDialog(
            foodWithServings = latest,
            onDismiss = { editingServingsForFood = null },
            onAddOrUpdateServing = { label, weight, isDefault ->
                onSaveServing(latest.food.id, label, weight, isDefault)
            },
            onDeleteServing = onDeleteServing
        )
    }

    if (showCreateSavedMealDialog) {
        CreateSavedMealDialog(
            allFoods = allFoods,
            defaultMealCategory = defaultMealCategory,
            onDismiss = { showCreateSavedMealDialog = false },
            onSave = { name, category, items ->
                onCreateSavedMeal(name, category, items)
                showCreateSavedMealDialog = false
            }
        )
    }
}

@Composable
private fun FoodCatalogCard(
    foodWithServings: FoodWithServings,
    isFavorite: Boolean,
    preferredQuantity: Double,
    preferredUnit: String,
    onQuickLog: () -> Unit,
    onToggleFavorite: () -> Unit,
    onEditServings: () -> Unit,
    onDeleteCustom: (() -> Unit)?
) {
    val food = foodWithServings.food
    val servingsSummary = foodWithServings.servings.joinToString(", ") {
        "1 ${it.label} = ${it.amountGramsOrMl.toInt()}${food.basis.unitSuffix}"
    }

    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text(
                            text = food.name,
                            style = MaterialTheme.typography.bodyLarge,
                            fontWeight = FontWeight.SemiBold
                        )
                        FoodSourceBadge(source = food.source)
                    }
                    Text(
                        text = "${food.basis.displayName}: ${NutritionCalculator.formatKcal(food.kcalPer100)} kcal | " +
                            "${NutritionCalculator.formatMacro(food.proteinPer100)}P " +
                            "${NutritionCalculator.formatMacro(food.carbsPer100)}C " +
                            "${NutritionCalculator.formatMacro(food.fatPer100)}F",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    if (servingsSummary.isNotEmpty()) {
                        Text(
                            text = "Servings: $servingsSummary",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onToggleFavorite) {
                        Icon(
                            imageVector = if (isFavorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                            contentDescription = "Favorite",
                            tint = if (isFavorite) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    IconButton(onClick = onEditServings) {
                        Icon(Icons.Default.Scale, contentDescription = "Edit servings")
                    }
                    if (onDeleteCustom != null) {
                        IconButton(onClick = onDeleteCustom) {
                            Icon(Icons.Default.Delete, contentDescription = "Delete custom food")
                        }
                    }
                    OutlinedButton(onClick = onQuickLog) {
                        val qtyText = if (preferredQuantity % 1.0 == 0.0) {
                            preferredQuantity.toInt().toString()
                        } else {
                            preferredQuantity.toString()
                        }
                        Text("+ $qtyText $preferredUnit")
                    }
                }
            }
        }
    }
}

@Composable
private fun SavedMealsListContent(
    savedMeals: List<SavedMealWithItems>,
    foodById: Map<Long, FoodWithServings>,
    defaultMealCategory: MealCategory,
    onLogSavedMeal: (Long, MealCategory) -> Unit,
    onDeleteSavedMeal: (Long) -> Unit,
    onCreateNew: () -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        if (savedMeals.isEmpty()) {
            item {
                Column(modifier = Modifier.padding(vertical = 24.dp)) {
                    Text(
                        text = "No saved meals yet",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.SemiBold
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Combine multiple items (e.g., Post-Workout Shake or Standard Lunch Thali) for one-tap logging.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Button(onClick = onCreateNew) {
                        Text("Create Saved Meal")
                    }
                }
            }
        } else {
            items(savedMeals, key = { it.meal.id }) { mealWithItems ->
                val itemsDesc = mealWithItems.items.mapNotNull { item ->
                    val foodName = foodById[item.foodId]?.food?.name ?: return@mapNotNull null
                    "${item.quantity} ${item.unit} $foodName"
                }.joinToString(", ")

                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = mealWithItems.meal.name,
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = itemsDesc.ifEmpty { "Empty meal" },
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Row {
                            IconButton(
                                onClick = {
                                    onLogSavedMeal(
                                        mealWithItems.meal.id,
                                        mealWithItems.meal.defaultMealCategory ?: defaultMealCategory
                                    )
                                }
                            ) {
                                Icon(Icons.Default.PlayArrow, contentDescription = "Log Saved Meal")
                            }
                            IconButton(onClick = { onDeleteSavedMeal(mealWithItems.meal.id) }) {
                                Icon(Icons.Default.Delete, contentDescription = "Delete Saved Meal")
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun CreateCustomFoodDialog(
    initialName: String = "",
    onDismiss: () -> Unit,
    onSave: (
        name: String,
        aliases: String,
        category: String,
        basis: FoodBasis,
        kcalPer100: Double,
        proteinPer100: Double,
        carbsPer100: Double,
        fatPer100: Double,
        preparation: Preparation,
        servingLabel: String?,
        servingWeight: Double?
    ) -> Unit
) {
    var name by remember { mutableStateOf(initialName) }
    var aliases by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("Custom") }
    var basis by remember { mutableStateOf(FoodBasis.PER_100G) }
    var preparation by remember { mutableStateOf(Preparation.NA) }
    var kcalText by remember { mutableStateOf("") }
    var proteinText by remember { mutableStateOf("") }
    var carbsText by remember { mutableStateOf("") }
    var fatText by remember { mutableStateOf("") }
    var servingLabel by remember { mutableStateOf("piece") }
    var servingWeightText by remember { mutableStateOf("100") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Create Custom Food") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Food Name") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = aliases,
                    onValueChange = { aliases = it },
                    label = { Text("Aliases (comma-separated)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FoodBasis.entries.forEach { b ->
                        FilterChip(
                            selected = basis == b,
                            onClick = { basis = b },
                            label = { Text(b.displayName) }
                        )
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Preparation.entries.forEach { prep ->
                        FilterChip(
                            selected = preparation == prep,
                            onClick = { preparation = prep },
                            label = { Text(prep.displayName) }
                        )
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = kcalText,
                        onValueChange = { kcalText = it },
                        label = { Text("kcal / 100") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = proteinText,
                        onValueChange = { proteinText = it },
                        label = { Text("Protein (g)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = carbsText,
                        onValueChange = { carbsText = it },
                        label = { Text("Carbs (g)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = fatText,
                        onValueChange = { fatText = it },
                        label = { Text("Fat (g)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = servingLabel,
                        onValueChange = { servingLabel = it },
                        label = { Text("Default Unit (e.g. katori)") },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = servingWeightText,
                        onValueChange = { servingWeightText = it },
                        label = { Text("Weight (${basis.unitSuffix})") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val kcal = kcalText.toDoubleOrNull() ?: return@Button
                    val p = proteinText.toDoubleOrNull() ?: 0.0
                    val c = carbsText.toDoubleOrNull() ?: 0.0
                    val f = fatText.toDoubleOrNull() ?: 0.0
                    val srvWeight = servingWeightText.toDoubleOrNull()
                    if (name.isNotBlank()) {
                        onSave(
                            name,
                            aliases,
                            category,
                            basis,
                            kcal,
                            p,
                            c,
                            f,
                            preparation,
                            servingLabel.takeIf { it.isNotBlank() },
                            srvWeight
                        )
                    }
                }
            ) {
                Text("Save Food")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}

@Composable
fun EditServingsDialog(
    foodWithServings: FoodWithServings,
    onDismiss: () -> Unit,
    onAddOrUpdateServing: (label: String, amountGramsOrMl: Double, isDefault: Boolean) -> Unit,
    onDeleteServing: (servingId: Long) -> Unit
) {
    var newLabel by remember { mutableStateOf("katori") }
    var newWeightText by remember { mutableStateOf("") }
    var makeDefault by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Serving Sizes • ${foodWithServings.food.name}") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    text = "Never assume one roti or katori weighs the same across foods. Configure exact ${foodWithServings.food.basis.unitSuffix} per unit:",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                foodWithServings.servings.forEach { serving ->
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "1 ${serving.label} = ${serving.amountGramsOrMl} ${foodWithServings.food.basis.unitSuffix}" +
                                if (serving.isDefault) " (Default)" else "",
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = if (serving.isDefault) FontWeight.Bold else FontWeight.Normal
                        )
                        IconButton(onClick = { onDeleteServing(serving.id) }) {
                            Icon(Icons.Default.Delete, contentDescription = "Delete serving")
                        }
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = newLabel,
                        onValueChange = { newLabel = it },
                        label = { Text("Unit (katori, roti...)") },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = newWeightText,
                        onValueChange = { newWeightText = it },
                        label = { Text("Amount (${foodWithServings.food.basis.unitSuffix})") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                }
                FilterChip(
                    selected = makeDefault,
                    onClick = { makeDefault = !makeDefault },
                    label = { Text("Set as default unit for ${foodWithServings.food.name}") }
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val weight = newWeightText.toDoubleOrNull()
                    if (newLabel.isNotBlank() && weight != null && weight > 0.0) {
                        onAddOrUpdateServing(newLabel.trim(), weight, makeDefault)
                        newWeightText = ""
                    }
                }
            ) {
                Text("Add / Update Unit")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Done")
            }
        }
    )
}

@Composable
private fun CreateSavedMealDialog(
    allFoods: List<FoodWithServings>,
    defaultMealCategory: MealCategory,
    onDismiss: () -> Unit,
    onSave: (
        name: String,
        defaultMealCategory: MealCategory?,
        items: List<Triple<Long, Double, String>>
    ) -> Unit
) {
    var mealName by remember { mutableStateOf("") }
    val selectedItems = remember { mutableStateListOf<Triple<Long, Double, String>>() }
    var search by remember { mutableStateOf("") }
    var qtyText by remember { mutableStateOf("1") }
    var unitText by remember { mutableStateOf("piece") }

    val matchingFoods = remember(search, allFoods) {
        FoodSearchMatcher.searchFoods(search, allFoods).take(5)
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Create Saved Meal") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = mealName,
                    onValueChange = { mealName = it },
                    label = { Text("Meal Name (e.g. Post-Workout Shake)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = qtyText,
                        onValueChange = { qtyText = it },
                        label = { Text("Qty") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = unitText,
                        onValueChange = { unitText = it },
                        label = { Text("Unit") },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                }
                OutlinedTextField(
                    value = search,
                    onValueChange = { search = it },
                    label = { Text("Search food to add") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                matchingFoods.forEach { candidate ->
                    TextButton(
                        onClick = {
                            val q = qtyText.toDoubleOrNull() ?: 1.0
                            val defaultUnit = candidate.servings.firstOrNull { it.isDefault }?.label ?: "g"
                            val chosenUnit = unitText.ifBlank { defaultUnit }
                            selectedItems.add(Triple(candidate.food.id, q, chosenUnit))
                        }
                    ) {
                        Text("+ Add ${candidate.food.name}")
                    }
                }
                if (selectedItems.isNotEmpty()) {
                    Text(
                        text = "Selected (${selectedItems.size} items):",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold
                    )
                    selectedItems.forEach { (foodId, q, u) ->
                        val fname = allFoods.firstOrNull { it.food.id == foodId }?.food?.name ?: "Food #$foodId"
                        Text(
                            text = "• $q $u $fname",
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (mealName.isNotBlank() && selectedItems.isNotEmpty()) {
                        onSave(mealName.trim(), defaultMealCategory, selectedItems.toList())
                    }
                }
            ) {
                Text("Save Meal")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}
