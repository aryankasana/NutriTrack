package com.nutritrack.app.ui.screens.quickadd

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.ChevronLeft
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.nutritrack.app.data.local.dao.RecentFoodProjection
import com.nutritrack.app.data.local.entity.FavoriteFoodEntity
import com.nutritrack.app.data.local.entity.FoodWithServings
import com.nutritrack.app.domain.calculation.NutritionCalculator
import com.nutritrack.app.domain.model.FoodBasis
import com.nutritrack.app.domain.model.MealCategory
import com.nutritrack.app.domain.model.Preparation
import com.nutritrack.app.domain.parser.ParsedItemStatus
import com.nutritrack.app.domain.parser.ParsedQuickAddItem
import com.nutritrack.app.domain.parser.QuickAddParser
import com.nutritrack.app.ui.components.FoodSourceBadge
import com.nutritrack.app.ui.screens.foods.CreateCustomFoodDialog
import com.nutritrack.app.ui.screens.home.ManualPortionDialog
import java.time.LocalDate
import java.time.format.DateTimeFormatter

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun QuickAddBottomSheet(
    initialDate: LocalDate,
    initialMealCategory: MealCategory,
    keepFocusedAfterAdd: Boolean,
    allFoods: List<FoodWithServings>,
    recentFoods: List<RecentFoodProjection>,
    favorites: List<FavoriteFoodEntity>,
    onDismiss: () -> Unit,
    onMealCategorySelected: (MealCategory) -> Unit,
    onConfirmBatch: (
        entryDate: LocalDate,
        mealCategory: MealCategory,
        items: List<ParsedQuickAddItem>
    ) -> Unit,
    onOneTapLogChip: (
        entryDate: LocalDate,
        mealCategory: MealCategory,
        food: FoodWithServings,
        quantity: Double,
        unit: String
    ) -> Unit,
    onSaveMissingServingWeight: (
        foodId: Long,
        unitLabel: String,
        amountGramsOrMl: Double
    ) -> Unit,
    onManualEntrySave: (
        entryDate: LocalDate,
        mealCategory: MealCategory,
        foodName: String,
        quantity: Double,
        unit: String,
        kcal: Double,
        protein: Double,
        carbs: Double,
        fat: Double
    ) -> Unit,
    onCreateCustomFood: (
        name: String,
        aliases: String,
        category: String,
        basis: FoodBasis,
        kcalPer100: Double,
        proteinPer100: Double,
        carbsPer100: Double,
        fatPer100: Double,
        preparation: Preparation,
        servingLabel: String?,
        servingWeight: Double?
    ) -> Unit
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    val focusRequester = remember { FocusRequester() }

    var inputText by remember { mutableStateOf("") }
    var selectedDate by remember { mutableStateOf(initialDate) }
    var selectedMealCategory by remember { mutableStateOf(initialMealCategory) }
    var parsedItems by remember { mutableStateOf<List<ParsedQuickAddItem>>(emptyList()) }

    var manualDialogForUnmatched by remember { mutableStateOf<ParsedQuickAddItem?>(null) }
    var customFoodDialogForUnmatched by remember { mutableStateOf<ParsedQuickAddItem?>(null) }
    var showBlankManualDialog by remember { mutableStateOf(false) }

    val foodById = remember(allFoods) { allFoods.associateBy { it.food.id } }
    val dateFormatter = remember { DateTimeFormatter.ofPattern("EEE, dd MMM") }

    // Live deterministic parse as the user types or when catalog updates (e.g. after saving a serving weight)
    LaunchedEffect(inputText, allFoods) {
        parsedItems = QuickAddParser.parseBatch(inputText, allFoods)
    }

    LaunchedEffect(Unit) {
        runCatching { focusRequester.requestFocus() }
    }

    val readyItems = remember(parsedItems) {
        parsedItems.filter { it.matchedFood != null && it.computedNutrition != null }
    }
    val runningKcal = remember(readyItems) { readyItems.sumOf { it.computedNutrition?.kcal ?: 0.0 } }
    val runningP = remember(readyItems) { readyItems.sumOf { it.computedNutrition?.protein ?: 0.0 } }
    val runningC = remember(readyItems) { readyItems.sumOf { it.computedNutrition?.carbs ?: 0.0 } }
    val runningF = remember(readyItems) { readyItems.sumOf { it.computedNutrition?.fat ?: 0.0 } }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // Header: Date chooser + Manual entry button
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Quick-Add Food",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold
                    )
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(onClick = { selectedDate = selectedDate.minusDays(1) }) {
                            Icon(Icons.Default.ChevronLeft, contentDescription = "Previous date")
                        }
                        Text(
                            text = selectedDate.format(dateFormatter),
                            style = MaterialTheme.typography.labelLarge,
                            fontWeight = FontWeight.SemiBold
                        )
                        IconButton(onClick = { selectedDate = selectedDate.plusDays(1) }) {
                            Icon(Icons.Default.ChevronRight, contentDescription = "Next date")
                        }
                    }
                }
            }

            // Meal category chips (last used preselected)
            item {
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    MealCategory.entries.forEach { category ->
                        FilterChip(
                            selected = selectedMealCategory == category,
                            onClick = {
                                selectedMealCategory = category
                                onMealCategorySelected(category)
                            },
                            label = { Text(category.displayName) }
                        )
                    }
                }
            }

            // One-tap Favorite & Recent chips
            if (favorites.isNotEmpty() || recentFoods.isNotEmpty()) {
                item {
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text(
                            text = "One-Tap Favorites & Recents",
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            items(favorites, key = { "fav_${it.foodId}" }) { fav ->
                                val food = foodById[fav.foodId] ?: return@items
                                val qtyText = if (fav.preferredQuantity % 1.0 == 0.0) {
                                    fav.preferredQuantity.toInt().toString()
                                } else {
                                    fav.preferredQuantity.toString()
                                }
                                AssistChip(
                                    onClick = {
                                        onOneTapLogChip(
                                            selectedDate,
                                            selectedMealCategory,
                                            food,
                                            fav.preferredQuantity,
                                            fav.preferredUnit
                                        )
                                    },
                                    label = { Text("★ ${food.food.name} ($qtyText ${fav.preferredUnit})") }
                                )
                            }
                            items(recentFoods, key = { "rec_${it.foodId}" }) { rec ->
                                val food = foodById[rec.foodId] ?: return@items
                                val qtyText = if (rec.lastQuantity % 1.0 == 0.0) {
                                    rec.lastQuantity.toInt().toString()
                                } else {
                                    rec.lastQuantity.toString()
                                }
                                AssistChip(
                                    onClick = {
                                        onOneTapLogChip(
                                            selectedDate,
                                            selectedMealCategory,
                                            food,
                                            rec.lastQuantity,
                                            rec.lastUnit
                                        )
                                    },
                                    label = { Text("${food.food.name} ($qtyText ${rec.lastUnit})") }
                                )
                            }
                        }
                    }
                }
            }

            // Fast multi-item text field
            item {
                OutlinedTextField(
                    value = inputText,
                    onValueChange = { inputText = it },
                    label = { Text("Type items (e.g. 3 roti, 200 ml milk, 1 banana, 100 g paneer)") },
                    placeholder = { Text("3 roti, 200 ml milk, 1 banana, 100 g paneer") },
                    trailingIcon = {
                        if (inputText.isNotEmpty()) {
                            IconButton(onClick = { inputText = "" }) {
                                Icon(Icons.Default.Close, contentDescription = "Clear")
                            }
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .focusRequester(focusRequester)
                )
            }

            // Live Preview Rows
            if (parsedItems.isNotEmpty()) {
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f)
                        )
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = "Running Meal Total (${readyItems.size}/${parsedItems.size} ready)",
                                    style = MaterialTheme.typography.labelLarge,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "${NutritionCalculator.formatKcal(runningKcal)} kcal • " +
                                        "${NutritionCalculator.formatMacro(runningP)}g P • " +
                                        "${NutritionCalculator.formatMacro(runningC)}g C • " +
                                        "${NutritionCalculator.formatMacro(runningF)}g F",
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                            Button(
                                onClick = {
                                    if (readyItems.isNotEmpty()) {
                                        onConfirmBatch(selectedDate, selectedMealCategory, readyItems)
                                        inputText = ""
                                        parsedItems = emptyList()
                                        if (keepFocusedAfterAdd) {
                                            runCatching { focusRequester.requestFocus() }
                                        } else {
                                            onDismiss()
                                        }
                                    }
                                },
                                enabled = readyItems.isNotEmpty()
                            ) {
                                Icon(Icons.Default.Check, contentDescription = null)
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Add all (${readyItems.size})")
                            }
                        }
                    }
                }

                itemsIndexed(
                    items = parsedItems,
                    key = { index, item -> "${index}_${item.rawSegment}" }
                ) { index, item ->
                    ParsedPreviewRowCard(
                        item = item,
                        allFoods = allFoods,
                        onUpdateRow = { updated ->
                            parsedItems = parsedItems.toMutableList().also { it[index] = updated }
                        },
                        onRemoveRow = {
                            parsedItems = parsedItems.toMutableList().also { it.removeAt(index) }
                        },
                        onSaveMissingServing = { foodId, unitLabel, weight ->
                            onSaveMissingServingWeight(foodId, unitLabel, weight)
                        },
                        onEnterManually = { manualDialogForUnmatched = item },
                        onSaveAsCustomFood = { customFoodDialogForUnmatched = item }
                    )
                }
            }

            // Manual fallback button
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    TextButton(onClick = { showBlankManualDialog = true }) {
                        Icon(Icons.Default.Add, contentDescription = null)
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Log Manual Portion")
                    }
                    TextButton(onClick = onDismiss) {
                        Text("Close")
                    }
                }
                Spacer(modifier = Modifier.height(24.dp))
            }
        }
    }

    if (showBlankManualDialog) {
        ManualPortionDialog(
            initialMealCategory = selectedMealCategory,
            onDismiss = { showBlankManualDialog = false },
            onConfirm = { meal, name, qty, unit, kcal, p, c, f ->
                onManualEntrySave(selectedDate, meal, name, qty, unit, kcal, p, c, f)
                showBlankManualDialog = false
            }
        )
    }

    manualDialogForUnmatched?.let { unmatched ->
        ManualPortionDialog(
            initialMealCategory = selectedMealCategory,
            initialFoodName = unmatched.extractedFoodName,
            initialQuantity = unmatched.quantity.toString(),
            initialUnit = unmatched.resolvedUnit,
            onDismiss = { manualDialogForUnmatched = null },
            onConfirm = { meal, name, qty, unit, kcal, p, c, f ->
                onManualEntrySave(selectedDate, meal, name, qty, unit, kcal, p, c, f)
                parsedItems = parsedItems.filterNot { it === unmatched }
                manualDialogForUnmatched = null
            }
        )
    }

    customFoodDialogForUnmatched?.let { unmatched ->
        CreateCustomFoodDialog(
            initialName = unmatched.extractedFoodName,
            onDismiss = { customFoodDialogForUnmatched = null },
            onSave = { name, aliases, category, basis, kcal, p, c, f, prep, srvLabel, srvWeight ->
                onCreateCustomFood(name, aliases, category, basis, kcal, p, c, f, prep, srvLabel, srvWeight)
                customFoodDialogForUnmatched = null
            }
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ParsedPreviewRowCard(
    item: ParsedQuickAddItem,
    allFoods: List<FoodWithServings>,
    onUpdateRow: (ParsedQuickAddItem) -> Unit,
    onRemoveRow: () -> Unit,
    onSaveMissingServing: (foodId: Long, unitLabel: String, weightGramsOrMl: Double) -> Unit,
    onEnterManually: () -> Unit,
    onSaveAsCustomFood: () -> Unit
) {
    var qtyText by remember(item.quantity) {
        val formatted = if (item.quantity % 1.0 == 0.0) {
            item.quantity.toInt().toString()
        } else {
            item.quantity.toString()
        }
        mutableStateOf(formatted)
    }
    var unitText by remember(item.resolvedUnit) { mutableStateOf(item.resolvedUnit) }
    var dropdownExpanded by remember { mutableStateOf(false) }
    var missingWeightInput by remember { mutableStateOf("") }

    val dropdownOptions = remember(item, allFoods) {
        if (item.candidateFoods.isNotEmpty()) item.candidateFoods else allFoods.take(30)
    }

    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = when (item.status) {
                ParsedItemStatus.MATCHED -> MaterialTheme.colorScheme.surface
                ParsedItemStatus.AMBIGUOUS -> MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.45f)
                ParsedItemStatus.UNMATCHED -> MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.35f)
            }
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(10.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    val statusBadge = when (item.status) {
                        ParsedItemStatus.MATCHED -> "MATCHED"
                        ParsedItemStatus.AMBIGUOUS -> "AMBIGUOUS • Pick one"
                        ParsedItemStatus.UNMATCHED -> "UNMATCHED"
                    }
                    Text(
                        text = statusBadge,
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = when (item.status) {
                            ParsedItemStatus.MATCHED -> MaterialTheme.colorScheme.primary
                            ParsedItemStatus.AMBIGUOUS -> MaterialTheme.colorScheme.tertiary
                            ParsedItemStatus.UNMATCHED -> MaterialTheme.colorScheme.error
                        }
                    )
                    item.matchedFood?.food?.let { matchedFood ->
                        FoodSourceBadge(source = matchedFood.source)
                    }
                }
                IconButton(onClick = onRemoveRow) {
                    Icon(Icons.Default.Close, contentDescription = "Remove item")
                }
            }

            // Editable Row: Qty, Unit, Food Dropdown
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedTextField(
                    value = qtyText,
                    onValueChange = { newText ->
                        qtyText = newText
                        val parsedQty = QuickAddParser.parseSingleQuantityToken(newText)
                        if (parsedQty != null && parsedQty > 0.0) {
                            onUpdateRow(
                                QuickAddParser.recalculateItem(
                                    item = item,
                                    newQuantity = parsedQty,
                                    newUnit = unitText
                                )
                            )
                        }
                    },
                    label = { Text("Qty") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    singleLine = true,
                    modifier = Modifier.width(76.dp)
                )

                OutlinedTextField(
                    value = unitText,
                    onValueChange = { newUnit ->
                        unitText = newUnit
                        onUpdateRow(
                            QuickAddParser.recalculateItem(
                                item = item,
                                newQuantity = item.quantity,
                                newUnit = newUnit
                            )
                        )
                    },
                    label = { Text("Unit") },
                    singleLine = true,
                    modifier = Modifier.width(88.dp)
                )

                ExposedDropdownMenuBox(
                    expanded = dropdownExpanded,
                    onExpandedChange = { dropdownExpanded = !dropdownExpanded },
                    modifier = Modifier.weight(1f)
                ) {
                    OutlinedTextField(
                        value = item.matchedFood?.food?.name
                            ?: "Select for '${item.extractedFoodName}'",
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("Food") },
                        trailingIcon = {
                            ExposedDropdownMenuDefaults.TrailingIcon(expanded = dropdownExpanded)
                        },
                        singleLine = true,
                        modifier = Modifier
                            .menuAnchor()
                            .fillMaxWidth()
                    )
                    ExposedDropdownMenu(
                        expanded = dropdownExpanded,
                        onDismissRequest = { dropdownExpanded = false }
                    ) {
                        dropdownOptions.forEach { option ->
                            DropdownMenuItem(
                                text = { Text("${option.food.name} (${option.food.source.badgeLabel})") },
                                onClick = {
                                    dropdownExpanded = false
                                    onUpdateRow(
                                        QuickAddParser.recalculateItem(
                                            item = item,
                                            newSelectedFood = option
                                        )
                                    )
                                }
                            )
                        }
                    }
                }
            }

            // Live nutrition or prompt for unconfigured household serving weight
            val computed = item.computedNutrition
            val missingUnit = item.missingServingUnit
            val matchedFood = item.matchedFood

            if (computed != null) {
                Text(
                    text = "${computed.amountGramsOrMl.toInt()} ${matchedFood?.food?.basis?.unitSuffix ?: "g"} → " +
                        "${NutritionCalculator.formatKcal(computed.kcal)} kcal | " +
                        "${NutritionCalculator.formatMacro(computed.protein)}g P • " +
                        "${NutritionCalculator.formatMacro(computed.carbs)}g C • " +
                        "${NutritionCalculator.formatMacro(computed.fat)}g F",
                    style = MaterialTheme.typography.bodySmall,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.onSurface
                )
            } else if (missingUnit != null && matchedFood != null) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        Icons.Default.Warning,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.error
                    )
                    OutlinedTextField(
                        value = missingWeightInput,
                        onValueChange = { missingWeightInput = it },
                        label = {
                            Text("1 $missingUnit of ${matchedFood.food.name} in ${matchedFood.food.basis.unitSuffix}?")
                        },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    Button(
                        onClick = {
                            val w = missingWeightInput.toDoubleOrNull()
                            if (w != null && w > 0.0) {
                                onSaveMissingServing(matchedFood.food.id, missingUnit, w)
                            }
                        }
                    ) {
                        Text("Save Unit")
                    }
                }
            }

            // Unmatched actions: enter manually or save as custom food
            if (item.status == ParsedItemStatus.UNMATCHED && item.matchedFood == null) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = onEnterManually) {
                        Text("Enter Manually")
                    }
                    OutlinedButton(onClick = onSaveAsCustomFood) {
                        Text("Save as Custom Food")
                    }
                }
            }
        }
    }
}
