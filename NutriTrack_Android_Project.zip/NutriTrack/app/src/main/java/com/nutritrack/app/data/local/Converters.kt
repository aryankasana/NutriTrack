package com.nutritrack.app.data.local

import androidx.room.TypeConverter
import com.nutritrack.app.domain.model.FoodBasis
import com.nutritrack.app.domain.model.FoodSource
import com.nutritrack.app.domain.model.MealCategory
import com.nutritrack.app.domain.model.Preparation
import java.time.Instant
import java.time.LocalDate

class Converters {
    @TypeConverter
    fun fromLocalDate(date: LocalDate?): String? = date?.toString()

    @TypeConverter
    fun toLocalDate(value: String?): LocalDate? = value?.let { LocalDate.parse(it) }

    @TypeConverter
    fun fromInstant(instant: Instant?): Long? = instant?.toEpochMilli()

    @TypeConverter
    fun toInstant(epochMilli: Long?): Instant? = epochMilli?.let { Instant.ofEpochMilli(it) }

    @TypeConverter
    fun fromFoodBasis(basis: FoodBasis): String = basis.name

    @TypeConverter
    fun toFoodBasis(value: String): FoodBasis = FoodBasis.valueOf(value)

    @TypeConverter
    fun fromPreparation(prep: Preparation): String = prep.name

    @TypeConverter
    fun toPreparation(value: String): Preparation = Preparation.valueOf(value)

    @TypeConverter
    fun fromFoodSource(source: FoodSource): String = source.name

    @TypeConverter
    fun toFoodSource(value: String): FoodSource = FoodSource.valueOf(value)

    @TypeConverter
    fun fromMealCategory(category: MealCategory): String = category.name

    @TypeConverter
    fun toMealCategory(value: String): MealCategory = MealCategory.valueOf(value)
}
