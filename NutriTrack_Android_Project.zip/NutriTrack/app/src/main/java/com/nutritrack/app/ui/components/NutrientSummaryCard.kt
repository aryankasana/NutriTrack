package com.nutritrack.app.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.nutritrack.app.domain.calculation.NutrientProgress
import com.nutritrack.app.domain.calculation.NutritionCalculator
import com.nutritrack.app.domain.model.FoodSource
import com.nutritrack.app.ui.theme.OverageErrorColor

@Composable
fun NutrientSummaryCard(
    title: String,
    unitSuffix: String,
    progress: NutrientProgress,
    isKcal: Boolean,
    accentColor: Color,
    modifier: Modifier = Modifier
) {
    val consumedText = if (isKcal) {
        NutritionCalculator.formatKcal(progress.consumed)
    } else {
        NutritionCalculator.formatMacro(progress.consumed)
    }
    val targetText = progress.target?.let {
        if (isKcal) NutritionCalculator.formatKcal(it) else NutritionCalculator.formatMacro(it)
    }
    val remainingLabel = NutritionCalculator.formatRemainingLabel(progress, isKcal)

    Card(
        modifier = modifier,
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f)
        ),
        shape = RoundedCornerShape(14.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.labelLarge,
                    color = accentColor,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = if (targetText != null) {
                        "$consumedText / $targetText $unitSuffix"
                    } else {
                        "$consumedText $unitSuffix"
                    },
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.SemiBold
                )
            }

            Spacer(modifier = Modifier.height(6.dp))

            // Unset target = no remaining and no progress bar for that nutrient
            if (progress.target != null && progress.progressFraction != null) {
                LinearProgressIndicator(
                    progress = { progress.progressFraction },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(7.dp)
                        .clip(RoundedCornerShape(4.dp)),
                    color = if (progress.isOverTarget) OverageErrorColor else accentColor,
                    trackColor = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.12f)
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = remainingLabel,
                    style = MaterialTheme.typography.labelSmall,
                    color = if (progress.isOverTarget) {
                        OverageErrorColor
                    } else {
                        MaterialTheme.colorScheme.onSurfaceVariant
                    },
                    fontWeight = if (progress.isOverTarget) FontWeight.Bold else FontWeight.Normal
                )
            } else {
                Text(
                    text = "Target unset",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
fun FoodSourceBadge(
    source: FoodSource,
    modifier: Modifier = Modifier
) {
    val containerColor = when (source) {
        FoodSource.ESTIMATE -> MaterialTheme.colorScheme.tertiaryContainer
        FoodSource.USER -> MaterialTheme.colorScheme.secondaryContainer
        FoodSource.OFF -> MaterialTheme.colorScheme.primaryContainer
        FoodSource.IFCT, FoodSource.USDA -> MaterialTheme.colorScheme.surfaceVariant
    }
    val contentColor = when (source) {
        FoodSource.ESTIMATE -> MaterialTheme.colorScheme.onTertiaryContainer
        FoodSource.USER -> MaterialTheme.colorScheme.onSecondaryContainer
        FoodSource.OFF -> MaterialTheme.colorScheme.onPrimaryContainer
        FoodSource.IFCT, FoodSource.USDA -> MaterialTheme.colorScheme.onSurfaceVariant
    }
    Surface(
        modifier = modifier,
        color = containerColor,
        contentColor = contentColor,
        shape = RoundedCornerShape(6.dp)
    ) {
        Box(modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)) {
            Text(
                text = source.badgeLabel,
                style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.Medium
            )
        }
    }
}
