package com.nutritrack.app.domain.parser

import com.nutritrack.app.data.local.entity.FoodWithServings
import com.nutritrack.app.domain.calculation.ComputedNutrition
import com.nutritrack.app.domain.calculation.NutritionCalculator
import com.nutritrack.app.domain.calculation.UnitConversionResult
import com.nutritrack.app.domain.model.Preparation
import java.util.Locale

enum class ParsedItemStatus {
    MATCHED,
    AMBIGUOUS,
    UNMATCHED
}

data class ParsedQuickAddItem(
    val rawSegment: String,
    val quantity: Double,
    /** Normalized unit ("g", "ml", "piece", "slice", "cup", "katori", "bowl", "tbsp", "tsp", or "" when no unit given) */
    val parsedUnit: String,
    /** Display/resolved unit for the matched food (e.g. "roti", "piece", "g") */
    val resolvedUnit: String,
    val extractedFoodName: String,
    val preparationHint: Preparation?,
    val status: ParsedItemStatus,
    val matchedFood: FoodWithServings? = null,
    val candidateFoods: List<FoodWithServings> = emptyList(),
    val computedNutrition: ComputedNutrition? = null,
    val missingServingUnit: String? = null
)

object QuickAddParser {

    private val wordQuantities = mapOf(
        "a" to 1.0,
        "an" to 1.0,
        "one" to 1.0,
        "two" to 2.0,
        "three" to 3.0,
        "four" to 4.0,
        "five" to 5.0,
        "six" to 6.0,
        "seven" to 7.0,
        "eight" to 8.0,
        "nine" to 9.0,
        "ten" to 10.0,
        "half" to 0.5,
        "quarter" to 0.25
    )

    private val unicodeFractions = mapOf(
        '½' to 0.5,
        '¼' to 0.25,
        '¾' to 0.75,
        '⅓' to (1.0 / 3.0),
        '⅔' to (2.0 / 3.0)
    )

    /**
     * Explicit unit aliases recognized by the parser.
     * Note: "roti", "paratha", "idli", "dosa" are food names first when used as "3 roti",
     * so they are NOT stripped as units unless another food name remains.
     */
    private val explicitUnitAliases = mapOf(
        "g" to "g",
        "gm" to "gm",
        "gms" to "gms",
        "gram" to "gram",
        "grams" to "grams",
        "kg" to "kg",
        "kgs" to "kgs",
        "kilogram" to "kilogram",
        "kilograms" to "kilograms",
        "ml" to "ml",
        "milliliter" to "ml",
        "millilitre" to "ml",
        "l" to "l",
        "ltr" to "ltr",
        "litre" to "litre",
        "litres" to "litre",
        "liter" to "liter",
        "liters" to "liter",
        "pc" to "pc",
        "pcs" to "pcs",
        "piece" to "piece",
        "pieces" to "pieces",
        "slice" to "slice",
        "slices" to "slices",
        "cup" to "cup",
        "cups" to "cups",
        "katori" to "katori",
        "katoris" to "katoris",
        "bowl" to "bowl",
        "bowls" to "bowls",
        "tbsp" to "tbsp",
        "tablespoon" to "tbsp",
        "tablespoons" to "tbsp",
        "tsp" to "tsp",
        "teaspoon" to "tsp",
        "teaspoons" to "tsp",
        "scoop" to "scoop",
        "scoops" to "scoops",
        "packet" to "packet",
        "packets" to "packet"
    )

    private val rawPrepWords = setOf("raw", "uncooked", "dry", "kacha")
    private val cookedPrepWords = setOf("cooked", "boiled", "steamed", "fried", "grilled", "roasted")

    private val delimiterRegex = Regex("""(?i)\s*(?:,|\+|\r?\n|;|\band\b)\s*""")

    // Matches glued number+unit like "200g", "250ml", "1.5kg", "1/2cup", "½cup"
    private val gluedQtyUnitRegex = Regex(
        """^(\d+(?:\.\d+)?|\d+/\d+|(?:\d+)?[½¼¾⅓⅔])([a-zA-Z]+)$"""
    )

    fun parseBatch(
        rawInput: String,
        catalog: List<FoodWithServings>
    ): List<ParsedQuickAddItem> {
        if (rawInput.isBlank()) return emptyList()

        val segments = rawInput
            .split(delimiterRegex)
            .map { it.trim() }
            .filter { it.isNotEmpty() }

        return segments.map { segment ->
            parseSegment(segment, catalog)
        }
    }

    fun parseSegment(
        segment: String,
        catalog: List<FoodWithServings>
    ): ParsedQuickAddItem {
        val rawTokens = tokenizeSegment(segment)
        if (rawTokens.isEmpty()) {
            return ParsedQuickAddItem(
                rawSegment = segment,
                quantity = 1.0,
                parsedUnit = "",
                resolvedUnit = "piece",
                extractedFoodName = "",
                preparationHint = null,
                status = ParsedItemStatus.UNMATCHED
            )
        }

        var quantity = 1.0
        var unit = ""
        var foodTokens: List<String> = rawTokens

        // Case 1: Leading quantity (e.g. "3 roti", "200 ml milk", "1/2 cup curd", "1 1/2 katori dal", "2 bread slices")
        val leadingQty = parseLeadingQuantity(rawTokens)
        if (leadingQty != null) {
            quantity = leadingQty.first
            val afterQty = rawTokens.drop(leadingQty.second)
            if (afterQty.isNotEmpty()) {
                val firstAfter = afterQty.first().lowercase(Locale.ROOT)
                val lastAfter = afterQty.last().lowercase(Locale.ROOT)

                if (afterQty.size >= 2 && firstAfter in explicitUnitAliases) {
                    // "[qty] [unit] [name]" -> "200 ml milk", "1 bowl dal", "1.5 katori rajma"
                    unit = NutritionCalculator.normalizeUnitLabel(firstAfter)
                    foodTokens = afterQty.drop(1)
                } else if (afterQty.size >= 2 && lastAfter in explicitUnitAliases) {
                    // "[qty] [name] [unit]" -> "2 bread slices"
                    unit = NutritionCalculator.normalizeUnitLabel(lastAfter)
                    foodTokens = afterQty.dropLast(1)
                } else {
                    // "[qty] [name]" -> "3 roti", "1 banana", "3 eggs"
                    foodTokens = afterQty
                }
            }
        } else {
            // Case 2: Trailing quantity + optional unit (e.g. "paneer 100g", "paneer 100 g", "roti 3")
            val trailing = parseTrailingQuantityAndUnit(rawTokens)
            if (trailing != null) {
                quantity = trailing.quantity
                unit = trailing.unit
                foodTokens = trailing.remainingTokens
            }
        }

        // Remove filler "of" at the start of foodTokens (e.g., "1 cup of milk")
        if (foodTokens.size >= 2 && foodTokens.first().equals("of", ignoreCase = true)) {
            foodTokens = foodTokens.drop(1)
        }

        val prepHint = inferPreparation(foodTokens)
        val cleanedFoodTokens = foodTokens.filterNot {
            val low = it.lowercase(Locale.ROOT)
            low in rawPrepWords || low in cookedPrepWords
        }
        val extractedName = (if (cleanedFoodTokens.isNotEmpty()) cleanedFoodTokens else foodTokens)
            .joinToString(" ")
            .trim()

        val matchOutcome = FoodSearchMatcher.matchFoodName(
            rawFoodQuery = extractedName,
            explicitPrep = prepHint,
            catalog = catalog
        )

        return when (matchOutcome) {
            is FoodMatchOutcome.Matched -> {
                val matched = matchOutcome.foodWithServings
                buildMatchedItem(
                    rawSegment = segment,
                    quantity = quantity,
                    parsedUnit = unit,
                    extractedFoodName = extractedName,
                    preparationHint = prepHint,
                    status = ParsedItemStatus.MATCHED,
                    selectedFood = matched,
                    candidates = listOf(matched)
                )
            }
            is FoodMatchOutcome.Ambiguous -> {
                ParsedQuickAddItem(
                    rawSegment = segment,
                    quantity = quantity,
                    parsedUnit = unit,
                    resolvedUnit = unit.ifEmpty { "piece" },
                    extractedFoodName = extractedName,
                    preparationHint = prepHint,
                    status = ParsedItemStatus.AMBIGUOUS,
                    matchedFood = null,
                    candidateFoods = matchOutcome.candidates,
                    computedNutrition = null,
                    missingServingUnit = null
                )
            }
            is FoodMatchOutcome.Unmatched -> {
                ParsedQuickAddItem(
                    rawSegment = segment,
                    quantity = quantity,
                    parsedUnit = unit,
                    resolvedUnit = unit.ifEmpty { "piece" },
                    extractedFoodName = extractedName,
                    preparationHint = prepHint,
                    status = ParsedItemStatus.UNMATCHED,
                    matchedFood = null,
                    candidateFoods = matchOutcome.suggestions,
                    computedNutrition = null,
                    missingServingUnit = null
                )
            }
        }
    }

    /**
     * Re-evaluates a single preview row when the user edits its quantity, unit, or selected food.
     */
    fun recalculateItem(
        item: ParsedQuickAddItem,
        newQuantity: Double = item.quantity,
        newUnit: String = item.parsedUnit,
        newSelectedFood: FoodWithServings? = item.matchedFood
    ): ParsedQuickAddItem {
        if (newSelectedFood == null) {
            return item.copy(
                quantity = newQuantity,
                parsedUnit = newUnit,
                resolvedUnit = newUnit.ifEmpty { "piece" },
                matchedFood = null,
                computedNutrition = null,
                missingServingUnit = null
            )
        }
        return buildMatchedItem(
            rawSegment = item.rawSegment,
            quantity = newQuantity,
            parsedUnit = newUnit,
            extractedFoodName = item.extractedFoodName,
            preparationHint = item.preparationHint,
            status = ParsedItemStatus.MATCHED,
            selectedFood = newSelectedFood,
            candidates = if (item.candidateFoods.isEmpty()) listOf(newSelectedFood) else item.candidateFoods
        )
    }

    private fun buildMatchedItem(
        rawSegment: String,
        quantity: Double,
        parsedUnit: String,
        extractedFoodName: String,
        preparationHint: Preparation?,
        status: ParsedItemStatus,
        selectedFood: FoodWithServings,
        candidates: List<FoodWithServings>
    ): ParsedQuickAddItem {
        return when (val conv = NutritionCalculator.resolveAmountGramsOrMl(
            food = selectedFood.food,
            servings = selectedFood.servings,
            quantity = quantity,
            rawUnit = parsedUnit
        )) {
            is UnitConversionResult.Success -> {
                val computed = NutritionCalculator.computeFromAmount(
                    food = selectedFood.food,
                    amountGramsOrMl = conv.amountGramsOrMl
                )
                ParsedQuickAddItem(
                    rawSegment = rawSegment,
                    quantity = quantity,
                    parsedUnit = parsedUnit,
                    resolvedUnit = conv.canonicalUnit,
                    extractedFoodName = extractedFoodName,
                    preparationHint = preparationHint,
                    status = status,
                    matchedFood = selectedFood,
                    candidateFoods = candidates,
                    computedNutrition = computed,
                    missingServingUnit = null
                )
            }
            is UnitConversionResult.MissingServingWeight -> {
                ParsedQuickAddItem(
                    rawSegment = rawSegment,
                    quantity = quantity,
                    parsedUnit = parsedUnit,
                    resolvedUnit = conv.requestedUnit,
                    extractedFoodName = extractedFoodName,
                    preparationHint = preparationHint,
                    status = status,
                    matchedFood = selectedFood,
                    candidateFoods = candidates,
                    computedNutrition = null,
                    missingServingUnit = conv.requestedUnit
                )
            }
        }
    }

    /**
     * Splits a segment into whitespace tokens while splitting glued number+unit tokens
     * such as "200g" -> ["200", "g"], "250ml" -> ["250", "ml"], "1.5kg" -> ["1.5", "kg"].
     */
    private fun tokenizeSegment(segment: String): List<String> {
        val rawParts = segment.trim().split(Regex("\\s+")).filter { it.isNotEmpty() }
        val expanded = mutableListOf<String>()
        for (part in rawParts) {
            val match = gluedQtyUnitRegex.matchEntire(part)
            if (match != null) {
                val numPart = match.groupValues[1]
                val unitPart = match.groupValues[2].lowercase(Locale.ROOT)
                if (unitPart in explicitUnitAliases) {
                    expanded.add(numPart)
                    expanded.add(unitPart)
                    continue
                }
            }
            expanded.add(part)
        }
        return expanded
    }

    /**
     * Parses a leading quantity from [tokens] and returns (quantityValue, tokensConsumed).
     * Supports:
     * - mixed fractions ("1 1/2") -> (1.5, 2)
     * - fractions ("1/2") -> (0.5, 1)
     * - unicode fractions ("½", "1½") -> (0.5 / 1.5, 1)
     * - decimals and integers ("3", "1.5", "200") -> (value, 1)
     * - quantity words ("one", "two", "half") -> (value, 1)
     */
    private fun parseLeadingQuantity(tokens: List<String>): Pair<Double, Int>? {
        if (tokens.isEmpty()) return null

        // Check 2-token mixed fraction like "1 1/2"
        if (tokens.size >= 2) {
            val firstInt = tokens[0].toIntOrNull()
            val secondFrac = parseSimpleFractionOrUnicode(tokens[1])
            if (firstInt != null && secondFrac != null) {
                return (firstInt.toDouble() + secondFrac) to 2
            }
        }

        val single = parseSingleQuantityToken(tokens[0])
        return single?.let { it to 1 }
    }

    private data class TrailingParse(
        val quantity: Double,
        val unit: String,
        val remainingTokens: List<String>
    )

    private fun parseTrailingQuantityAndUnit(tokens: List<String>): TrailingParse? {
        if (tokens.size < 2) return null

        val lastLower = tokens.last().lowercase(Locale.ROOT)
        if (lastLower in explicitUnitAliases && tokens.size >= 3) {
            // Check 2-token mixed fraction before unit: e.g. "rajma 1 1/2 katori"
            if (tokens.size >= 4) {
                val intPart = tokens[tokens.size - 3].toIntOrNull()
                val fracPart = parseSimpleFractionOrUnicode(tokens[tokens.size - 2])
                if (intPart != null && fracPart != null) {
                    return TrailingParse(
                        quantity = intPart + fracPart,
                        unit = NutritionCalculator.normalizeUnitLabel(lastLower),
                        remainingTokens = tokens.dropLast(3)
                    )
                }
            }
            val qtyBeforeUnit = parseSingleQuantityToken(tokens[tokens.size - 2])
            if (qtyBeforeUnit != null) {
                return TrailingParse(
                    quantity = qtyBeforeUnit,
                    unit = NutritionCalculator.normalizeUnitLabel(lastLower),
                    remainingTokens = tokens.dropLast(2)
                )
            }
        }

        // Trailing quantity without unit: e.g. "roti 3"
        val trailingQty = parseSingleQuantityToken(tokens.last())
        if (trailingQty != null) {
            return TrailingParse(
                quantity = trailingQty,
                unit = "",
                remainingTokens = tokens.dropLast(1)
            )
        }

        return null
    }

    fun parseSingleQuantityToken(token: String): Double? {
        val cleaned = token.trim().lowercase(Locale.ROOT)
        if (cleaned.isEmpty()) return null

        wordQuantities[cleaned]?.let { return it }
        parseSimpleFractionOrUnicode(cleaned)?.let { return it }

        return cleaned.toDoubleOrNull()
    }

    private fun parseSimpleFractionOrUnicode(token: String): Double? {
        if (token.length == 1 && token[0] in unicodeFractions) {
            return unicodeFractions[token[0]]
        }
        if (token.length > 1 && token.last() in unicodeFractions) {
            val whole = token.dropLast(1).toDoubleOrNull() ?: return null
            val frac = unicodeFractions[token.last()] ?: return null
            return whole + frac
        }
        if (token.contains('/')) {
            val parts = token.split('/')
            if (parts.size == 2) {
                val num = parts[0].toDoubleOrNull()
                val den = parts[1].toDoubleOrNull()
                if (num != null && den != null && den != 0.0) {
                    return num / den
                }
            }
        }
        return null
    }

    private fun inferPreparation(tokens: List<String>): Preparation? {
        val lower = tokens.map { it.lowercase(Locale.ROOT) }
        return when {
            lower.any { it in rawPrepWords } -> Preparation.RAW
            lower.any { it in cookedPrepWords } -> Preparation.COOKED
            else -> null
        }
    }
}
