package com.nutritrack.app.data.local.entity

import androidx.room.Embedded
import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey
import androidx.room.Relation
import com.nutritrack.app.domain.model.FoodBasis
import com.nutritrack.app.domain.model.FoodSource
import com.nutritrack.app.domain.model.MealCategory
import com.nutritrack.app.domain.model.Preparation
import java.time.Instant
import java.time.LocalDate

@Entity(
    tableName = "foods",
    indices = [
        Index(value = ["name"]),
        Index(value = ["category"]),
        Index(value = ["isCustom"]),
        Index(value = ["barcode"])
    ]
)
data class FoodEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0L,
    val name: String,
    /** Comma-separated lowercase aliases for deterministic lookup (e.g. "chapati,phulka,fulka") */
    val aliases: String = "",
    val category: String,
    val basis: FoodBasis,
    val kcalPer100: Double,
    val proteinPer100: Double,
    val carbsPer100: Double,
    val fatPer100: Double,
    val preparation: Preparation = Preparation.NA,
    val densityGPerMl: Double? = null,
    val source: FoodSource = FoodSource.ESTIMATE,
    val isCustom: Boolean = false,
    val barcode: String? = null,
    val notes: String? = null
) {
    fun aliasList(): List<String> =
        aliases.split(",")
            .map { it.trim().lowercase() }
            .filter { it.isNotEmpty() }
}

@Entity(
    tableName = "food_servings",
    foreignKeys = [
        ForeignKey(
            entity = FoodEntity::class,
            parentColumns = ["id"],
            childColumns = ["foodId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [
        Index(value = ["foodId"]),
        Index(value = ["foodId", "label"], unique = true)
    ]
)
data class FoodServingEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0L,
    val foodId: Long,
    /** Household unit label: roti, katori, bowl, slice, piece, cup, tbsp, tsp, etc. */
    val label: String,
    /** Equivalent weight in grams (for PER_100G foods) or volume in ml (for PER_100ML foods) */
    val amountGramsOrMl: Double,
    val isDefault: Boolean = false
)

data class FoodWithServings(
    @Embedded val food: FoodEntity,
    @Relation(
        parentColumn = "id",
        entityColumn = "foodId"
    )
    val servings: List<FoodServingEntity>
)

@Entity(
    tableName = "food_entries",
    foreignKeys = [
        ForeignKey(
            entity = FoodEntity::class,
            parentColumns = ["id"],
            childColumns = ["foodId"],
            onDelete = ForeignKey.SET_NULL
        )
    ],
    indices = [
        Index(value = ["entryDate"]),
        Index(value = ["entryDate", "mealCategory"]),
        Index(value = ["foodId"]),
        Index(value = ["loggedAt"])
    ]
)
data class FoodEntryEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0L,
    val entryDate: LocalDate,
    val loggedAt: Instant,
    val mealCategory: MealCategory,
    /** Nullable foreign key with ON DELETE SET NULL so deleting a custom food never alters existing entries */
    val foodId: Long?,
    val foodNameSnapshot: String,
    val quantity: Double,
    val unit: String,
    /** Resolved base amount in grams or ml used at save time */
    val amountGramsOrMl: Double,
    val kcal: Double,
    val protein: Double,
    val carbs: Double,
    val fat: Double,
    val sourceSnapshot: FoodSource
)

@Entity(tableName = "saved_meals")
data class SavedMealEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0L,
    val name: String,
    val defaultMealCategory: MealCategory? = null,
    val createdAt: Instant = Instant.now()
)

@Entity(
    tableName = "saved_meal_items",
    foreignKeys = [
        ForeignKey(
            entity = SavedMealEntity::class,
            parentColumns = ["id"],
            childColumns = ["savedMealId"],
            onDelete = ForeignKey.CASCADE
        ),
        ForeignKey(
            entity = FoodEntity::class,
            parentColumns = ["id"],
            childColumns = ["foodId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [
        Index(value = ["savedMealId"]),
        Index(value = ["foodId"])
    ]
)
data class SavedMealItemEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0L,
    val savedMealId: Long,
    val foodId: Long,
    val quantity: Double,
    val unit: String
)

data class SavedMealWithItems(
    @Embedded val meal: SavedMealEntity,
    @Relation(
        parentColumn = "id",
        entityColumn = "savedMealId"
    )
    val items: List<SavedMealItemEntity>
)

@Entity(
    tableName = "favorite_foods",
    foreignKeys = [
        ForeignKey(
            entity = FoodEntity::class,
            parentColumns = ["id"],
            childColumns = ["foodId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index(value = ["foodId"], unique = true)]
)
data class FavoriteFoodEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0L,
    val foodId: Long,
    val preferredQuantity: Double = 1.0,
    val preferredUnit: String = "piece",
    val addedAt: Instant = Instant.now()
)

@Entity(
    tableName = "quantity_history",
    foreignKeys = [
        ForeignKey(
            entity = FoodEntity::class,
            parentColumns = ["id"],
            childColumns = ["foodId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [
        Index(value = ["foodId", "unit"], unique = true),
        Index(value = ["foodId", "useCount"])
    ]
)
data class QuantityHistoryEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0L,
    val foodId: Long,
    val quantity: Double,
    val unit: String,
    val useCount: Int = 1,
    val lastUsedAt: Instant = Instant.now()
)

@Entity(
    tableName = "nutrition_targets",
    indices = [Index(value = ["effectiveFrom"], unique = true)]
)
data class NutritionTargetEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0L,
    val effectiveFrom: LocalDate,
    val kcal: Double? = null,
    val protein: Double? = null,
    val carbs: Double? = null,
    val fat: Double? = null
)
