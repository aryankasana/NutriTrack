package com.nutritrack.app

import android.app.Application
import com.nutritrack.app.di.AppContainer

class NutriTrackApplication : Application() {
    lateinit var container: AppContainer
        private set

    override fun onCreate() {
        super.onCreate()
        container = AppContainer(this)
        container.initializeSeedDataAsync()
    }
}
