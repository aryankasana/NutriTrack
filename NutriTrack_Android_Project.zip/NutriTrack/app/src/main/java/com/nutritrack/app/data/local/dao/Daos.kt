package com.nutritrack.app.data.local.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import androidx.room.Update
import com.nutritrack.app.data.local.entity.FavoriteFoodEntity
import com.nutritrack.app.data.local.entity.FoodEntity
import com.nutritrack.app.data.local.entity.FoodEntryEntity
import com.nutritrack.app.data.local.entity.FoodServingEntity
import com.nutritrack.app.data.local.entity.FoodWithServings
import com.nutritrack.app.data.local.entity.NutritionTargetEntity
import com.nutritrack.app.data.local.entity.QuantityHistoryEntity
import com.nutritrack.app.data.local.entity.SavedMealEntity
import com.nutritrack.app.data.local.entity.SavedMealItemEntity
import com.nutritrack.app.data.local.entity.SavedMealWithItems
import kotlinx.coroutines.flow.Flow
import java.time.Instant
import java.time.LocalDate

data class DailyNutritionTotalsTuple(
    val totalKcal: Double,
    val totalProtein: Double,
    val totalCarbs: Double,
    val totalFat: Double,
    val entryCount: Int
)

data class DatedNutritionTotalsTuple(
    val entryDate: LocalDate,
    val totalKcal: Double,
    val totalProtein: Double,
    val totalCarbs: Double,
    val totalFat: Double,
    val entryCount: Int
)

data class RecentFoodProjection(
    val foodId: Long,
    val lastLoggedAt: Instant,
    val lastQuantity: Double,
    val lastUnit: String
)

@Dao
interface FoodDao {
    @Transaction
    @Query("SELECT * FROM foods ORDER BY name ASC")
    fun observeAllFoodsWithServings(): Flow<List<FoodWithServings>>

    @Transaction
    @Query("SELECT * FROM foods ORDER BY name ASC")
    suspend fun getAllFoodsWithServings(): List<FoodWithServings>

    @Transaction
    @Query("SELECT * FROM foods WHERE isCustom = 1 ORDER BY name ASC")
    fun observeCustomFoodsWithServings(): Flow<List<FoodWithServings>>

    @Transaction
    @Query("SELECT * FROM foods WHERE id = :foodId LIMIT 1")
    suspend fun getFoodWithServingsById(foodId: Long): FoodWithServings?

    @Transaction
    @Query("SELECT * FROM foods WHERE barcode = :barcode LIMIT 1")
    suspend fun getFoodWithServingsByBarcode(barcode: String): FoodWithServings?

    @Query("SELECT COUNT(*) FROM foods")
    suspend fun getFoodCount(): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertFood(food: FoodEntity): Long

    @Update
    suspend fun updateFood(food: FoodEntity)

    @Query("DELETE FROM foods WHERE id = :foodId")
    suspend fun deleteFoodById(foodId: Long)
}

@Dao
interface FoodServingDao {
    @Query("SELECT * FROM food_servings WHERE foodId = :foodId ORDER BY isDefault DESC, label ASC")
    suspend fun getServingsForFood(foodId: Long): List<FoodServingEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertServing(serving: FoodServingEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertServings(servings: List<FoodServingEntity>)

    @Update
    suspend fun updateServing(serving: FoodServingEntity)

    @Query("DELETE FROM food_servings WHERE id = :servingId")
    suspend fun deleteServingById(servingId: Long)

    @Query("UPDATE food_servings SET isDefault = 0 WHERE foodId = :foodId")
    suspend fun clearDefaultForFood(foodId: Long)
}

@Dao
interface FoodEntryDao {
    @Query(
        """
        SELECT * FROM food_entries
        WHERE entryDate = :date
        ORDER BY mealCategory ASC, loggedAt ASC, id ASC
        """
    )
    fun observeEntriesForDate(date: LocalDate): Flow<List<FoodEntryEntity>>

    @Query(
        """
        SELECT * FROM food_entries
        WHERE entryDate = :date
        ORDER BY mealCategory ASC, loggedAt ASC, id ASC
        """
    )
    suspend fun getEntriesForDate(date: LocalDate): List<FoodEntryEntity>

    /**
     * Daily totals come strictly from SQL SUM over entries, never from UI state,
     * so edits and deletes update everything immediately.
     */
    @Query(
        """
        SELECT
            COALESCE(SUM(kcal), 0.0) AS totalKcal,
            COALESCE(SUM(protein), 0.0) AS totalProtein,
            COALESCE(SUM(carbs), 0.0) AS totalCarbs,
            COALESCE(SUM(fat), 0.0) AS totalFat,
            COUNT(*) AS entryCount
        FROM food_entries
        WHERE entryDate = :date
        """
    )
    fun observeDailyTotals(date: LocalDate): Flow<DailyNutritionTotalsTuple>

    @Query(
        """
        SELECT
            COALESCE(SUM(kcal), 0.0) AS totalKcal,
            COALESCE(SUM(protein), 0.0) AS totalProtein,
            COALESCE(SUM(carbs), 0.0) AS totalCarbs,
            COALESCE(SUM(fat), 0.0) AS totalFat,
            COUNT(*) AS entryCount
        FROM food_entries
        WHERE entryDate = :date
        """
    )
    suspend fun getDailyTotals(date: LocalDate): DailyNutritionTotalsTuple

    /**
     * History/averages/charts use only days with at least one entry (HAVING COUNT(*) > 0).
     */
    @Query(
        """
        SELECT
            entryDate,
            COALESCE(SUM(kcal), 0.0) AS totalKcal,
            COALESCE(SUM(protein), 0.0) AS totalProtein,
            COALESCE(SUM(carbs), 0.0) AS totalCarbs,
            COALESCE(SUM(fat), 0.0) AS totalFat,
            COUNT(*) AS entryCount
        FROM food_entries
        WHERE entryDate BETWEEN :startDate AND :endDate
        GROUP BY entryDate
        HAVING COUNT(*) > 0
        ORDER BY entryDate ASC
        """
    )
    fun observeLoggedDailyTotalsBetween(
        startDate: LocalDate,
        endDate: LocalDate
    ): Flow<List<DatedNutritionTotalsTuple>>

    @Query(
        """
        SELECT * FROM food_entries
        WHERE foodNameSnapshot LIKE '%' || :query || '%'
        ORDER BY entryDate DESC, loggedAt DESC
        LIMIT 100
        """
    )
    fun searchPastEntries(query: String): Flow<List<FoodEntryEntity>>

    @Query(
        """
        SELECT * FROM food_entries
        ORDER BY entryDate ASC, loggedAt ASC, id ASC
        """
    )
    suspend fun getAllEntriesChronological(): List<FoodEntryEntity>

    @Query(
        """
        SELECT
            foodId AS foodId,
            MAX(loggedAt) AS lastLoggedAt,
            quantity AS lastQuantity,
            unit AS lastUnit
        FROM food_entries
        WHERE foodId IS NOT NULL
        GROUP BY foodId
        ORDER BY lastLoggedAt DESC
        LIMIT :limit
        """
    )
    fun observeRecentFoods(limit: Int = 15): Flow<List<RecentFoodProjection>>

    @Query("SELECT * FROM food_entries WHERE id = :entryId LIMIT 1")
    suspend fun getEntryById(entryId: Long): FoodEntryEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertEntry(entry: FoodEntryEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertEntries(entries: List<FoodEntryEntity>): List<Long>

    @Update
    suspend fun updateEntry(entry: FoodEntryEntity)

    @Delete
    suspend fun deleteEntry(entry: FoodEntryEntity)

    @Query("DELETE FROM food_entries WHERE id = :entryId")
    suspend fun deleteEntryById(entryId: Long)
}

@Dao
interface NutritionTargetDao {
    /**
     * A day's "remaining" uses the target effective on that date
     * (most recent target where effectiveFrom <= :date).
     */
    @Query(
        """
        SELECT * FROM nutrition_targets
        WHERE effectiveFrom <= :date
        ORDER BY effectiveFrom DESC
        LIMIT 1
        """
    )
    fun observeEffectiveTargetForDate(date: LocalDate): Flow<NutritionTargetEntity?>

    @Query(
        """
        SELECT * FROM nutrition_targets
        WHERE effectiveFrom <= :date
        ORDER BY effectiveFrom DESC
        LIMIT 1
        """
    )
    suspend fun getEffectiveTargetForDate(date: LocalDate): NutritionTargetEntity?

    @Query("SELECT * FROM nutrition_targets ORDER BY effectiveFrom DESC")
    fun observeAllTargets(): Flow<List<NutritionTargetEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertTarget(target: NutritionTargetEntity): Long
}

@Dao
interface FavoriteFoodDao {
    @Query("SELECT * FROM favorite_foods ORDER BY addedAt DESC")
    fun observeFavorites(): Flow<List<FavoriteFoodEntity>>

    @Query("SELECT * FROM favorite_foods WHERE foodId = :foodId LIMIT 1")
    suspend fun getFavoriteForFood(foodId: Long): FavoriteFoodEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertFavorite(favorite: FavoriteFoodEntity): Long

    @Query("DELETE FROM favorite_foods WHERE foodId = :foodId")
    suspend fun deleteFavoriteForFood(foodId: Long)
}

@Dao
interface QuantityHistoryDao {
    @Query(
        """
        SELECT * FROM quantity_history
        WHERE foodId = :foodId
        ORDER BY useCount DESC, lastUsedAt DESC
        """
    )
    suspend fun getHistoryForFood(foodId: Long): List<QuantityHistoryEntity>

    @Query(
        """
        SELECT * FROM quantity_history
        WHERE foodId = :foodId AND LOWER(unit) = LOWER(:unit)
        LIMIT 1
        """
    )
    suspend fun getHistoryForFoodAndUnit(foodId: Long, unit: String): QuantityHistoryEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertHistory(history: QuantityHistoryEntity): Long
}

@Dao
interface SavedMealDao {
    @Transaction
    @Query("SELECT * FROM saved_meals ORDER BY name ASC")
    fun observeSavedMealsWithItems(): Flow<List<SavedMealWithItems>>

    @Transaction
    @Query("SELECT * FROM saved_meals WHERE id = :mealId LIMIT 1")
    suspend fun getSavedMealWithItemsById(mealId: Long): SavedMealWithItems?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSavedMeal(meal: SavedMealEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSavedMealItems(items: List<SavedMealItemEntity>)

    @Query("DELETE FROM saved_meal_items WHERE savedMealId = :mealId")
    suspend fun deleteItemsForMeal(mealId: Long)

    @Query("DELETE FROM saved_meals WHERE id = :mealId")
    suspend fun deleteSavedMealById(mealId: Long)
}
