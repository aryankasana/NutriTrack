package com.nutritrack.app.data.remote

import com.nutritrack.app.data.repository.NutritionRepository
import com.nutritrack.app.domain.model.FoodBasis
import com.nutritrack.app.domain.model.FoodSource
import com.nutritrack.app.domain.model.Preparation
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

data class OpenFoodFactsProduct(
    val barcode: String?,
    val name: String,
    val brand: String?,
    val kcalPer100g: Double,
    val proteinPer100g: Double,
    val carbsPer100g: Double,
    val fatPer100g: Double,
    val servingQuantityGrams: Double?
)

/**
 * Optional Phase 6 Open Food Facts lookup:
 * - Uses no API key (public Open Food Facts read endpoint under ODbL).
 * - Strictly gated behind the `openFoodFactsEnabled` feature flag in Settings.
 * - Offline-safe: catches all network/IO exceptions cleanly so the app works 100% offline.
 * - Caches discovered products into Room with `source = FoodSource.OFF`, showing the OFF badge
 *   and allowing user serving/macro edits.
 */
class OpenFoodFactsClient(
    private val repository: NutritionRepository
) {
    suspend fun searchAndCacheProducts(
        query: String,
        featureFlagEnabled: Boolean
    ): Result<List<OpenFoodFactsProduct>> = withContext(Dispatchers.IO) {
        if (!featureFlagEnabled) {
            return@withContext Result.failure(
                IllegalStateException("Open Food Facts lookup is disabled in Settings.")
            )
        }
        runCatching {
            val encoded = URLEncoder.encode(query.trim(), "UTF-8")
            val endpoint =
                "https://world.openfoodfacts.org/cgi/search.pl?search_terms=$encoded&search_simple=1&action=process&json=1&page_size=5"
            val connection = (URL(endpoint).openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                connectTimeout = 5000
                readTimeout = 5000
                setRequestProperty("User-Agent", "NutriTrack-Android/1.0 (Offline-First Nutrition Tracker)")
            }

            try {
                if (connection.responseCode != HttpURLConnection.HTTP_OK) {
                    throw IllegalStateException("HTTP ${connection.responseCode}")
                }
                val body = connection.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
                val root = JSONObject(body)
                val productsArr = root.optJSONArray("products") ?: return@runCatching emptyList()
                val results = mutableListOf<OpenFoodFactsProduct>()

                for (i in 0 until productsArr.length()) {
                    val prod = productsArr.getJSONObject(i)
                    val rawName = prod.optString("product_name", "").trim()
                    if (rawName.isEmpty()) continue
                    val brands = prod.optString("brands", "").trim().takeIf { it.isNotEmpty() }
                    val nutriments = prod.optJSONObject("nutriments") ?: continue

                    val kcal = nutriments.optDouble("energy-kcal_100g", Double.NaN)
                        .let { if (it.isNaN()) nutriments.optDouble("energy-kcal", 0.0) else it }
                    val protein = nutriments.optDouble("proteins_100g", 0.0)
                    val carbs = nutriments.optDouble("carbohydrates_100g", 0.0)
                    val fat = nutriments.optDouble("fat_100g", 0.0)
                    val srvQty = prod.optDouble("serving_quantity", Double.NaN).takeIf { !it.isNaN() && it > 0.0 }
                    val code = prod.optString("code", "").takeIf { it.isNotEmpty() }

                    val displayName = if (brands != null && !rawName.contains(brands, ignoreCase = true)) {
                        "$rawName ($brands)"
                    } else {
                        rawName
                    }

                    val parsedProduct = OpenFoodFactsProduct(
                        barcode = code,
                        name = displayName,
                        brand = brands,
                        kcalPer100g = kcal,
                        proteinPer100g = protein,
                        carbsPer100g = carbs,
                        fatPer100g = fat,
                        servingQuantityGrams = srvQty
                    )
                    results.add(parsedProduct)

                    // Cache into Room with source = OFF so subsequent searches work 100% offline
                    repository.createCustomFood(
                        name = parsedProduct.name,
                        aliases = query.trim().lowercase(),
                        category = "Packaged (OFF)",
                        basis = FoodBasis.PER_100G,
                        kcalPer100 = parsedProduct.kcalPer100g,
                        proteinPer100 = parsedProduct.proteinPer100g,
                        carbsPer100 = parsedProduct.carbsPer100g,
                        fatPer100 = parsedProduct.fatPer100g,
                        preparation = Preparation.NA,
                        defaultServingLabel = if (srvQty != null) "serving" else "packet",
                        defaultServingGramsOrMl = srvQty ?: 30.0,
                        source = FoodSource.OFF,
                        barcode = code
                    )
                }
                results
            } finally {
                connection.disconnect()
            }
        }
    }
}
