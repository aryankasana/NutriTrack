package com.nutritrack.app.data.local

import android.content.Context
import com.nutritrack.app.data.local.dao.FoodDao
import com.nutritrack.app.data.local.dao.FoodServingDao
import com.nutritrack.app.data.local.entity.FoodEntity
import com.nutritrack.app.data.local.entity.FoodServingEntity
import com.nutritrack.app.domain.model.FoodBasis
import com.nutritrack.app.domain.model.FoodSource
import com.nutritrack.app.domain.model.Preparation
import org.json.JSONArray

object SeedDatabaseLoader {

    suspend fun ensureSeeded(
        context: Context,
        foodDao: FoodDao,
        foodServingDao: FoodServingDao
    ) {
        if (foodDao.getFoodCount() > 0) return

        val jsonText = context.assets.open("seed_foods.json")
            .bufferedReader(Charsets.UTF_8)
            .use { it.readText() }

        seedFromJsonString(jsonText, foodDao, foodServingDao)
    }

    suspend fun seedFromJsonString(
        jsonText: String,
        foodDao: FoodDao,
        foodServingDao: FoodServingDao
    ) {
        val rootArray = JSONArray(jsonText)
        for (i in 0 until rootArray.length()) {
            val obj = rootArray.getJSONObject(i)
            val density = if (obj.isNull("densityGPerMl")) null else obj.optDouble("densityGPerMl")
            val notes = if (obj.isNull("notes")) null else obj.optString("notes")

            val food = FoodEntity(
                name = obj.getString("name"),
                aliases = obj.optString("aliases", ""),
                category = obj.optString("category", "General"),
                basis = FoodBasis.valueOf(obj.getString("basis")),
                kcalPer100 = obj.getDouble("kcalPer100"),
                proteinPer100 = obj.getDouble("proteinPer100"),
                carbsPer100 = obj.getDouble("carbsPer100"),
                fatPer100 = obj.getDouble("fatPer100"),
                preparation = Preparation.valueOf(obj.optString("preparation", "NA")),
                densityGPerMl = density,
                source = FoodSource.valueOf(obj.optString("source", "ESTIMATE")),
                isCustom = false,
                notes = notes
            )

            val foodId = foodDao.insertFood(food)
            val servingsArray = obj.optJSONArray("servings") ?: continue
            val servings = mutableListOf<FoodServingEntity>()
            for (j in 0 until servingsArray.length()) {
                val sObj = servingsArray.getJSONObject(j)
                servings.add(
                    FoodServingEntity(
                        foodId = foodId,
                        label = sObj.getString("label"),
                        amountGramsOrMl = sObj.getDouble("amountGramsOrMl"),
                        isDefault = sObj.optBoolean("isDefault", j == 0)
                    )
                )
            }
            if (servings.isNotEmpty()) {
                foodServingDao.insertServings(servings)
            }
        }
    }
}
