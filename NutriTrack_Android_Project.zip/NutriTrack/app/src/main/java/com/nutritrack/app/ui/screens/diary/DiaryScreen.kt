package com.nutritrack.app.ui.screens.diary

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DatePicker
import androidx.compose.material3.DatePickerDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberDatePickerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.nutritrack.app.data.local.entity.FoodEntryEntity
import com.nutritrack.app.data.local.entity.FoodWithServings
import com.nutritrack.app.domain.calculation.DailyNutritionSummary
import com.nutritrack.app.domain.calculation.NutritionCalculator
import com.nutritrack.app.domain.model.MealCategory
import com.nutritrack.app.ui.screens.home.EditEntryDialog
import com.nutritrack.app.ui.screens.home.FoodEntryRowCard
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneOffset
import java.time.format.DateTimeFormatter

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DiaryScreen(
    selectedDate: LocalDate,
    todayDate: LocalDate,
    summary: DailyNutritionSummary,
    entries: List<FoodEntryEntity>,
    pastSearchResults: List<FoodEntryEntity>,
    allFoods: List<FoodWithServings>,
    onSelectDate: (LocalDate) -> Unit,
    onOpenQuickAdd: () -> Unit,
    onRepeatYesterday: () -> Unit,
    onCopyMealToToday: (MealCategory) -> Unit,
    onEditEntry: (
        entry: FoodEntryEntity,
        newFoodId: Long?,
        newQuantity: Double,
        newUnit: String,
        newMealCategory: MealCategory
    ) -> Unit,
    onDeleteEntry: (FoodEntryEntity) -> Unit,
    onDuplicateEntryToSelectedDate: (FoodEntryEntity) -> Unit,
    onSearchPastEntriesQueryChange: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    var showCalendarDialog by remember { mutableStateOf(false) }
    var searchQuery by remember { mutableStateOf("") }
    var editingEntry by remember { mutableStateOf<FoodEntryEntity?>(null) }

    val dayNumberFormatter = remember { DateTimeFormatter.ofPattern("dd") }
    val dayOfWeekFormatter = remember { DateTimeFormatter.ofPattern("EEE") }
    val fullDateFormatter = remember { DateTimeFormatter.ofPattern("EEE, dd MMM yyyy") }

    val dateStripDays = remember(selectedDate) {
        (-3..3).map { offset -> selectedDate.plusDays(offset.toLong()) }
    }

    val groupedMeals = remember(entries) {
        entries.groupBy { it.mealCategory }
            .toSortedMap(compareBy { it.sortOrder })
    }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = onOpenQuickAdd,
                icon = { Icon(Icons.Default.Add, contentDescription = null) },
                text = { Text("+ Add Food") }
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Top bar with Date title + Calendar picker icon
            item {
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "Food Diary",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = selectedDate.format(fullDateFormatter),
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        OutlinedButton(onClick = onRepeatYesterday) {
                            Icon(Icons.Default.History, contentDescription = null)
                            Text(" Repeat Yesterday")
                        }
                        IconButton(onClick = { showCalendarDialog = true }) {
                            Icon(Icons.Default.CalendarMonth, contentDescription = "Open Calendar")
                        }
                    }
                }
            }

            // 7-day horizontal date strip
            item {
                LazyRow(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(dateStripDays, key = { it.toString() }) { day ->
                        val isSelected = day == selectedDate
                        val isToday = day == todayDate
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = when {
                                isSelected -> MaterialTheme.colorScheme.primary
                                isToday -> MaterialTheme.colorScheme.secondaryContainer
                                else -> MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                            },
                            contentColor = when {
                                isSelected -> MaterialTheme.colorScheme.onPrimary
                                isToday -> MaterialTheme.colorScheme.onSecondaryContainer
                                else -> MaterialTheme.colorScheme.onSurface
                            },
                            modifier = Modifier.clickable { onSelectDate(day) }
                        ) {
                            Column(
                                modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text(
                                    text = day.format(dayOfWeekFormatter),
                                    style = MaterialTheme.typography.labelSmall
                                )
                                Text(
                                    text = day.format(dayNumberFormatter),
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            }

            // Selected date's SQL totals banner
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.45f)
                    )
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "Day Total (${summary.entryCount} entries)",
                                style = MaterialTheme.typography.labelLarge,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "${NutritionCalculator.formatKcal(summary.kcal.consumed)} kcal • " +
                                    "${NutritionCalculator.formatMacro(summary.protein.consumed)}g P • " +
                                    "${NutritionCalculator.formatMacro(summary.carbs.consumed)}g C • " +
                                    "${NutritionCalculator.formatMacro(summary.fat.consumed)}g F",
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                        Text(
                            text = NutritionCalculator.formatRemainingLabel(summary.kcal, isKcal = true),
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            // Search past entries bar
            item {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = {
                        searchQuery = it
                        onSearchPastEntriesQueryChange(it)
                    },
                    label = { Text("Search past diary entries to re-log") },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }

            if (searchQuery.isNotBlank()) {
                item {
                    Text(
                        text = "Past Entries Matching '$searchQuery' (${pastSearchResults.size})",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold
                    )
                }
                items(pastSearchResults, key = { "search_${it.id}" }) { pastEntry ->
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f)
                        )
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "${pastEntry.foodNameSnapshot} (${pastEntry.quantity} ${pastEntry.unit})",
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.SemiBold
                                )
                                Text(
                                    text = "${pastEntry.entryDate} • ${pastEntry.mealCategory.displayName} • " +
                                        "${NutritionCalculator.formatKcal(pastEntry.kcal)} kcal",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            TextButton(onClick = { onDuplicateEntryToSelectedDate(pastEntry) }) {
                                Icon(Icons.Default.ContentCopy, contentDescription = null)
                                Text(" Copy to ${selectedDate.format(dayNumberFormatter)}")
                            }
                        }
                    }
                }
            }

            // Grouped meals for selectedDate
            if (entries.isEmpty()) {
                item {
                    Text(
                        text = "No entries recorded on ${selectedDate.format(fullDateFormatter)}.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(vertical = 20.dp)
                    )
                }
            } else {
                groupedMeals.forEach { (mealCategory, mealEntries) ->
                    item(key = "diary_meal_${mealCategory.name}") {
                        val mealKcal = mealEntries.sumOf { it.kcal }
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(top = 6.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "${mealCategory.displayName} (${NutritionCalculator.formatKcal(mealKcal)} kcal)",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )
                            if (selectedDate != todayDate) {
                                TextButton(onClick = { onCopyMealToToday(mealCategory) }) {
                                    Icon(Icons.Default.ContentCopy, contentDescription = null)
                                    Text(" Copy meal to Today")
                                }
                            }
                        }
                    }
                    items(mealEntries, key = { it.id }) { entry ->
                        FoodEntryRowCard(
                            entry = entry,
                            onEdit = { editingEntry = entry },
                            onDuplicate = { onDuplicateEntryToSelectedDate(entry) },
                            onDelete = { onDeleteEntry(entry) }
                        )
                    }
                }
            }

            item { Spacer(modifier = Modifier.height(84.dp)) }
        }
    }

    if (showCalendarDialog) {
        val initialMillis = remember(selectedDate) {
            selectedDate.atStartOfDay(ZoneOffset.UTC).toInstant().toEpochMilli()
        }
        val datePickerState = rememberDatePickerState(initialSelectedDateMillis = initialMillis)
        DatePickerDialog(
            onDismissRequest = { showCalendarDialog = false },
            confirmButton = {
                TextButton(
                    onClick = {
                        datePickerState.selectedDateMillis?.let { millis ->
                            val picked = Instant.ofEpochMilli(millis)
                                .atZone(ZoneOffset.UTC)
                                .toLocalDate()
                            onSelectDate(picked)
                        }
                        showCalendarDialog = false
                    }
                ) {
                    Text("Select")
                }
            },
            dismissButton = {
                TextButton(onClick = { showCalendarDialog = false }) {
                    Text("Cancel")
                }
            }
        ) {
            DatePicker(state = datePickerState)
        }
    }

    editingEntry?.let { targetEntry ->
        EditEntryDialog(
            entry = targetEntry,
            allFoods = allFoods,
            onDismiss = { editingEntry = null },
            onSave = { newFoodId, newQty, newUnit, newMealCategory ->
                onEditEntry(targetEntry, newFoodId, newQty, newUnit, newMealCategory)
                editingEntry = null
            }
        )
    }
}
