package com.nutritrack.app.ui

import android.content.Context
import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.nutritrack.app.data.local.dao.DailyNutritionTotalsTuple
import com.nutritrack.app.data.local.dao.RecentFoodProjection
import com.nutritrack.app.data.local.entity.FavoriteFoodEntity
import com.nutritrack.app.data.local.entity.FoodEntryEntity
import com.nutritrack.app.data.local.entity.FoodWithServings
import com.nutritrack.app.data.local.entity.NutritionTargetEntity
import com.nutritrack.app.data.local.entity.SavedMealWithItems
import com.nutritrack.app.data.preferences.UserPreferences
import com.nutritrack.app.data.preferences.UserPreferencesRepository
import com.nutritrack.app.data.remote.OpenFoodFactsClient
import com.nutritrack.app.data.repository.NutritionRepository
import com.nutritrack.app.domain.calculation.DailyNutritionSummary
import com.nutritrack.app.domain.calculation.DayHistoryPoint
import com.nutritrack.app.domain.calculation.HistoryAnalyzer
import com.nutritrack.app.domain.calculation.NutritionCalculator
import com.nutritrack.app.domain.calculation.PeriodNutritionAverages
import com.nutritrack.app.domain.calculation.UnitConversionResult
import com.nutritrack.app.domain.export.CsvExporter
import com.nutritrack.app.domain.model.FoodBasis
import com.nutritrack.app.domain.model.MealCategory
import com.nutritrack.app.domain.model.Preparation
import com.nutritrack.app.domain.model.ThemeMode
import com.nutritrack.app.domain.parser.ParsedQuickAddItem
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.time.LocalDate

@OptIn(ExperimentalCoroutinesApi::class)
class NutriTrackViewModel(
    private val repository: NutritionRepository,
    private val preferencesRepository: UserPreferencesRepository,
    private val openFoodFactsClient: OpenFoodFactsClient
) : ViewModel() {

    private val _todayDate = MutableStateFlow(LocalDate.now())
    val todayDate: StateFlow<LocalDate> = _todayDate.asStateFlow()

    /**
     * `selectedDate` lives in the ViewModel and every date-sensitive query is keyed by it.
     * When the clock passes midnight while the app stays open, `_todayDate` updates and, if
     * `selectedDate` was on the previous today, automatically rolls over to the new day.
     */
    private val _selectedDate = MutableStateFlow(LocalDate.now())
    val selectedDate: StateFlow<LocalDate> = _selectedDate.asStateFlow()

    private val _pastSearchQuery = MutableStateFlow("")
    private val _offLoading = MutableStateFlow(false)
    val offLoading: StateFlow<Boolean> = _offLoading.asStateFlow()

    private val _offStatusMessage = MutableStateFlow<String?>(null)
    val offStatusMessage: StateFlow<String?> = _offStatusMessage.asStateFlow()

    init {
        // Midnight rollover observer so Home updates automatically after midnight if kept open
        viewModelScope.launch {
            while (isActive) {
                delay(30_000L)
                val now = LocalDate.now()
                val oldToday = _todayDate.value
                if (now != oldToday) {
                    _todayDate.value = now
                    if (_selectedDate.value == oldToday) {
                        _selectedDate.value = now
                    }
                }
            }
        }
    }

    val preferences: StateFlow<UserPreferences> = preferencesRepository.preferencesFlow
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5_000),
            initialValue = UserPreferences()
        )

    val allFoods: StateFlow<List<FoodWithServings>> = repository.observeAllFoodsWithServings()
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5_000),
            initialValue = emptyList()
        )

    val recentFoods: StateFlow<List<RecentFoodProjection>> = repository.observeRecentFoods(15)
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5_000),
            initialValue = emptyList()
        )

    val favorites: StateFlow<List<FavoriteFoodEntity>> = repository.observeFavorites()
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5_000),
            initialValue = emptyList()
        )

    val savedMeals: StateFlow<List<SavedMealWithItems>> = repository.observeSavedMealsWithItems()
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5_000),
            initialValue = emptyList()
        )

    val entriesForSelectedDate: StateFlow<List<FoodEntryEntity>> = _selectedDate
        .flatMapLatest { date -> repository.observeEntriesForDate(date) }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5_000),
            initialValue = emptyList()
        )

    val effectiveTargetForSelectedDate: StateFlow<NutritionTargetEntity?> = _selectedDate
        .flatMapLatest { date -> repository.observeEffectiveTargetForDate(date) }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5_000),
            initialValue = null
        )

    private val sqlTotalsForSelectedDate: StateFlow<DailyNutritionTotalsTuple> = _selectedDate
        .flatMapLatest { date -> repository.observeDailyTotals(date) }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5_000),
            initialValue = DailyNutritionTotalsTuple(0.0, 0.0, 0.0, 0.0, 0)
        )

    /**
     * Daily summary combines SQL `SUM` totals from `food_entries` with the effective
     * `NutritionTarget` for `selectedDate`.
     */
    val dailySummary: StateFlow<DailyNutritionSummary> = combine(
        sqlTotalsForSelectedDate,
        effectiveTargetForSelectedDate
    ) { totals, target ->
        NutritionCalculator.buildDailySummary(
            totalKcal = totals.totalKcal,
            totalProtein = totals.totalProtein,
            totalCarbs = totals.totalCarbs,
            totalFat = totals.totalFat,
            entryCount = totals.entryCount,
            targetKcal = target?.kcal,
            targetProtein = target?.protein,
            targetCarbs = target?.carbs,
            targetFat = target?.fat
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5_000),
        initialValue = NutritionCalculator.buildDailySummary(0.0, 0.0, 0.0, 0.0, 0, null, null, null, null)
    )

    val pastEntrySearchResults: StateFlow<List<FoodEntryEntity>> = _pastSearchQuery
        .flatMapLatest { q ->
            if (q.isBlank()) flowOf(emptyList()) else repository.searchPastEntries(q.trim())
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5_000),
            initialValue = emptyList()
        )

    private val thirtyDayLoggedTotals = _selectedDate.flatMapLatest { endDate ->
        repository.observeLoggedDailyTotalsBetween(endDate.minusDays(29), endDate)
    }

    val sevenDayAverages: StateFlow<PeriodNutritionAverages> = combine(
        _selectedDate,
        thirtyDayLoggedTotals
    ) { endDate, logged ->
        HistoryAnalyzer.computeLoggedDayAverages(endDate.minusDays(6), endDate, logged)
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5_000),
        initialValue = PeriodNutritionAverages(0, 7, null, null, null, null)
    )

    val thirtyDayAverages: StateFlow<PeriodNutritionAverages> = combine(
        _selectedDate,
        thirtyDayLoggedTotals
    ) { endDate, logged ->
        HistoryAnalyzer.computeLoggedDayAverages(endDate.minusDays(29), endDate, logged)
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5_000),
        initialValue = PeriodNutritionAverages(0, 30, null, null, null, null)
    )

    val recentSevenDaySeries: StateFlow<List<DayHistoryPoint>> = combine(
        _selectedDate,
        thirtyDayLoggedTotals
    ) { endDate, logged ->
        HistoryAnalyzer.buildDailySeries(endDate.minusDays(6), endDate, logged)
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5_000),
        initialValue = emptyList()
    )

    fun selectDate(date: LocalDate) {
        _selectedDate.value = date
    }

    fun goToPreviousDay() {
        _selectedDate.value = _selectedDate.value.minusDays(1)
    }

    fun goToNextDay() {
        _selectedDate.value = _selectedDate.value.plusDays(1)
    }

    fun jumpToToday() {
        val now = LocalDate.now()
        _todayDate.value = now
        _selectedDate.value = now
    }

    fun setPastSearchQuery(query: String) {
        _pastSearchQuery.value = query
    }

    fun setLastUsedMealCategory(category: MealCategory) {
        viewModelScope.launch {
            preferencesRepository.setLastUsedMealCategory(category)
        }
    }

    fun setThemeMode(mode: ThemeMode) {
        viewModelScope.launch {
            preferencesRepository.setThemeMode(mode)
        }
    }

    fun setKeepQuickAddFocused(keepFocused: Boolean) {
        viewModelScope.launch {
            preferencesRepository.setKeepQuickAddFocused(keepFocused)
        }
    }

    fun setOpenFoodFactsEnabled(enabled: Boolean) {
        viewModelScope.launch {
            preferencesRepository.setOpenFoodFactsEnabled(enabled)
        }
    }

    fun confirmQuickAddBatch(
        entryDate: LocalDate,
        mealCategory: MealCategory,
        items: List<ParsedQuickAddItem>
    ) {
        viewModelScope.launch {
            preferencesRepository.setLastUsedMealCategory(mealCategory)
            for (item in items) {
                val matched = item.matchedFood ?: continue
                val computed = item.computedNutrition ?: continue
                repository.logFoodEntry(
                    entryDate = entryDate,
                    mealCategory = mealCategory,
                    foodWithServings = matched,
                    quantity = item.quantity,
                    unit = item.resolvedUnit,
                    amountGramsOrMl = computed.amountGramsOrMl
                )
            }
        }
    }

    fun quickLogSingleFood(
        entryDate: LocalDate,
        mealCategory: MealCategory,
        food: FoodWithServings,
        quantity: Double,
        unit: String
    ) {
        viewModelScope.launch {
            preferencesRepository.setLastUsedMealCategory(mealCategory)
            val conv = NutritionCalculator.resolveAmountGramsOrMl(
                food = food.food,
                servings = food.servings,
                quantity = quantity,
                rawUnit = unit
            )
            val amount = when (conv) {
                is UnitConversionResult.Success -> conv.amountGramsOrMl
                is UnitConversionResult.MissingServingWeight -> quantity * 100.0
            }
            repository.logFoodEntry(
                entryDate = entryDate,
                mealCategory = mealCategory,
                foodWithServings = food,
                quantity = quantity,
                unit = unit,
                amountGramsOrMl = amount
            )
        }
    }

    fun logManualPortion(
        entryDate: LocalDate,
        mealCategory: MealCategory,
        foodName: String,
        quantity: Double,
        unit: String,
        kcal: Double,
        protein: Double,
        carbs: Double,
        fat: Double
    ) {
        viewModelScope.launch {
            preferencesRepository.setLastUsedMealCategory(mealCategory)
            repository.logManualPortion(
                entryDate = entryDate,
                mealCategory = mealCategory,
                foodName = foodName,
                quantity = quantity,
                unit = unit,
                kcal = kcal,
                protein = protein,
                carbs = carbs,
                fat = fat
            )
        }
    }

    fun editEntry(
        entry: FoodEntryEntity,
        newFoodId: Long?,
        newQuantity: Double,
        newUnit: String,
        newMealCategory: MealCategory
    ) {
        viewModelScope.launch {
            repository.editEntry(entry, newFoodId, newQuantity, newUnit, newMealCategory)
        }
    }

    fun deleteEntry(entry: FoodEntryEntity) {
        viewModelScope.launch {
            repository.deleteEntry(entry)
        }
    }

    fun duplicateEntry(entry: FoodEntryEntity, targetDate: LocalDate = entry.entryDate) {
        viewModelScope.launch {
            repository.duplicateEntry(entry, targetDate = targetDate)
        }
    }

    fun copyMealToToday(mealCategory: MealCategory) {
        viewModelScope.launch {
            repository.copyMealEntries(
                sourceDate = _selectedDate.value,
                sourceMealCategory = mealCategory,
                targetDate = _todayDate.value,
                targetMealCategory = mealCategory
            )
        }
    }

    fun repeatYesterdayIntoSelectedDate() {
        viewModelScope.launch {
            repository.repeatYesterdayIntoDate(_selectedDate.value)
        }
    }

    fun createCustomFood(
        name: String,
        aliases: String,
        category: String,
        basis: FoodBasis,
        kcalPer100: Double,
        proteinPer100: Double,
        carbsPer100: Double,
        fatPer100: Double,
        preparation: Preparation,
        servingLabel: String?,
        servingWeight: Double?
    ) {
        viewModelScope.launch {
            repository.createCustomFood(
                name = name,
                aliases = aliases,
                category = category,
                basis = basis,
                kcalPer100 = kcalPer100,
                proteinPer100 = proteinPer100,
                carbsPer100 = carbsPer100,
                fatPer100 = fatPer100,
                preparation = preparation,
                defaultServingLabel = servingLabel,
                defaultServingGramsOrMl = servingWeight
            )
        }
    }

    fun deleteCustomFood(foodId: Long) {
        viewModelScope.launch {
            repository.deleteCustomFood(foodId)
        }
    }

    fun saveFoodServing(
        foodId: Long,
        label: String,
        amountGramsOrMl: Double,
        isDefault: Boolean = false
    ) {
        viewModelScope.launch {
            repository.saveFoodServing(foodId, label, amountGramsOrMl, isDefault)
        }
    }

    fun deleteFoodServing(servingId: Long) {
        viewModelScope.launch {
            repository.deleteFoodServing(servingId)
        }
    }

    fun toggleFavorite(food: FoodWithServings, preferredQty: Double, preferredUnit: String) {
        viewModelScope.launch {
            repository.toggleFavoriteFood(food.food.id, preferredQty, preferredUnit)
        }
    }

    fun createSavedMeal(
        name: String,
        defaultMealCategory: MealCategory?,
        items: List<Triple<Long, Double, String>>
    ) {
        viewModelScope.launch {
            repository.createSavedMeal(name, defaultMealCategory, items)
        }
    }

    fun logSavedMeal(savedMealId: Long, mealCategory: MealCategory) {
        viewModelScope.launch {
            repository.logSavedMeal(savedMealId, _selectedDate.value, mealCategory)
        }
    }

    fun deleteSavedMeal(savedMealId: Long) {
        viewModelScope.launch {
            repository.deleteSavedMeal(savedMealId)
        }
    }

    fun saveTargets(
        effectiveFrom: LocalDate,
        kcal: Double?,
        protein: Double?,
        carbs: Double?,
        fat: Double?
    ) {
        viewModelScope.launch {
            repository.upsertNutritionTarget(effectiveFrom, kcal, protein, carbs, fat)
        }
    }

    fun searchOpenFoodFacts(query: String) {
        viewModelScope.launch {
            _offLoading.value = true
            _offStatusMessage.value = null
            val enabled = preferences.value.openFoodFactsEnabled
            val result = openFoodFactsClient.searchAndCacheProducts(query, enabled)
            _offLoading.value = false
            result.fold(
                onSuccess = { list ->
                    _offStatusMessage.value = if (list.isEmpty()) {
                        "No Open Food Facts matches for '$query'"
                    } else {
                        "Cached ${list.size} Open Food Facts items (source=OFF)"
                    }
                },
                onFailure = { err ->
                    _offStatusMessage.value = "Offline / OFF unavailable (${err.message ?: "network error"})"
                }
            )
        }
    }

    fun shareCsvExport(context: Context) {
        viewModelScope.launch {
            val entries = repository.getAllEntriesChronological()
            val csv = CsvExporter.formatEntriesToCsv(entries)
            CsvExporter.shareCsvViaIntent(context, csv)
        }
    }

    fun writeCsvExportToUri(context: Context, uri: Uri) {
        viewModelScope.launch {
            val entries = repository.getAllEntriesChronological()
            val csv = CsvExporter.formatEntriesToCsv(entries)
            withContext(Dispatchers.IO) {
                context.contentResolver.openOutputStream(uri)?.use { out ->
                    out.write(csv.toByteArray(Charsets.UTF_8))
                }
            }
        }
    }

    companion object {
        fun provideFactory(
            repository: NutritionRepository,
            preferencesRepository: UserPreferencesRepository,
            openFoodFactsClient: OpenFoodFactsClient
        ): ViewModelProvider.Factory = object : ViewModelProvider.Factory {
            @Suppress("UNCHECKED_CAST")
            override fun <T : ViewModel> create(modelClass: Class<T>): T {
                return NutriTrackViewModel(
                    repository = repository,
                    preferencesRepository = preferencesRepository,
                    openFoodFactsClient = openFoodFactsClient
                ) as T
            }
        }
    }
}
