package com.nutritrack.app.ui.navigation

import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Book
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Restaurant
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.nutritrack.app.ui.NutriTrackViewModel
import com.nutritrack.app.ui.screens.diary.DiaryScreen
import com.nutritrack.app.ui.screens.foods.FoodsScreen
import com.nutritrack.app.ui.screens.home.HomeScreen
import com.nutritrack.app.ui.screens.quickadd.QuickAddBottomSheet
import com.nutritrack.app.ui.screens.settings.SettingsScreen

enum class TopLevelDestination(
    val route: String,
    val label: String,
    val icon: ImageVector
) {
    HOME("home", "Home", Icons.Default.Home),
    DIARY("diary", "Food Diary", Icons.Default.Book),
    FOODS("foods", "Foods", Icons.Default.Restaurant),
    SETTINGS("settings", "Settings", Icons.Default.Settings)
}

@Composable
fun NutriTrackNavHost(
    viewModel: NutriTrackViewModel,
    modifier: Modifier = Modifier
) {
    val navController = rememberNavController()
    val context = LocalContext.current

    val selectedDate by viewModel.selectedDate.collectAsState()
    val todayDate by viewModel.todayDate.collectAsState()
    val summary by viewModel.dailySummary.collectAsState()
    val entries by viewModel.entriesForSelectedDate.collectAsState()
    val allFoods by viewModel.allFoods.collectAsState()
    val recentFoods by viewModel.recentFoods.collectAsState()
    val favorites by viewModel.favorites.collectAsState()
    val savedMeals by viewModel.savedMeals.collectAsState()
    val preferences by viewModel.preferences.collectAsState()
    val effectiveTarget by viewModel.effectiveTargetForSelectedDate.collectAsState()
    val pastSearchResults by viewModel.pastEntrySearchResults.collectAsState()
    val sevenDayAverages by viewModel.sevenDayAverages.collectAsState()
    val thirtyDayAverages by viewModel.thirtyDayAverages.collectAsState()
    val recentSevenDaySeries by viewModel.recentSevenDaySeries.collectAsState()
    val offLoading by viewModel.offLoading.collectAsState()
    val offStatusMessage by viewModel.offStatusMessage.collectAsState()

    var showQuickAddSheet by rememberSaveable { mutableStateOf(false) }

    Scaffold(
        modifier = modifier,
        bottomBar = {
            val navBackStackEntry by navController.currentBackStackEntryAsState()
            val currentRoute = navBackStackEntry?.destination?.route

            NavigationBar {
                TopLevelDestination.entries.forEach { dest ->
                    NavigationBarItem(
                        selected = currentRoute == dest.route,
                        onClick = {
                            navController.navigate(dest.route) {
                                popUpTo(navController.graph.findStartDestination().id) {
                                    saveState = true
                                }
                                launchSingleTop = true
                                restoreState = true
                            }
                        },
                        icon = { Icon(dest.icon, contentDescription = dest.label) },
                        label = { Text(dest.label) }
                    )
                }
            }
        }
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = TopLevelDestination.HOME.route,
            modifier = Modifier.padding(innerPadding)
        ) {
            composable(TopLevelDestination.HOME.route) {
                HomeScreen(
                    selectedDate = selectedDate,
                    todayDate = todayDate,
                    summary = summary,
                    entries = entries,
                    allFoods = allFoods,
                    defaultMealCategory = preferences.lastUsedMealCategory,
                    onPreviousDay = viewModel::goToPreviousDay,
                    onNextDay = viewModel::goToNextDay,
                    onJumpToToday = viewModel::jumpToToday,
                    onOpenQuickAdd = { showQuickAddSheet = true },
                    onManualEntrySave = { meal, foodName, qty, unit, kcal, p, c, f ->
                        viewModel.logManualPortion(selectedDate, meal, foodName, qty, unit, kcal, p, c, f)
                    },
                    onEditEntry = viewModel::editEntry,
                    onDeleteEntry = viewModel::deleteEntry,
                    onDuplicateEntry = { entry -> viewModel.duplicateEntry(entry) }
                )
            }

            composable(TopLevelDestination.DIARY.route) {
                DiaryScreen(
                    selectedDate = selectedDate,
                    todayDate = todayDate,
                    summary = summary,
                    entries = entries,
                    pastSearchResults = pastSearchResults,
                    allFoods = allFoods,
                    onSelectDate = viewModel::selectDate,
                    onOpenQuickAdd = { showQuickAddSheet = true },
                    onRepeatYesterday = viewModel::repeatYesterdayIntoSelectedDate,
                    onCopyMealToToday = viewModel::copyMealToToday,
                    onEditEntry = viewModel::editEntry,
                    onDeleteEntry = viewModel::deleteEntry,
                    onDuplicateEntryToSelectedDate = { entry ->
                        viewModel.duplicateEntry(entry, targetDate = selectedDate)
                    },
                    onSearchPastEntriesQueryChange = viewModel::setPastSearchQuery
                )
            }

            composable(TopLevelDestination.FOODS.route) {
                FoodsScreen(
                    allFoods = allFoods,
                    recentFoods = recentFoods,
                    favorites = favorites,
                    savedMeals = savedMeals,
                    defaultMealCategory = preferences.lastUsedMealCategory,
                    openFoodFactsEnabled = preferences.openFoodFactsEnabled,
                    openFoodFactsLoading = offLoading,
                    openFoodFactsMessage = offStatusMessage,
                    onQuickLogFood = { food, qty, unit ->
                        viewModel.quickLogSingleFood(
                            selectedDate,
                            preferences.lastUsedMealCategory,
                            food,
                            qty,
                            unit
                        )
                    },
                    onToggleFavorite = viewModel::toggleFavorite,
                    onCreateCustomFood = viewModel::createCustomFood,
                    onDeleteCustomFood = viewModel::deleteCustomFood,
                    onSaveServing = viewModel::saveFoodServing,
                    onDeleteServing = viewModel::deleteFoodServing,
                    onCreateSavedMeal = viewModel::createSavedMeal,
                    onLogSavedMeal = viewModel::logSavedMeal,
                    onDeleteSavedMeal = viewModel::deleteSavedMeal,
                    onSearchOpenFoodFacts = viewModel::searchOpenFoodFacts
                )
            }

            composable(TopLevelDestination.SETTINGS.route) {
                SettingsScreen(
                    selectedDate = selectedDate,
                    effectiveTarget = effectiveTarget,
                    sevenDayAverages = sevenDayAverages,
                    thirtyDayAverages = thirtyDayAverages,
                    recentSevenDaySeries = recentSevenDaySeries,
                    themeMode = preferences.themeMode,
                    keepQuickAddFocused = preferences.keepQuickAddFocused,
                    openFoodFactsEnabled = preferences.openFoodFactsEnabled,
                    onSaveTargetsForDate = viewModel::saveTargets,
                    onThemeModeChange = viewModel::setThemeMode,
                    onKeepQuickAddFocusedChange = viewModel::setKeepQuickAddFocused,
                    onOpenFoodFactsEnabledChange = viewModel::setOpenFoodFactsEnabled,
                    onShareCsv = { viewModel.shareCsvExport(context) },
                    onWriteCsvToUri = { uri -> viewModel.writeCsvExportToUri(context, uri) }
                )
            }
        }
    }

    if (showQuickAddSheet) {
        QuickAddBottomSheet(
            initialDate = selectedDate,
            initialMealCategory = preferences.lastUsedMealCategory,
            keepFocusedAfterAdd = preferences.keepQuickAddFocused,
            allFoods = allFoods,
            recentFoods = recentFoods,
            favorites = favorites,
            onDismiss = { showQuickAddSheet = false },
            onMealCategorySelected = viewModel::setLastUsedMealCategory,
            onConfirmBatch = viewModel::confirmQuickAddBatch,
            onOneTapLogChip = viewModel::quickLogSingleFood,
            onSaveMissingServingWeight = { foodId, unitLabel, weight ->
                viewModel.saveFoodServing(foodId, unitLabel, weight, isDefault = false)
            },
            onManualEntrySave = viewModel::logManualPortion,
            onCreateCustomFood = viewModel::createCustomFood
        )
    }
}
