package com.nutritrack.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.lifecycle.viewmodel.compose.viewModel
import com.nutritrack.app.ui.NutriTrackViewModel
import com.nutritrack.app.ui.navigation.NutriTrackNavHost
import com.nutritrack.app.ui.theme.NutriTrackTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val appContainer = (application as NutriTrackApplication).container

        setContent {
            val viewModel: NutriTrackViewModel = viewModel(
                factory = NutriTrackViewModel.provideFactory(
                    repository = appContainer.nutritionRepository,
                    preferencesRepository = appContainer.preferencesRepository,
                    openFoodFactsClient = appContainer.openFoodFactsClient
                )
            )
            val preferences by viewModel.preferences.collectAsState()

            NutriTrackTheme(themeMode = preferences.themeMode) {
                NutriTrackNavHost(viewModel = viewModel)
            }
        }
    }
}
