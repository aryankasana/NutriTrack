package com.nutritrack.app.ui.screens.settings

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.nutritrack.app.data.local.entity.NutritionTargetEntity
import com.nutritrack.app.domain.calculation.DayHistoryPoint
import com.nutritrack.app.domain.calculation.NutritionCalculator
import com.nutritrack.app.domain.calculation.PeriodNutritionAverages
import com.nutritrack.app.domain.model.ThemeMode
import java.time.LocalDate
import java.time.format.DateTimeFormatter

@Composable
fun SettingsScreen(
    selectedDate: LocalDate,
    effectiveTarget: NutritionTargetEntity?,
    sevenDayAverages: PeriodNutritionAverages,
    thirtyDayAverages: PeriodNutritionAverages,
    recentSevenDaySeries: List<DayHistoryPoint>,
    themeMode: ThemeMode,
    keepQuickAddFocused: Boolean,
    openFoodFactsEnabled: Boolean,
    onSaveTargetsForDate: (
        effectiveFrom: LocalDate,
        kcal: Double?,
        protein: Double?,
        carbs: Double?,
        fat: Double?
    ) -> Unit,
    onThemeModeChange: (ThemeMode) -> Unit,
    onKeepQuickAddFocusedChange: (Boolean) -> Unit,
    onOpenFoodFactsEnabledChange: (Boolean) -> Unit,
    onShareCsv: () -> Unit,
    onWriteCsvToUri: (android.net.Uri) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var kcalInput by remember(effectiveTarget) {
        mutableStateOf(effectiveTarget?.kcal?.toInt()?.toString() ?: "")
    }
    var proteinInput by remember(effectiveTarget) {
        mutableStateOf(effectiveTarget?.protein?.toString() ?: "")
    }
    var carbsInput by remember(effectiveTarget) {
        mutableStateOf(effectiveTarget?.carbs?.toString() ?: "")
    }
    var fatInput by remember(effectiveTarget) {
        mutableStateOf(effectiveTarget?.fat?.toString() ?: "")
    }

    val safLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("text/csv")
    ) { uri ->
        if (uri != null) {
            onWriteCsvToUri(uri)
        }
    }

    val shortDateFormatter = remember { DateTimeFormatter.ofPattern("EEE dd MMM") }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "Settings & History",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold
            )
        }

        // Nutrition Targets Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = "Nutrition Targets (Effective from $selectedDate)",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Leave any field blank to unset that target. Unset targets hide remaining and progress bars for that nutrient.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = kcalInput,
                            onValueChange = { kcalInput = it },
                            label = { Text("Calories (kcal)") },
                            placeholder = { Text("Unset") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = proteinInput,
                            onValueChange = { proteinInput = it },
                            label = { Text("Protein (g)") },
                            placeholder = { Text("Unset") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = carbsInput,
                            onValueChange = { carbsInput = it },
                            label = { Text("Carbs (g)") },
                            placeholder = { Text("Unset") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = fatInput,
                            onValueChange = { fatInput = it },
                            label = { Text("Fat (g)") },
                            placeholder = { Text("Unset") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        TextButton(
                            onClick = {
                                kcalInput = ""
                                proteinInput = ""
                                carbsInput = ""
                                fatInput = ""
                                onSaveTargetsForDate(selectedDate, null, null, null, null)
                            }
                        ) {
                            Text("Clear All Targets")
                        }
                        Button(
                            onClick = {
                                onSaveTargetsForDate(
                                    selectedDate,
                                    kcalInput.trim().toDoubleOrNull(),
                                    proteinInput.trim().toDoubleOrNull(),
                                    carbsInput.trim().toDoubleOrNull(),
                                    fatInput.trim().toDoubleOrNull()
                                )
                            }
                        ) {
                            Text("Save Targets")
                        }
                    }
                }
            }
        }

        // History & Logged-Day Averages Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = "History & Averages (Logged Days Only)",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Averages include only days with at least one logged entry. Unlogged days show 'No data', never zero.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    AveragesRow(label = "Last 7 Days", averages = sevenDayAverages)
                    AveragesRow(label = "Last 30 Days", averages = thirtyDayAverages)

                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Last 7 Days Breakdown",
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.Bold
                    )
                    recentSevenDaySeries.forEach { point ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = point.date.format(shortDateFormatter),
                                style = MaterialTheme.typography.bodySmall
                            )
                            if (point.hasData && point.totalKcal != null) {
                                Text(
                                    text = "${NutritionCalculator.formatKcal(point.totalKcal)} kcal • " +
                                        "${NutritionCalculator.formatMacro(point.totalProtein ?: 0.0)}P " +
                                        "${NutritionCalculator.formatMacro(point.totalCarbs ?: 0.0)}C " +
                                        "${NutritionCalculator.formatMacro(point.totalFat ?: 0.0)}F",
                                    style = MaterialTheme.typography.bodySmall,
                                    fontWeight = FontWeight.SemiBold
                                )
                            } else {
                                Text(
                                    text = "No data",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }
            }
        }

        // Theme & Preferences Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text(
                        text = "Appearance & Workflow",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        ThemeMode.entries.forEach { mode ->
                            FilterChip(
                                selected = themeMode == mode,
                                onClick = { onThemeModeChange(mode) },
                                label = { Text(mode.displayName) }
                            )
                        }
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Keep Quick-Add field focused after 'Add all'",
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.Medium
                            )
                            Text(
                                text = "Allows rapid consecutive batch logging without reopening the sheet.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Switch(
                            checked = keepQuickAddFocused,
                            onCheckedChange = onKeepQuickAddFocusedChange
                        )
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Enable Open Food Facts Lookup (Optional)",
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.Medium
                            )
                            Text(
                                text = "No API key. Caches results in Room with source=OFF and allows manual correction. Core app works 100% offline without it.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Switch(
                            checked = openFoodFactsEnabled,
                            onCheckedChange = onOpenFoodFactsEnabledChange
                        )
                    }
                }
            }
        }

        // CSV Export Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = "CSV Data Export",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Exports all entries (date, time, meal, food, quantity, unit, kcal, P, C, F, source).",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(
                            onClick = onShareCsv,
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(Icons.Default.Share, contentDescription = null)
                            Text(" Share Sheet")
                        }
                        OutlinedButton(
                            onClick = { safLauncher.launch("nutritrack_entries.csv") },
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(Icons.Default.Download, contentDescription = null)
                            Text(" Save to File")
                        }
                    }
                }
            }
            Spacer(modifier = Modifier.height(36.dp))
        }
    }
}

@Composable
private fun AveragesRow(
    label: String,
    averages: PeriodNutritionAverages
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = "$label (${averages.loggedDaysCount}/${averages.totalWindowDays} days logged)",
            style = MaterialTheme.typography.bodySmall,
            fontWeight = FontWeight.Medium
        )
        if (averages.loggedDaysCount > 0 && averages.averageKcal != null) {
            Text(
                text = "Avg ${NutritionCalculator.formatKcal(averages.averageKcal)} kcal • " +
                    "${NutritionCalculator.formatMacro(averages.averageProtein ?: 0.0)}P " +
                    "${NutritionCalculator.formatMacro(averages.averageCarbs ?: 0.0)}C " +
                    "${NutritionCalculator.formatMacro(averages.averageFat ?: 0.0)}F",
                style = MaterialTheme.typography.bodySmall,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )
        } else {
            Text(
                text = "No data",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}
