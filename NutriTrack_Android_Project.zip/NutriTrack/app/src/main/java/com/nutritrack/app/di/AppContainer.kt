package com.nutritrack.app.di

import android.content.Context
import com.nutritrack.app.data.local.NutriTrackDatabase
import com.nutritrack.app.data.local.SeedDatabaseLoader
import com.nutritrack.app.data.preferences.UserPreferencesRepository
import com.nutritrack.app.data.remote.OpenFoodFactsClient
import com.nutritrack.app.data.repository.NutritionRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

/**
 * Lightweight manual Dependency Injection container initialized in `NutriTrackApplication`.
 */
class AppContainer(context: Context) {
    private val appContext = context.applicationContext
    private val applicationScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    val database: NutriTrackDatabase by lazy {
        NutriTrackDatabase.getInstance(appContext)
    }

    val preferencesRepository: UserPreferencesRepository by lazy {
        UserPreferencesRepository(appContext)
    }

    val nutritionRepository: NutritionRepository by lazy {
        NutritionRepository(
            foodDao = database.foodDao(),
            foodServingDao = database.foodServingDao(),
            foodEntryDao = database.foodEntryDao(),
            nutritionTargetDao = database.nutritionTargetDao(),
            favoriteFoodDao = database.favoriteFoodDao(),
            quantityHistoryDao = database.quantityHistoryDao(),
            savedMealDao = database.savedMealDao()
        )
    }

    val openFoodFactsClient: OpenFoodFactsClient by lazy {
        OpenFoodFactsClient(nutritionRepository)
    }

    fun initializeSeedDataAsync() {
        applicationScope.launch {
            SeedDatabaseLoader.ensureSeeded(
                context = appContext,
                foodDao = database.foodDao(),
                foodServingDao = database.foodServingDao()
            )
        }
    }
}
