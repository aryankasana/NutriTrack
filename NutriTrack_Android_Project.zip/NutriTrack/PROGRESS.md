# NutriTrack Progress Log

## Environment Check (Ground Rules Disclosure)
- **OS / Container**: Debian 12 Linux sandbox (`x86_64`), offline (no outbound network access).
- **Java Runtime**: OpenJDK Runtime Environment `17.0.20.1` (`/usr/bin/java` present; `javac` compiler not installed).
- **Kotlin / Gradle / Android SDK**: Not installed (`kotlinc`, `gradle`, `sdkmanager`, `aapt2`, `adb`, and Android SDK platforms/build-tools are absent from the container, and Gradle wrapper cannot download distributions due to disabled network access).
- **Emulator / Connected Device**: None (`adb` not installed, no connected device/emulator).
- **Build & Test Impact**: `./gradlew assembleDebug` and `./gradlew testDebugUnitTest` **cannot be executed** in this container environment. Per ground rules, no Gradle build or JUnit test execution is claimed to have passed. All Android/Kotlin features are labeled `implemented+untested` regarding Android/Gradle execution, while a local Python verification suite (`tools/verify_project.py`) validates the seed data generator, SQLite schema/queries/migrations (`sqlite3`), and Kotlin source structure.

## Phase Status

### Phase 0: Environment Check, Scaffold & Version Catalog
- **Done**:
  - Environment inspected and documented honestly.
  - Initialized single-module Android project (`:app`, `minSdk = 26`, `targetSdk = 35`, `compileSdk = 35`).
  - Configured Gradle Version Catalog (`gradle/libs.versions.toml`) with Kotlin 2.0.21, KSP, Jetpack Compose BOM, Material 3, Room 2.6.1 (`exportSchema = true`), DataStore Preferences, Navigation Compose, and JUnit/Robolectric test dependencies.
  - Added `AndroidManifest.xml` with `FileProvider` for CSV export share sheet.
- **Tested**:
  - Gradle build / JUnit tests: **Not run** (no Android SDK, Gradle, `javac`, or `kotlinc` in container).

### Phase 1: Schema, Calculation Engine, Targets, Home Screen, Manual Entry, Edit/Delete, Themes
- **Done**:
  - Implemented all Room entities (`FoodEntity`, `FoodServingEntity`, `FoodEntryEntity` with `ON DELETE SET NULL`, `SavedMealEntity`, `SavedMealItemEntity`, `FavoriteFoodEntity`, `QuantityHistoryEntity`, `NutritionTargetEntity`), `Converters`, and `NutriTrackDatabase` (`exportSchema = true`).
  - Implemented DAOs (`FoodDao`, `FoodServingDao`, `FoodEntryDao`, `NutritionTargetDao`, `FavoriteFoodDao`, `QuantityHistoryDao`, `SavedMealDao`) where daily totals come strictly from SQL `SUM` over `food_entries` and daily targets resolve via `WHERE effectiveFrom <= :date ORDER BY effectiveFrom DESC LIMIT 1`.
  - Implemented `NutritionCalculator` using `Double` internally, rounding only for display (whole kcal, 1 decimal macros), scaling stored nutrition by `newAmount / oldAmount` on quantity edits, recalculating when changing food, never hiding negative remaining ("Over by X"), and omitting remaining/progress bars when a target is unset.
  - Implemented `UserPreferencesRepository` (DataStore) for theme, last-used meal category, and UI flags.
  - Implemented Material 3 Light and Dark themes (`Theme.kt`) and `HomeScreen.kt` with `selectedDate`, midnight rollover observer in `NutriTrackViewModel`, 4 macro cards, meal grouping, manual entry fallback, edit, delete, and duplicate.
  - Wrote JUnit 4 tests in `NutritionCalculatorTest.kt`.
- **Tested**:
  - Gradle build / JUnit tests: **Not run** (no Android SDK/Gradle/`kotlinc` in container).
  - SQLite `SUM` fixture (`Food A 200/10/25/6 + Food B 300/20/30/10 -> 500 kcal, 30P, 55C, 16F`) verified via `tools/verify_project.py`.

### Phase 2: Seed DB, Serving Sizes, Food Search, Custom Foods
- **Done**:
  - Created `tools/generate_seed_foods.py` to generate `app/src/main/assets/seed_foods.json` and `app/src/main/assets/seed_foods.csv` with `source = ESTIMATE` per row (since live IFCT/USDA/OFF databases cannot be fetched in the offline container) and food-specific `FoodServing` weights.
  - Implemented `SeedDatabaseLoader.kt`, `FoodSearchMatcher.kt`, `NutritionRepository.kt`, and `FoodsScreen.kt` (All / Recent / Favorites / Saved meals / Custom tabs, custom food creation/deletion, per-food serving size editor).
- **Tested**:
  - `python3 tools/generate_seed_foods.py` and `python3 tools/verify_project.py` executed and passed.
  - Gradle build / JUnit tests: **Not run** (no Android SDK/Gradle/`kotlinc` in container).

### Phase 3: Quick-Add Parser, Preview/Confirm Sheet, Remembered Meal Category
- **Done**:
  - Implemented deterministic pure-Kotlin `QuickAddParser.kt` supporting comma, `+`, ` and `, and newline delimiters; `[qty] [unit] name`, `[qty] [name] [unit]`, and `name [qty unit]` patterns; integer, decimal, fraction (`1/2`), Unicode fraction (`½`), and word (`one`, `two`, `half`) quantities; unit aliases; preparation modifiers; and `MATCHED`, `AMBIGUOUS`, and `UNMATCHED` resolution.
  - Implemented `QuickAddBottomSheet.kt` with editable preview rows, live kcal/P/C/F, running meal total, remembered meal-category chips, date selector, prompt to save missing household serving weights once without guessing, and `"Add all"` confirmation keeping the text field focused.
  - Wrote `QuickAddParserTest.kt` covering all 10 required parser test inputs.
- **Tested**:
  - Device install (`adb install -r`): **Not run** (no emulator/device or `adb` in container).
  - Gradle build / JUnit tests: **Not run** (no Android SDK/Gradle/`kotlinc` in container).

### Phase 4: Diary/Calendar, Copy/Repeat/Duplicate/Search, Recents, Favorites, Saved Meals
- **Done**:
  - Implemented `DiaryScreen.kt` with 7-day date strip, Material 3 `DatePickerDialog` calendar, any date's entries and SQL `SUM` totals, add/edit/delete/duplicate, copy meal to today, repeat yesterday, and search past entries.
  - Integrated Recent foods (derived via SQL `GROUP BY foodId` over `food_entries`), Favorites (with preferred quantity/unit), `QuantityHistory` tracking, and `SavedMeal` + `SavedMealItem` creation and one-tap logging.
- **Tested**:
  - Gradle build / JUnit tests: **Not run** (no Android SDK/Gradle/`kotlinc` in container).

### Phase 5: History, CSV Export, Migration Test, Seed Expansion
- **Done**:
  - Implemented `HistoryAnalyzer.kt` computing 7-day and 30-day averages strictly over days with `>= 1` entry (`entryCount > 0`); unlogged days return `hasData = false` and display `"No data"`, never zero.
  - Implemented `CsvExporter.kt` exporting all entries (`date,time,meal,food,quantity,unit,kcal,P,C,F,source`) via Android Share Sheet (`FileProvider`) and Storage Access Framework (`CreateDocument("text/csv")`).
  - Exported Room schemas `1.json` and `2.json` (`app/schemas/com.nutritrack.app.data.local.NutriTrackDatabase/`), implemented `MIGRATION_1_2`, and wrote `HistoryAndCsvExportTest.kt` and `NutriTrackRoomRobolectricTest.kt`.
  - Expanded `tools/generate_seed_foods.py` to **62 essential Indian and gym foods** with raw/cooked separation.
- **Tested**:
  - `python3 tools/verify_project.py` verified SQLite schema, `ON DELETE SET NULL`, file-backed persistence across close/reopen, and `MIGRATION_1_2`.
  - Gradle build / JUnit / Robolectric tests: **Not run** (no Android SDK/Gradle/`kotlinc` in container).

### Phase 6: Optional Open Food Facts Lookup
- **Done**:
  - Implemented `OpenFoodFactsClient.kt` (no API key, public ODbL search endpoint, offline-safe exception handling, caches products in Room with `source = FoodSource.OFF`, shows `"OFF"` badge, allows manual serving/macro correction, behind `openFoodFactsEnabled` feature flag in Settings).
- **Tested**:
  - Gradle build / JUnit tests: **Not run** (no Android SDK/Gradle/`kotlinc` in container).

## Known Bugs & Remaining Limitations
1. **Unverified Gradle Compile in Offline Container**: Because this environment lacks `javac`, `kotlinc`, Gradle, and the Android SDK, `./gradlew assembleDebug` and `./gradlew testDebugUnitTest` have not been executed here.
2. **Estimated Seed Data (`source = ESTIMATE`)**: All 62 bundled seed foods are marked `ESTIMATE` and display an `"Estimated"` badge until verified against official IFCT 2017, USDA FoodData Central, and Open Food Facts tables.
3. **Custom Recipe Builder**: Multi-ingredient meals are supported via `SavedMeal` + `SavedMealItem` and manual portion logging; raw-to-cooked yield weight calculation for multi-serving homemade recipes is not included.
